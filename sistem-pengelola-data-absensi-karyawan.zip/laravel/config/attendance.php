<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Jam Kerja Kantor (WIB)
    |--------------------------------------------------------------------------
    */
    'default_clock_in' => env('ATTENDANCE_CLOCK_IN', '08:15:00'),
    'default_clock_out_mon_thu' => env('ATTENDANCE_CLOCK_OUT_MON_THU', '16:30:00'),
    'default_clock_out_fri' => env('ATTENDANCE_CLOCK_OUT_FRI', '17:00:00'),

    /*
    |--------------------------------------------------------------------------
    | Toleransi & Nominal Potongan (Rupiah)
    |--------------------------------------------------------------------------
    */
    'late_threshold_minutes' => 60,
    'penalties' => [
        'late_under_or_equal_60' => 7500,
        'late_over_60' => 10000,
        'early_leave' => 10000,
        'missing_in' => 10000,
        'missing_out' => 10000,
        'missing_both_working_day' => 20000,
        'holiday_missing' => 0, // Libur nasional/akhir pekan bebas denda
    ],

    'timezone' => 'Asia/Jakarta',
];
