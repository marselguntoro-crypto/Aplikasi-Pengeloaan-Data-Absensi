@extends('layouts.app')

@section('title', 'Tambah Pegawai Baru')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">

    <div class="flex items-center justify-between">
        <div>
            <a href="{{ route('employees.index') }}" class="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800 transition mb-2">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                <span>Kembali ke Master Pegawai</span>
            </a>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
                <i data-lucide="user-plus" class="w-6 h-6 text-emerald-600"></i>
                Tambah Pegawai Baru
            </h1>
            <p class="text-sm text-slate-500 mt-0.5">
                Pastikan Kode Pegawai sesuai dengan ID User yang terdaftar di mesin absensi fingerprint/biometrik.
            </p>
        </div>
    </div>

    @if($errors->any())
        <div class="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-sm">
            <p class="font-semibold flex items-center gap-1.5 mb-2">
                <i data-lucide="alert-circle" class="w-5 h-5"></i>
                Terdapat beberapa kesalahan input:
            </p>
            <ul class="list-disc list-inside space-y-1 text-xs">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <form method="POST" action="{{ route('employees.store') }}" class="p-6 space-y-6">
            @csrf

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <!-- Kode Pegawai (Machine ID) -->
                <div>
                    <label for="employee_code" class="block text-sm font-semibold text-slate-700 mb-1">
                        Kode Pegawai / ID Mesin <span class="text-rose-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="employee_code" 
                        name="employee_code" 
                        value="{{ old('employee_code') }}" 
                        placeholder="Contoh: PEG001 atau 1001" 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('employee_code') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror font-mono"
                        required
                    >
                    <p class="text-xs text-slate-400 mt-1">Harus unik. Digunakan untuk pencocokan log absensi mesin.</p>
                </div>

                <!-- NIP -->
                <div>
                    <label for="nip" class="block text-sm font-semibold text-slate-700 mb-1">
                        NIP / Nomor Induk Pegawai
                    </label>
                    <input 
                        type="text" 
                        id="nip" 
                        name="nip" 
                        value="{{ old('nip') }}" 
                        placeholder="Contoh: 198503152010011002" 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('nip') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror font-mono"
                    >
                    <p class="text-xs text-slate-400 mt-1">Opsional untuk non-PNS / Tenaga Kontrak.</p>
                </div>

                <!-- Nama Lengkap -->
                <div class="sm:col-span-2">
                    <label for="name" class="block text-sm font-semibold text-slate-700 mb-1">
                        Nama Lengkap Beserta Gelar <span class="text-rose-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name" 
                        value="{{ old('name') }}" 
                        placeholder="Contoh: Dr. Budi Santoso, S.Kom., M.T." 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('name') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror"
                        required
                    >
                </div>

                <!-- Unit / Departemen -->
                <div>
                    <label for="department" class="block text-sm font-semibold text-slate-700 mb-1">
                        Unit / Departemen <span class="text-rose-500">*</span>
                    </label>
                    <select 
                        id="department" 
                        name="department" 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('department') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror bg-white"
                        required
                    >
                        <option value="">Pilih Departemen</option>
                        @foreach($departments as $dept)
                            <option value="{{ $dept }}" {{ old('department') === $dept ? 'selected' : '' }}>{{ $dept }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- Jabatan -->
                <div>
                    <label for="position" class="block text-sm font-semibold text-slate-700 mb-1">
                        Jabatan <span class="text-rose-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="position" 
                        name="position" 
                        value="{{ old('position') }}" 
                        placeholder="Contoh: Pranata Komputer Ahli Pertama" 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('position') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror"
                        required
                    >
                </div>

                <!-- Status Kepegawaian -->
                <div>
                    <label for="employment_status" class="block text-sm font-semibold text-slate-700 mb-1">
                        Status Kepegawaian <span class="text-rose-500">*</span>
                    </label>
                    <select 
                        id="employment_status" 
                        name="employment_status" 
                        class="w-full px-3.5 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 @error('employment_status') border-rose-300 bg-rose-50/50 @else border-slate-200 @enderror bg-white"
                        required
                    >
                        @foreach($statuses as $st)
                            <option value="{{ $st }}" {{ old('employment_status', 'Tetap') === $st ? 'selected' : '' }}>{{ $st }}</option>
                        @endforeach
                    </select>
                </div>

                <!-- Status Aktif Checkbox -->
                <div class="flex items-center sm:pt-6">
                    <label class="relative flex items-center gap-3 cursor-pointer">
                        <input 
                            type="checkbox" 
                            name="is_active" 
                            value="1" 
                            class="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                            {{ old('is_active', true) ? 'checked' : '' }}
                        >
                        <div>
                            <span class="text-sm font-medium text-slate-800">Pegawai Aktif Bekerja</span>
                            <p class="text-xs text-slate-400">Pegawai aktif akan otomatis dimasukkan ke dalam rekalkulasi harian.</p>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Action buttons -->
            <div class="pt-6 border-t border-slate-100 flex items-center justify-end gap-3">
                <a href="{{ route('employees.index') }}" class="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm font-medium rounded-lg transition">
                    Batal
                </a>
                <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg shadow-sm transition inline-flex items-center gap-2">
                    <i data-lucide="check" class="w-4 h-4"></i>
                    <span>Simpan Pegawai</span>
                </button>
            </div>
        </form>
    </div>

</div>
@endsection
