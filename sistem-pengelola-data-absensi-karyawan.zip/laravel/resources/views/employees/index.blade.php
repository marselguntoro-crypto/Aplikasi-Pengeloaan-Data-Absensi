@extends('layouts.app')

@section('title', 'Data Pegawai & Karyawan')

@section('content')
<div class="space-y-6">

    <!-- Header & Action Bar -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
                <i data-lucide="users" class="w-7 h-7 text-emerald-600"></i>
                Master Data Pegawai
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Kelola data pegawai, sinkronisasi NIP, status kepegawaian, dan integrasi kode mesin absensi.
            </p>
        </div>

        <div class="flex items-center gap-2 flex-wrap">
            <a href="{{ route('employees.export', request()->query()) }}" class="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-medium rounded-lg shadow-sm transition">
                <i data-lucide="download" class="w-4 h-4 text-slate-500"></i>
                <span>Export Excel</span>
            </a>
            @if(auth()->user()->isOperator())
                <a href="{{ route('employees.import.view') }}" class="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 text-sm font-medium rounded-lg shadow-sm transition">
                    <i data-lucide="file-up" class="w-4 h-4 text-emerald-600"></i>
                    <span>Import Excel/CSV</span>
                </a>
                <a href="{{ route('employees.create') }}" class="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg shadow-sm transition">
                    <i data-lucide="user-plus" class="w-4 h-4"></i>
                    <span>Tambah Pegawai</span>
                </a>
            @endif
        </div>
    </div>

    <!-- 4 Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                <i data-lucide="users" class="w-6 h-6"></i>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Pegawai</p>
                <p class="text-2xl font-bold text-slate-800">{{ number_format($stats['total']) }}</p>
                <p class="text-xs text-slate-500 mt-0.5">Terdaftar di master</p>
            </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                <i data-lucide="user-check" class="w-6 h-6"></i>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Pegawai Aktif</p>
                <p class="text-2xl font-bold text-emerald-700">{{ number_format($stats['active']) }}</p>
                <p class="text-xs text-emerald-600 mt-0.5">Wajib absen harian</p>
            </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500 shrink-0">
                <i data-lucide="user-x" class="w-6 h-6"></i>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Pegawai Nonaktif</p>
                <p class="text-2xl font-bold text-slate-600">{{ number_format($stats['inactive']) }}</p>
                <p class="text-xs text-slate-400 mt-0.5">Pensiun / Resign</p>
            </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 shrink-0">
                <i data-lucide="building" class="w-6 h-6"></i>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Unit / Departemen</p>
                <p class="text-2xl font-bold text-sky-700">{{ number_format($stats['departments']) }}</p>
                <p class="text-xs text-sky-600 mt-0.5">Struktur divisi aktif</p>
            </div>
        </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <form method="GET" action="{{ route('employees.index') }}" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <!-- Search -->
            <div class="relative">
                <i data-lucide="search" class="w-4 h-4 text-slate-400 absolute left-3 top-3"></i>
                <input 
                    type="text" 
                    name="search" 
                    value="{{ $search }}"
                    placeholder="Cari Nama, NIP, Kode, Jabatan..." 
                    class="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
            </div>

            <!-- Filter Department -->
            <div>
                <select name="department" class="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white">
                    <option value="">Semua Departemen</option>
                    @foreach($departmentList as $dept)
                        <option value="{{ $dept }}" {{ $department === $dept ? 'selected' : '' }}>{{ $dept }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Filter Status Aktif -->
            <div>
                <select name="status" class="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white">
                    <option value="">Semua Status Aktif</option>
                    <option value="1" {{ $status === '1' ? 'selected' : '' }}>Hanya Aktif</option>
                    <option value="0" {{ $status === '0' ? 'selected' : '' }}>Hanya Nonaktif</option>
                </select>
            </div>

            <!-- Buttons -->
            <div class="flex items-center gap-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg transition inline-flex items-center justify-center gap-2">
                    <i data-lucide="filter" class="w-4 h-4"></i>
                    <span>Terapkan</span>
                </button>
                @if($search || $department || $status !== null && $status !== '')
                    <a href="{{ route('employees.index') }}" class="px-3 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-medium transition" title="Reset Filter">
                        <i data-lucide="rotate-ccw" class="w-4 h-4"></i>
                    </a>
                @endif
            </div>
        </form>
    </div>

    <!-- Table Pegawai -->
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                        <th class="py-3.5 px-4 w-12 text-center">No</th>
                        <th class="py-3.5 px-4">Pegawai</th>
                        <th class="py-3.5 px-4">Kode / NIP</th>
                        <th class="py-3.5 px-4">Unit / Departemen</th>
                        <th class="py-3.5 px-4">Jabatan</th>
                        <th class="py-3.5 px-4">Status Kerja</th>
                        <th class="py-3.5 px-4 text-center">Status</th>
                        <th class="py-3.5 px-4 text-center w-36">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    @forelse($employees as $index => $emp)
                    <tr class="hover:bg-slate-50/80 transition-colors {{ !$emp->is_active ? 'bg-slate-50/40 text-slate-400' : '' }}">
                        <td class="py-3 px-4 text-center font-mono text-xs text-slate-400">
                            {{ $employees->firstItem() + $index }}
                        </td>
                        <td class="py-3 px-4 font-medium text-slate-900">
                            <div class="flex items-center gap-3">
                                <div class="w-9 h-9 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs text-slate-700 uppercase shrink-0">
                                    {{ substr($emp->name, 0, 2) }}
                                </div>
                                <div>
                                    <a href="{{ route('employees.show', $emp->id) }}" class="text-slate-900 hover:text-emerald-600 font-semibold transition">
                                        {{ $emp->name }}
                                    </a>
                                    <p class="text-xs text-slate-400">ID: #{{ $emp->id }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="py-3 px-4">
                            <span class="inline-block font-mono text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                                {{ $emp->employee_code }}
                            </span>
                            <div class="text-xs text-slate-500 font-mono mt-0.5">
                                {{ $emp->nip ?? '-' }}
                            </div>
                        </td>
                        <td class="py-3 px-4">
                            <span class="font-medium text-slate-700">{{ $emp->department }}</span>
                        </td>
                        <td class="py-3 px-4 text-slate-600">
                            {{ $emp->position }}
                        </td>
                        <td class="py-3 px-4">
                            <span class="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded 
                                {{ $emp->employment_status === 'PNS' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : '' }}
                                {{ $emp->employment_status === 'PPPK' ? 'bg-sky-50 text-sky-700 border border-sky-200' : '' }}
                                {{ $emp->employment_status === 'Tetap' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : '' }}
                                {{ $emp->employment_status === 'Kontrak' ? 'bg-amber-50 text-amber-700 border border-amber-200' : '' }}
                                {{ $emp->employment_status === 'Magang' ? 'bg-purple-50 text-purple-700 border border-purple-200' : '' }}">
                                {{ $emp->employment_status }}
                            </span>
                        </td>
                        <td class="py-3 px-4 text-center">
                            @if($emp->is_active)
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                                    Aktif
                                </span>
                            @else
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                                    <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                    Nonaktif
                                </span>
                            @endif
                        </td>
                        <td class="py-3 px-4 text-center">
                            <div class="inline-flex items-center gap-1">
                                <a href="{{ route('employees.show', $emp->id) }}" class="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition" title="Lihat Profil & Absensi">
                                    <i data-lucide="eye" class="w-4 h-4"></i>
                                </a>

                                @if(auth()->user()->isOperator())
                                    <a href="{{ route('employees.edit', $emp->id) }}" class="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition" title="Edit Pegawai">
                                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                                    </a>

                                    <!-- Toggle Status Form -->
                                    <form method="POST" action="{{ route('employees.toggle-status', $emp->id) }}" class="inline">
                                        @csrf
                                        @method('PATCH')
                                        <button type="submit" class="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition" title="{{ $emp->is_active ? 'Nonaktifkan Pegawai' : 'Aktifkan Pegawai' }}" onclick="return confirm('Apakah Anda yakin ingin mengubah status aktif pegawai ini?')">
                                            <i data-lucide="{{ $emp->is_active ? 'user-x' : 'user-check' }}" class="w-4 h-4"></i>
                                        </button>
                                    </form>

                                    <!-- Soft Delete Form -->
                                    <form method="POST" action="{{ route('employees.destroy', $emp->id) }}" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition" title="Hapus (Soft Delete)" onclick="return confirm('Apakah Anda yakin ingin menghapus data pegawai {{ $emp->name }}? Data dapat dipulihkan melalui log audit.')">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="py-12 text-center text-slate-400">
                            <i data-lucide="users" class="w-12 h-12 mx-auto text-slate-300 mb-3"></i>
                            <p class="font-medium text-slate-600">Tidak ada data pegawai yang sesuai</p>
                            <p class="text-xs text-slate-400 mt-1">Coba sesuaikan kata kunci pencarian atau filter departemen.</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination Footer -->
        <div class="px-5 py-4 bg-slate-50 border-t border-slate-200">
            {{ $employees->links() }}
        </div>
    </div>

</div>
@endsection
