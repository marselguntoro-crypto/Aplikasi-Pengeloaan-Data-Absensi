@extends('layouts.app')

@section('title', 'Detail Pegawai: ' . $employee->name)

@section('content')
<div class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <a href="{{ route('employees.index') }}" class="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800 transition mb-2">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                <span>Kembali ke Daftar Pegawai</span>
            </a>
            <div class="flex items-center gap-3">
                <h1 class="text-2xl font-bold text-slate-800 tracking-tight">
                    {{ $employee->name }}
                </h1>
                @if($employee->is_active)
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                        Aktif
                    </span>
                @else
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 text-xs font-semibold rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                        Nonaktif
                    </span>
                @endif
            </div>
            <p class="text-sm text-slate-500 mt-1">
                {{ $employee->position }} &bull; {{ $employee->department }}
            </p>
        </div>

        @if(auth()->user()->isOperator())
            <div class="flex items-center gap-2">
                <a href="{{ route('employees.edit', $employee->id) }}" class="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-medium rounded-lg shadow-sm transition">
                    <i data-lucide="edit-3" class="w-4 h-4 text-slate-500"></i>
                    <span>Edit Profil</span>
                </a>
            </div>
        @endif
    </div>

    <!-- 4 KPI Performance Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <p class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Hari Dicatat</p>
            <p class="text-2xl font-bold text-slate-800 mt-1">{{ $attendanceStats['total_recorded'] }}</p>
            <p class="text-xs text-slate-500 mt-0.5">Riwayat absensi</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <p class="text-xs font-semibold uppercase tracking-wider text-emerald-600">Tepat Waktu</p>
            <p class="text-2xl font-bold text-emerald-700 mt-1">{{ $attendanceStats['on_time'] }}</p>
            <p class="text-xs text-emerald-600 mt-0.5">Sesuai jam masuk</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <p class="text-xs font-semibold uppercase tracking-wider text-amber-600">Terlambat</p>
            <p class="text-2xl font-bold text-amber-700 mt-1">{{ $attendanceStats['late'] }}</p>
            <p class="text-xs text-amber-600 mt-0.5">Kena potongan terlambat</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <p class="text-xs font-semibold uppercase tracking-wider text-purple-600">Missing In/Out</p>
            <p class="text-2xl font-bold text-purple-700 mt-1">{{ $attendanceStats['missing_in_out'] }}</p>
            <p class="text-xs text-purple-600 mt-0.5">Lupa tap masuk/pulang</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <p class="text-xs font-semibold uppercase tracking-wider text-rose-600">Total Potongan</p>
            <p class="text-xl font-bold text-rose-700 mt-1">Rp {{ number_format($attendanceStats['total_penalties'], 0, ',', '.') }}</p>
            <p class="text-xs text-rose-500 mt-0.5">Akumulasi denda</p>
        </div>
    </div>

    <!-- Main Grid: Info Pegawai & Riwayat Terakhir -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Kolom Kiri: Detail Informasi Pegawai -->
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
            <h2 class="text-base font-bold text-slate-800 border-b border-slate-100 pb-3 flex items-center gap-2">
                <i data-lucide="user" class="w-4 h-4 text-emerald-600"></i>
                Informasi Kepegawaian
            </h2>

            <dl class="space-y-4 text-sm">
                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">Kode Pegawai (ID Mesin)</dt>
                    <dd class="mt-1 font-mono font-semibold text-slate-800 bg-slate-50 px-2.5 py-1 rounded border border-slate-200 inline-block">
                        {{ $employee->employee_code }}
                    </dd>
                </div>

                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">NIP</dt>
                    <dd class="mt-1 font-mono text-slate-700">
                        {{ $employee->nip ?? 'Tidak ada / Tenaga Non-ASN' }}
                    </dd>
                </div>

                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">Unit / Departemen</dt>
                    <dd class="mt-1 font-medium text-slate-800">
                        {{ $employee->department }}
                    </dd>
                </div>

                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">Jabatan</dt>
                    <dd class="mt-1 text-slate-700">
                        {{ $employee->position }}
                    </dd>
                </div>

                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">Status Kepegawaian</dt>
                    <dd class="mt-1">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            {{ $employee->employment_status }}
                        </span>
                    </dd>
                </div>

                <div>
                    <dt class="text-xs font-semibold uppercase text-slate-400">Tanggal Terdaftar</dt>
                    <dd class="mt-1 text-slate-600">
                        {{ $employee->created_at ? $employee->created_at->translatedFormat('d F Y H:i') : '-' }}
                    </dd>
                </div>
            </dl>
        </div>

        <!-- Kolom Kanan: Riwayat Log Absensi Harian Terakhir -->
        <div class="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <h2 class="text-base font-bold text-slate-800 flex items-center gap-2">
                    <i data-lucide="calendar" class="w-4 h-4 text-emerald-600"></i>
                    Catatan Absensi Terakhir
                </h2>
                <span class="text-xs text-slate-400">15 Hari Terakhir</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600">
                    <thead class="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                        <tr>
                            <th class="py-3 px-4">Tanggal</th>
                            <th class="py-3 px-4">Masuk (IN)</th>
                            <th class="py-3 px-4">Pulang (OUT)</th>
                            <th class="py-3 px-4">Keterlambatan</th>
                            <th class="py-3 px-4">Status</th>
                            <th class="py-3 px-4 text-right">Potongan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse($employee->attendanceDaily as $daily)
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="py-3 px-4 font-medium text-slate-900">
                                {{ \Carbon\Carbon::parse($daily->attendance_date)->translatedFormat('d M Y') }}
                            </td>
                            <td class="py-3 px-4 font-mono text-xs">
                                {{ $daily->first_in ?? '--:--:--' }}
                            </td>
                            <td class="py-3 px-4 font-mono text-xs">
                                {{ $daily->last_out ?? '--:--:--' }}
                            </td>
                            <td class="py-3 px-4">
                                @if($daily->late_minutes > 0)
                                    <span class="text-xs font-semibold text-amber-600">
                                        +{{ $daily->late_minutes }} menit
                                    </span>
                                @else
                                    <span class="text-xs text-slate-400">-</span>
                                @endif
                            </td>
                            <td class="py-3 px-4">
                                <span class="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded 
                                    {{ str_contains($daily->attendance_status, 'TEPAT WAKTU') ? 'bg-emerald-50 text-emerald-700' : '' }}
                                    {{ str_contains($daily->attendance_status, 'TERLAMBAT') ? 'bg-amber-50 text-amber-700' : '' }}
                                    {{ str_contains($daily->attendance_status, 'LIBUR') ? 'bg-indigo-50 text-indigo-700' : '' }}
                                    {{ str_contains($daily->attendance_status, 'TIDAK ABSEN') ? 'bg-rose-50 text-rose-700' : '' }}">
                                    {{ $daily->attendance_status }}
                                </span>
                            </td>
                            <td class="py-3 px-4 text-right font-mono font-semibold {{ $daily->total_penalty > 0 ? 'text-rose-600' : 'text-slate-400' }}">
                                Rp {{ number_format($daily->total_penalty, 0, ',', '.') }}
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="py-8 text-center text-slate-400 text-xs">
                                Belum ada riwayat absensi yang tercatat untuk pegawai ini.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>
@endsection
