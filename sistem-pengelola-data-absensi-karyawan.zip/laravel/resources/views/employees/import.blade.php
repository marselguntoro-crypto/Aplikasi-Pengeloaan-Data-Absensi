@extends('layouts.app')

@section('title', 'Import Data Pegawai dari Excel / CSV')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">

    <div>
        <a href="{{ route('employees.index') }}" class="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800 transition mb-2">
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            <span>Kembali ke Master Pegawai</span>
        </a>
        <h1 class="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <i data-lucide="file-up" class="w-6 h-6 text-emerald-600"></i>
            Import Pegawai Massal (.xlsx / .csv)
        </h1>
        <p class="text-sm text-slate-500 mt-0.5">
            Unggah file spreadsheet untuk menambahkan atau memperbarui data pegawai secara otomatis.
        </p>
    </div>

    @if(session('error'))
        <div class="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-sm flex items-start gap-3">
            <i data-lucide="alert-circle" class="w-5 h-5 shrink-0 mt-0.5"></i>
            <div>
                <p class="font-semibold">Import Gagal</p>
                <p class="text-xs mt-1">{{ session('error') }}</p>
            </div>
        </div>
    @endif

    <!-- Panduan Format Kolom -->
    <div class="bg-indigo-50/70 border border-indigo-100 rounded-xl p-5 space-y-3">
        <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-indigo-900 flex items-center gap-2">
                <i data-lucide="info" class="w-4 h-4 text-indigo-600"></i>
                Ketentuan Header Kolom Excel / CSV
            </h3>
            <a href="#" class="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800 underline">
                <i data-lucide="download" class="w-3.5 h-3.5"></i>
                Unduh Template Standar (.xlsx)
            </a>
        </div>
        <p class="text-xs text-indigo-700 leading-relaxed">
            Baris pertama file <strong>harus memuat nama kolom berikut</strong> (huruf kecil atau besar didukung):
        </p>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">kode_pegawai</strong> <span class="text-rose-500">*Wajib</span>: ID mesin/fingerprint
            </div>
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">nama_lengkap</strong> <span class="text-rose-500">*Wajib</span>: Nama dan gelar
            </div>
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">nip</strong>: 18 digit angka atau kosong
            </div>
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">departemen</strong>: Unit kerja pegawai
            </div>
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">jabatan</strong>: Jabatan fungsional/struktural
            </div>
            <div class="bg-white/80 p-2 rounded border border-indigo-100">
                <strong class="text-slate-800">status_kepegawaian</strong>: PNS / PPPK / Tetap / Kontrak
            </div>
        </div>
        <p class="text-[11px] text-indigo-600 italic">
            * Jika kode_pegawai sudah ada di sistem, data pegawai tersebut akan diperbarui (Upsert).
        </p>
    </div>

    <!-- Form Upload File -->
    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <form method="POST" action="{{ route('employees.import.store') }}" enctype="multipart/form-data" class="space-y-6">
            @csrf

            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-2">
                    Pilih Berkas Spreadsheet
                </label>
                <div class="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-xl p-8 text-center bg-slate-50/50 transition cursor-pointer relative">
                    <input 
                        type="file" 
                        name="file" 
                        accept=".xlsx,.xls,.csv" 
                        class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                        required
                        onchange="document.getElementById('file-chosen').innerText = this.files[0] ? this.files[0].name : 'Belum ada file dipilih'"
                    >
                    <i data-lucide="file-spreadsheet" class="w-12 h-12 mx-auto text-emerald-600 mb-3"></i>
                    <p class="text-sm font-semibold text-slate-700">
                        Klik untuk memilih file atau seret & lepas ke sini
                    </p>
                    <p class="text-xs text-slate-400 mt-1">
                        Format didukung: Microsoft Excel (.xlsx, .xls) atau Comma-Separated Values (.csv) maks 10 MB
                    </p>
                    <p id="file-chosen" class="text-xs font-mono font-semibold text-emerald-600 mt-3">
                        Belum ada file dipilih
                    </p>
                </div>
            </div>

            <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <a href="{{ route('employees.index') }}" class="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm font-medium rounded-lg transition">
                    Batal
                </a>
                <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg shadow-sm transition inline-flex items-center gap-2">
                    <i data-lucide="upload" class="w-4 h-4"></i>
                    <span>Mulai Proses Import</span>
                </button>
            </div>
        </form>
    </div>

</div>
@endsection
