<!-- Mobile Backdrop -->
<div x-show="sidebarOpen" 
     x-transition:enter="transition-opacity ease-linear duration-300"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition-opacity ease-linear duration-300"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0"
     class="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
     @click="sidebarOpen = false"
     style="display: none;"></div>

<!-- Sidebar Component -->
<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
       class="fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 border-r border-slate-800 transition-transform duration-300 ease-in-out lg:translate-x-0 flex flex-col">
    
    <!-- App Brand / Logo -->
    <div class="h-16 flex items-center px-6 bg-slate-950 border-b border-slate-800/80 gap-3">
        <div class="w-9 h-9 rounded-lg bg-emerald-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
            <i data-lucide="clock-check" class="w-5 h-5"></i>
        </div>
        <div class="flex flex-col overflow-hidden">
            <span class="font-bold text-sm tracking-tight text-white truncate">SIM-ABSENSI</span>
            <span class="text-[11px] text-emerald-400 font-medium truncate">Data & Potongan Kepegawaian</span>
        </div>
    </div>

    <!-- Navigation Menu -->
    <div class="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        <!-- Main Navigation -->
        <div>
            <div class="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Menu Utama
            </div>
            <nav class="space-y-1">
                <a href="{{ route('dashboard') }}" 
                   class="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('dashboard') ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}">
                    <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                    <span>Dashboard</span>
                </a>

                <a href="{{ url('/employees') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors {{ request()->is('employees*') ? 'bg-emerald-600 text-white font-semibold' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}">
                    <div class="flex items-center gap-3">
                        <i data-lucide="users" class="w-4 h-4"></i>
                        <span>Data Pegawai</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 2</span>
                </a>
            </nav>
        </div>

        <!-- Attendance Processing -->
        <div>
            <div class="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Data & Pengolahan Absensi
            </div>
            <nav class="space-y-1">
                <a href="{{ url('/attendance/raw') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="database" class="w-4 h-4"></i>
                        <span>Data Absensi Mentah</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 3</span>
                </a>

                <a href="{{ url('/attendance/import') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="file-up" class="w-4 h-4"></i>
                        <span>Import Data Absensi</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 3</span>
                </a>

                <a href="{{ url('/attendance/calendar') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="calendar" class="w-4 h-4"></i>
                        <span>Kalender Absensi</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 6</span>
                </a>

                <a href="{{ url('/calendar') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="calendar-range" class="w-4 h-4"></i>
                        <span>Kalender Kerja & Libur</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 4</span>
                </a>

                <a href="{{ url('/attendance/adjustments') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="edit-3" class="w-4 h-4"></i>
                        <span>Koreksi Manual</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 9</span>
                </a>
            </nav>
        </div>

        <!-- Reports & Exports -->
        <div>
            <div class="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Laporan & Rekapitulasi
            </div>
            <nav class="space-y-1">
                <a href="{{ url('/reports/monthly') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="file-spreadsheet" class="w-4 h-4"></i>
                        <span>Rekap Bulanan</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 7</span>
                </a>

                <a href="{{ url('/reports/deductions') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="receipt" class="w-4 h-4"></i>
                        <span>Laporan Potongan</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 7</span>
                </a>
            </nav>
        </div>

        <!-- System Administration -->
        <div>
            <div class="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Administrasi & Sistem
            </div>
            <nav class="space-y-1">
                <a href="{{ url('/settings') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="sliders-horizontal" class="w-4 h-4"></i>
                        <span>Pengaturan Aturan</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 1/5</span>
                </a>

                <a href="{{ url('/audit-logs') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="shield-check" class="w-4 h-4"></i>
                        <span>Audit Log</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 9</span>
                </a>

                <a href="{{ url('/users') }}" 
                   class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors text-slate-300 hover:bg-slate-800 hover:text-white">
                    <div class="flex items-center gap-3">
                        <i data-lucide="user-cog" class="w-4 h-4"></i>
                        <span>User Management</span>
                    </div>
                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">Phase 1</span>
                </a>
            </nav>
        </div>
    </div>

    <!-- Active User & Logout Footer -->
    <div class="p-3 bg-slate-950 border-t border-slate-800">
        <div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-slate-900/60">
            <div class="flex items-center gap-2.5 min-w-0">
                <div class="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-xs text-white">
                    {{ strtoupper(substr(auth()->user()->name ?? 'AD', 0, 2)) }}
                </div>
                <div class="flex flex-col truncate">
                    <span class="text-xs font-semibold text-white truncate">{{ auth()->user()->name ?? 'Administrator' }}</span>
                    <span class="text-[10px] text-emerald-400 capitalize font-medium">{{ auth()->user()->role ?? 'admin' }}</span>
                </div>
            </div>
            <form method="POST" action="{{ route('logout') }}" class="m-0">
                @csrf
                <button type="submit" title="Keluar Sistem" class="p-1.5 text-slate-400 hover:text-rose-400 rounded-md hover:bg-slate-800 transition-colors">
                    <i data-lucide="log-out" class="w-4 h-4"></i>
                </button>
            </form>
        </div>
    </div>
</aside>
