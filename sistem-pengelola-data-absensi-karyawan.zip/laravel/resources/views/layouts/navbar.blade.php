<header class="sticky top-0 z-30 bg-white border-b border-slate-200/80 shadow-xs">
    <div class="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        <!-- Left: Mobile Toggle & Page Title -->
        <div class="flex items-center gap-3">
            <button @click="sidebarOpen = true" type="button" class="lg:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 focus:outline-hidden">
                <i data-lucide="menu" class="w-5 h-5"></i>
            </button>
            <div class="flex items-center gap-2">
                <h1 class="text-base sm:text-lg font-bold text-slate-800 tracking-tight">
                    @yield('header-title', 'Dashboard Monitoring Absensi')
                </h1>
                <span class="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">
                    WIB (Asia/Jakarta)
                </span>
            </div>
        </div>

        <!-- Right: Current Clock, Role Indicator, User Status -->
        <div class="flex items-center gap-3 sm:gap-4">
            <!-- Dynamic Realtime Clock Jakarta -->
            <div class="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-medium text-slate-600">
                <i data-lucide="clock" class="w-3.5 h-3.5 text-emerald-600"></i>
                <span id="current-jakarta-time">{{ now('Asia/Jakarta')->translatedFormat('l, d F Y - H:i') }} WIB</span>
            </div>

            <!-- Role Badge -->
            <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700">
                <i data-lucide="shield" class="w-3.5 h-3.5 text-indigo-600"></i>
                <span class="uppercase">{{ auth()->user()->role ?? 'ADMIN' }}</span>
            </div>

            <!-- Notifications placeholder -->
            <button type="button" class="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg relative">
                <i data-lucide="bell" class="w-4 h-4"></i>
                <span class="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white"></span>
            </button>
        </div>
    </div>
</header>
