<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-900">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Pengelola Data Absensi Karyawan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="h-full flex items-center justify-center p-4 sm:p-6 bg-radial from-slate-900 via-slate-950 to-black text-slate-100">

    <div class="w-full max-w-md bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        <!-- Brand Header -->
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-600 text-white mb-4 shadow-lg shadow-emerald-500/25">
                <i data-lucide="clock-check" class="w-8 h-8"></i>
            </div>
            <h1 class="text-2xl font-bold text-white tracking-tight">SIM-ABSENSI</h1>
            <p class="text-xs text-slate-400 mt-1">Sistem Pengolah Data Mentah & Perhitungan Potongan Jam Kerja</p>
        </div>

        <!-- Error notification -->
        @if($errors->any())
            <div class="mb-6 p-4 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-center gap-3">
                <i data-lucide="alert-triangle" class="w-5 h-5 shrink-0 text-rose-400"></i>
                <div>
                    {{ $errors->first() }}
                </div>
            </div>
        @endif

        @if(session('info'))
            <div class="mb-6 p-4 rounded-xl bg-sky-950/60 border border-sky-800/80 text-sky-300 text-xs flex items-center gap-3">
                <i data-lucide="info" class="w-5 h-5 shrink-0 text-sky-400"></i>
                <div>
                    {{ session('info') }}
                </div>
            </div>
        @endif

        <!-- Login Form -->
        <form method="POST" action="{{ route('login.post') }}" class="space-y-4">
            @csrf

            <div>
                <label for="email" class="block text-xs font-semibold text-slate-300 mb-1.5">Alamat Email</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                        <i data-lucide="mail" class="w-4 h-4"></i>
                    </span>
                    <input type="email" id="email" name="email" value="{{ old('email', 'admin@kepegawaian.go.id') }}" required autofocus
                           class="w-full pl-10 pr-3 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                           placeholder="nama@kepegawaian.go.id">
                </div>
            </div>

            <div>
                <div class="flex items-center justify-between mb-1.5">
                    <label for="password" class="block text-xs font-semibold text-slate-300">Kata Sandi</label>
                </div>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                        <i data-lucide="lock" class="w-4 h-4"></i>
                    </span>
                    <input type="password" id="password" name="password" required
                           class="w-full pl-10 pr-3 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                           placeholder="••••••••">
                </div>
            </div>

            <div class="flex items-center justify-between pt-1">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="remember" class="rounded border-slate-800 bg-slate-950 text-emerald-600 focus:ring-emerald-500">
                    <span class="text-xs text-slate-400">Ingat sesi saya</span>
                </label>
            </div>

            <button type="submit" 
                    class="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer">
                <span>Masuk ke Dashboard</span>
                <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </button>
        </form>

        <!-- Development Credentials Card -->
        <div class="mt-8 pt-5 border-t border-slate-800/80">
            <p class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <i data-lucide="key" class="w-3.5 h-3.5 text-emerald-400"></i>
                Akun Bawaan Seeder:
            </p>
            <div class="space-y-1 text-xs text-slate-400 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div class="flex justify-between">
                    <span class="text-slate-300">Admin:</span>
                    <span class="font-mono text-emerald-400">admin@kepegawaian.go.id / AdminAbsensi2026!</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-300">Operator:</span>
                    <span class="font-mono text-emerald-400">operator@kepegawaian.go.id / OperatorAbsensi2026!</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
