@extends('layouts.app')

@section('title', 'Dashboard Monitoring Absensi')
@section('header-title', 'Dashboard Monitoring & Pengolahan Absensi')

@section('content')
<div class="space-y-6">

    <!-- Top Filter & Date Selector Banner -->
    <div class="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-emerald-600">Sistem Pengelola Data Absensi Karyawan</span>
            <h2 class="text-xl font-bold text-slate-800 tracking-tight mt-0.5">
                Monitoring Status Absensi Harian
            </h2>
            <p class="text-xs text-slate-500 mt-1">
                Data mentah diproses otomatis dan dikorelasikan langsung dengan Kalender Kerja aktif.
            </p>
        </div>

        <form method="GET" action="{{ route('dashboard') }}" class="flex flex-wrap items-center gap-2.5">
            <div class="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
                <i data-lucide="calendar" class="w-4 h-4 text-slate-400"></i>
                <label for="date-select" class="text-xs font-medium text-slate-600">Tanggal:</label>
                <input type="date" id="date-select" name="date" value="{{ $selectedDate }}" 
                       onchange="this.form.submit()"
                       class="bg-transparent text-xs font-semibold text-slate-800 focus:outline-hidden cursor-pointer">
            </div>

            <a href="{{ url('/attendance/import') }}" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors shadow-xs">
                <i data-lucide="upload-cloud" class="w-4 h-4"></i>
                <span>Import File Absensi</span>
            </a>
        </form>
    </div>

    <!-- Active Work Calendar & Rules Summary Banner -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- Calendar Status Card -->
        <div class="lg:col-span-1 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-5 shadow-sm flex flex-col justify-between border border-slate-700/60">
            <div>
                <div class="flex items-center justify-between">
                    <span class="text-[11px] font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                        <i data-lucide="calendar-check" class="w-4 h-4"></i>
                        Status Kalender Kerja
                    </span>
                    <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold {{ $isWorkingDay ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30' }}">
                        {{ $isWorkingDay ? 'HARI KERJA' : 'HARI LIBUR' }}
                    </span>
                </div>
                <div class="mt-3">
                    <div class="text-2xl font-black tracking-tight text-white">
                        {{ $carbonDate->translatedFormat('l, d F Y') }}
                    </div>
                    <p class="text-xs text-slate-300 mt-1">
                        {{ $dayStatus }}
                    </p>
                </div>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-700/80 grid grid-cols-2 gap-2 text-xs">
                <div>
                    <span class="text-slate-400 block text-[11px]">Jam Masuk Normal:</span>
                    <span class="font-bold text-emerald-400 text-sm">{{ $rules['clock_in'] }} WIB</span>
                </div>
                <div>
                    <span class="text-slate-400 block text-[11px]">Jam Pulang Normal:</span>
                    <span class="font-bold text-emerald-400 text-sm">
                        {{ $carbonDate->isFriday() ? $rules['clock_out_fri'] : $rules['clock_out_mon_thu'] }} WIB
                    </span>
                </div>
            </div>
        </div>

        <!-- Rules & Penalty Matrix Card -->
        <div class="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
                <h3 class="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <i data-lucide="scale" class="w-4 h-4 text-emerald-600"></i>
                    Matriks Peraturan Potongan & Keterlambatan Aktif
                </h3>
                <span class="text-[11px] font-medium text-slate-500">Konfigurasi Sistem Otomatis</span>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 my-2">
                <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div class="text-[11px] font-medium text-slate-500">Terlambat &le; 1 Jam</div>
                    <div class="text-sm font-bold text-amber-600 mt-0.5">Rp {{ number_format($rules['late_under'], 0, ',', '.') }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">&gt; 08:15 s/d 09:15</div>
                </div>

                <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div class="text-[11px] font-medium text-slate-500">Terlambat &gt; 1 Jam</div>
                    <div class="text-sm font-bold text-rose-600 mt-0.5">Rp {{ number_format($rules['late_over'], 0, ',', '.') }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">&gt; 09:15 WIB</div>
                </div>

                <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div class="text-[11px] font-medium text-slate-500">Pulang Cepat</div>
                    <div class="text-sm font-bold text-orange-600 mt-0.5">Rp {{ number_format($rules['early_leave'], 0, ',', '.') }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">Sebelum jam selesai</div>
                </div>

                <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div class="text-[11px] font-medium text-slate-500">Missing In / Out</div>
                    <div class="text-sm font-bold text-purple-600 mt-0.5">Rp {{ number_format($rules['missing_in'], 0, ',', '.') }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">Hanya 1x absen</div>
                </div>

                <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <div class="text-[11px] font-medium text-slate-500">Tidak Hadir Kerja</div>
                    <div class="text-sm font-bold text-red-700 mt-0.5">Rp {{ number_format($rules['missing_both'], 0, ',', '.') }}</div>
                    <div class="text-[10px] text-slate-400 mt-0.5">Tanpa absen masuk+pulang</div>
                </div>
            </div>

            <div class="flex items-center justify-between text-[11px] text-slate-500 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100">
                <span class="flex items-center gap-1.5 text-emerald-800 font-medium">
                    <i data-lucide="shield-alert" class="w-3.5 h-3.5 text-emerald-600 shrink-0"></i>
                    <strong>Penting:</strong> Absensi pada hari Libur Nasional / Akhir Pekan otomatis <strong>Rp 0 (Bebas Potongan)</strong>.
                </span>
                <a href="{{ url('/settings') }}" class="text-emerald-700 font-semibold hover:underline shrink-0">Ubah Setting &rarr;</a>
            </div>
        </div>
    </div>

    <!-- 8 Main Metric Statistic Cards -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        <!-- Total Pegawai -->
        <div class="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-xs">
            <span class="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">Total Pegawai</span>
            <div class="text-2xl font-bold text-slate-800 mt-1">{{ $stats['total_pegawai'] }}</div>
            <span class="text-[10px] text-slate-400 mt-0.5 block">Pegawai Aktif</span>
        </div>

        <!-- Hadir Tepat Waktu -->
        <div class="bg-white rounded-xl p-3.5 border border-emerald-200 bg-emerald-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider block">Tepat Waktu</span>
            <div class="text-2xl font-bold text-emerald-600 mt-1">{{ $stats['hadir_tepat_waktu'] }}</div>
            <span class="text-[10px] text-emerald-600 font-medium mt-0.5 block">&le; 08:15 (Rp 0)</span>
        </div>

        <!-- Terlambat -->
        <div class="bg-white rounded-xl p-3.5 border border-amber-200 bg-amber-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-amber-700 uppercase tracking-wider block">Terlambat</span>
            <div class="text-2xl font-bold text-amber-600 mt-1">{{ $stats['terlambat'] }}</div>
            <span class="text-[10px] text-amber-600 font-medium mt-0.5 block">&le; 1 Jam / &gt; 1 Jam</span>
        </div>

        <!-- Pulang Cepat -->
        <div class="bg-white rounded-xl p-3.5 border border-orange-200 bg-orange-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-orange-700 uppercase tracking-wider block">Pulang Cepat</span>
            <div class="text-2xl font-bold text-orange-600 mt-1">{{ $stats['pulang_cepat'] }}</div>
            <span class="text-[10px] text-orange-600 font-medium mt-0.5 block">Sebelum Jadwal</span>
        </div>

        <!-- Tidak Absen Masuk -->
        <div class="bg-white rounded-xl p-3.5 border border-purple-200 bg-purple-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-purple-700 uppercase tracking-wider block">Tanpa Masuk</span>
            <div class="text-2xl font-bold text-purple-600 mt-1">{{ $stats['tidak_absen_masuk'] }}</div>
            <span class="text-[10px] text-purple-600 font-medium mt-0.5 block">Hanya Ada Pulang</span>
        </div>

        <!-- Tidak Absen Pulang -->
        <div class="bg-white rounded-xl p-3.5 border border-indigo-200 bg-indigo-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-indigo-700 uppercase tracking-wider block">Tanpa Pulang</span>
            <div class="text-2xl font-bold text-indigo-600 mt-1">{{ $stats['tidak_absen_pulang'] }}</div>
            <span class="text-[10px] text-indigo-600 font-medium mt-0.5 block">Hanya Ada Masuk</span>
        </div>

        <!-- Tidak Hadir / Alpha -->
        <div class="bg-white rounded-xl p-3.5 border border-rose-200 bg-rose-50/20 shadow-xs">
            <span class="text-[11px] font-semibold text-rose-700 uppercase tracking-wider block">Tidak Hadir</span>
            <div class="text-2xl font-bold text-rose-600 mt-1">{{ $stats['tidak_hadir'] }}</div>
            <span class="text-[10px] text-rose-600 font-medium mt-0.5 block">Hari Kerja (Rp 20.000)</span>
        </div>

        <!-- Total Potongan -->
        <div class="bg-white rounded-xl p-3.5 border border-red-300 bg-red-50/40 shadow-xs">
            <span class="text-[11px] font-semibold text-red-700 uppercase tracking-wider block">Total Potongan</span>
            <div class="text-lg font-black text-red-700 mt-1">
                Rp {{ number_format($stats['total_potongan'], 0, ',', '.') }}
            </div>
            <span class="text-[10px] text-red-600 font-medium mt-0.5 block">Kalkulasi Hari Ini</span>
        </div>
    </div>

    <!-- Data Tables & Recent Transactions -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Recent Raw Records Preview -->
        <div class="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                <div>
                    <h3 class="text-sm font-bold text-slate-800">Transaksi Mentah Absensi Terakhir</h3>
                    <p class="text-xs text-slate-500">Log pembacaan mesin fingerprint / face recognition</p>
                </div>
                <a href="{{ url('/attendance/raw') }}" class="text-xs font-semibold text-emerald-600 hover:text-emerald-700">
                    Lihat Semua &rarr;
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
                        <tr>
                            <th class="px-4 py-3">Waktu</th>
                            <th class="px-4 py-3">Kode Pegawai</th>
                            <th class="px-4 py-3">Nama Pegawai</th>
                            <th class="px-4 py-3">Tipe / Status</th>
                            <th class="px-4 py-3">Mesin ID</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-slate-700">
                        @forelse($recentRaw as $raw)
                            <tr class="hover:bg-slate-50/80 transition-colors">
                                <td class="px-4 py-3 font-mono font-medium text-slate-900">{{ $raw->attendance_time }} WIB</td>
                                <td class="px-4 py-3 font-mono">{{ $raw->employee_code }}</td>
                                <td class="px-4 py-3 font-semibold text-slate-800">{{ $raw->employee_name ?? ($raw->employee->name ?? '-') }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                                        {{ $raw->attendance_type ?? 'AUTO_DETECT' }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 font-mono text-slate-400">{{ $raw->machine_id ?? 'MESIN-01' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="px-4 py-8 text-center text-slate-400">
                                    Belum ada transaksi mentah absensi untuk tanggal ini. Klik tombol <a href="{{ url('/attendance/import') }}" class="text-emerald-600 underline font-semibold">Import File Absensi</a> untuk mengunggah log mesin.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Action & Workflow Phase Guide -->
        <div class="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-800 mb-1">Alur Kerja Pengolahan Absensi</h3>
                <p class="text-xs text-slate-500 mb-4">SOP pengolahan data mentah ke laporan potongan</p>

                <ol class="space-y-3 relative border-l border-slate-200 ml-2.5 text-xs">
                    <li class="pl-4 relative">
                        <span class="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></span>
                        <div class="font-semibold text-slate-800">1. Setup Kalender Kerja</div>
                        <p class="text-slate-500 text-[11px]">Pastikan hari libur nasional & akhir pekan terkonfigurasi sebelum hitung.</p>
                    </li>
                    <li class="pl-4 relative">
                        <span class="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></span>
                        <div class="font-semibold text-slate-800">2. Upload Log Mesin Absensi</div>
                        <p class="text-slate-500 text-[11px]">Upload file .xlsx / .csv dengan mapping kolom otomatis/manual.</p>
                    </li>
                    <li class="pl-4 relative">
                        <span class="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></span>
                        <div class="font-semibold text-slate-800">3. Eksekusi Perhitungan Absensi</div>
                        <p class="text-slate-500 text-[11px]">AttendanceCalculationService mengolah waktu masuk/pulang & denda.</p>
                    </li>
                    <li class="pl-4 relative">
                        <span class="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-slate-300 ring-4 ring-white"></span>
                        <div class="font-semibold text-slate-600">4. Verifikasi & Koreksi Manual</div>
                        <p class="text-slate-500 text-[11px]">Perbaiki data jika ada izin/dinas luar tanpa merusak data mentah.</p>
                    </li>
                    <li class="pl-4 relative">
                        <span class="absolute -left-1.5 top-0.5 w-3 h-3 rounded-full bg-slate-300 ring-4 ring-white"></span>
                        <div class="font-semibold text-slate-600">5. Cetak Rekap & Export PDF/Excel</div>
                        <p class="text-slate-500 text-[11px]">Laporan bulanan dan slip rincian potongan pegawai siap dicetak.</p>
                    </li>
                </ol>
            </div>

            <div class="pt-4 border-t border-slate-100 mt-4">
                <a href="{{ url('/attendance/process') }}" class="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors">
                    <i data-lucide="cpu" class="w-4 h-4 text-emerald-400"></i>
                    <span>Jalankan Proses Hitung Absensi</span>
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
