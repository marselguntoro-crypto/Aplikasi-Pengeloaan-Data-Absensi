<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EmployeeController;

/*
|--------------------------------------------------------------------------
| Web Routes - Sistem Pengelola Data Absensi Karyawan
|--------------------------------------------------------------------------
*/

// Redirect Root to Dashboard
Route::get('/', function () {
    return redirect()->route('dashboard');
});

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Protected Application Routes
Route::middleware(['auth'])->group(function () {
    
    // 1. Dashboard Monitoring (Phase 1)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // 2. Data Pegawai (Phase 2)
    Route::prefix('employees')->name('employees.')->group(function () {
        Route::get('/', [EmployeeController::class, 'index'])->name('index');
        Route::get('/create', [EmployeeController::class, 'create'])->name('create');
        Route::post('/', [EmployeeController::class, 'store'])->name('store');
        Route::get('/import', [EmployeeController::class, 'importView'])->name('import.view');
        Route::post('/import', [EmployeeController::class, 'import'])->name('import.store');
        Route::get('/export', [EmployeeController::class, 'export'])->name('export');
        Route::get('/{employee}', [EmployeeController::class, 'show'])->name('show');
        Route::get('/{employee}/edit', [EmployeeController::class, 'edit'])->name('edit');
        Route::put('/{employee}', [EmployeeController::class, 'update'])->name('update');
        Route::delete('/{employee}', [EmployeeController::class, 'destroy'])->name('destroy');
        Route::patch('/{employee}/toggle-status', [EmployeeController::class, 'toggleStatus'])->name('toggle-status');
    });

    // 3. Data Absensi Mentah & Import (Phase 3)
    Route::prefix('attendance')->name('attendance.')->group(function () {
        Route::get('/raw', function () { return view('attendance.raw'); })->name('raw');
        Route::get('/import', function () { return view('attendance.import'); })->name('import');
        Route::post('/import/preview', function () { return response()->json(['status' => 'preview_ready']); });
        Route::post('/import/process', function () { return response()->json(['status' => 'imported']); });
        Route::post('/process', function () { return back()->with('success', 'Perhitungan absensi harian berhasil dijalankan.'); })->name('process');
        Route::get('/calendar', function () { return view('attendance.calendar'); })->name('calendar');
        Route::get('/adjustments', function () { return view('attendance.adjustments'); })->name('adjustments');
    });

    // 4. Kalender Kerja & Hari Libur (Phase 4)
    Route::prefix('calendar')->name('calendar.')->group(function () {
        Route::get('/', function () { return view('calendar.index'); })->name('index');
        Route::get('/holidays', function () { return view('calendar.holidays'); })->name('holidays');
    });

    // 5. Laporan & Rekapitulasi Potongan (Phase 7 & 8)
    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/monthly', function () { return view('reports.monthly'); })->name('monthly');
        Route::get('/deductions', function () { return view('reports.deductions'); })->name('deductions');
        Route::get('/export/excel', function () { return response()->download(''); })->name('export.excel');
        Route::get('/export/pdf', function () { return response()->download(''); })->name('export.pdf');
    });

    // 6. Settings & Audit Logs (Phase 1, 5, 9)
    Route::get('/settings', function () { return view('settings.index'); })->name('settings.index');
    Route::post('/settings', function () { return back()->with('success', 'Pengaturan berhasil diperbarui.'); })->name('settings.update');
    Route::get('/audit-logs', function () { return view('audit_logs.index'); })->name('audit_logs.index');
    Route::get('/users', function () { return view('users.index'); })->name('users.index');
});
