<?php

namespace App\Exports;

use App\Models\Employee;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class EmployeesExport implements FromQuery, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    protected ?string $search;
    protected ?string $department;
    protected ?string $status;

    public function __construct(?string $search = null, ?string $department = null, ?string $status = null)
    {
        $this->search = $search;
        $this->department = $department;
        $this->status = $status;
    }

    public function query()
    {
        $query = Employee::query()->orderBy('department')->orderBy('name');

        if ($this->search) {
            $query->where(function ($q) {
                $q->where('name', 'like', '%' . $this->search . '%')
                  ->orWhere('employee_code', 'like', '%' . $this->search . '%')
                  ->orWhere('nip', 'like', '%' . $this->search . '%');
            });
        }

        if ($this->department) {
            $query->where('department', $this->department);
        }

        if ($this->status !== null && $this->status !== '') {
            $query->where('is_active', (bool)$this->status);
        }

        return $query;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Kode Pegawai',
            'NIP',
            'Nama Lengkap',
            'Unit / Departemen',
            'Jabatan',
            'Status Kepegawaian',
            'Status Aktif',
            'Tanggal Dibuat',
        ];
    }

    public function map($employee): array
    {
        return [
            $employee->id,
            $employee->employee_code,
            $employee->nip ?? '-',
            $employee->name,
            $employee->department,
            $employee->position,
            $employee->employment_status,
            $employee->is_active ? 'Aktif' : 'Nonaktif',
            $employee->created_at ? $employee->created_at->format('d/m/Y H:i') : '-',
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF']],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => ['argb' => 'FF1E293B'] // Slate 800
                ]
            ],
        ];
    }
}
