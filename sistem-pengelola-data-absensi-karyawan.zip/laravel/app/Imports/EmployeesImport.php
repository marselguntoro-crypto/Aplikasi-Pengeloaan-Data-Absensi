<?php

namespace App\Imports;

use App\Models\Employee;
use App\Models\AuditLog;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsErrors;

class EmployeesImport implements 
    ToModel, 
    WithHeadingRow, 
    WithValidation, 
    WithBatchInserts, 
    WithChunkReading, 
    SkipsOnFailure,
    SkipsOnError
{
    use SkipsFailures, SkipsErrors;

    private int $importedCount = 0;
    private int $updatedCount = 0;

    public function model(array $row)
    {
        $code = trim((string)($row['kode_pegawai'] ?? $row['kode'] ?? $row['employee_code'] ?? ''));
        if (empty($code)) {
            return null;
        }

        $nip = trim((string)($row['nip'] ?? ''));
        $name = trim((string)($row['nama_lengkap'] ?? $row['nama'] ?? $row['name'] ?? ''));
        $dept = trim((string)($row['departemen'] ?? $row['unit_kerja'] ?? $row['department'] ?? 'Umum'));
        $pos = trim((string)($row['jabatan'] ?? $row['position'] ?? 'Staff'));
        $status = trim((string)($row['status_kepegawaian'] ?? $row['status'] ?? 'Tetap'));
        
        $activeRaw = strtolower(trim((string)($row['aktif'] ?? $row['is_active'] ?? '1')));
        $isActive = in_array($activeRaw, ['1', 'true', 'ya', 'yes', 'aktif']);

        // Upsert logic berdasarkan employee_code
        $employee = Employee::withTrashed()->where('employee_code', $code)->first();

        if ($employee) {
            if ($employee->trashed()) {
                $employee->restore();
            }
            $employee->update([
                'nip' => !empty($nip) ? $nip : $employee->nip,
                'name' => $name,
                'department' => $dept,
                'position' => $pos,
                'employment_status' => $status,
                'is_active' => $isActive,
            ]);
            $this->updatedCount++;
            return null;
        }

        $this->importedCount++;

        return new Employee([
            'employee_code' => $code,
            'nip' => !empty($nip) ? $nip : null,
            'name' => $name,
            'department' => $dept,
            'position' => $pos,
            'employment_status' => $status,
            'is_active' => $isActive,
        ]);
    }

    public function rules(): array
    {
        return [
            '*.kode_pegawai' => ['sometimes', 'required', 'string'],
            '*.nama_lengkap' => ['sometimes', 'required', 'string'],
        ];
    }

    public function batchSize(): int
    {
        return 250;
    }

    public function chunkSize(): int
    {
        return 500;
    }

    public function getImportedCount(): int
    {
        return $this->importedCount;
    }

    public function getUpdatedCount(): int
    {
        return $this->updatedCount;
    }
}
