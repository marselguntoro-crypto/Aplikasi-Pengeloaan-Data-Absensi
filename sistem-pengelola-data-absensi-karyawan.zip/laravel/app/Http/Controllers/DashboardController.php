<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\AttendanceDaily;
use App\Models\AttendanceRaw;
use App\Models\WorkCalendar;
use App\Models\Setting;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // Default tanggal: hari ini (WIB / Asia/Jakarta)
        $selectedDate = $request->input('date', Carbon::now('Asia/Jakarta')->toDateString());
        $carbonDate = Carbon::parse($selectedDate);

        // 1. Status Kalender Kerja untuk tanggal terpilih
        $calendar = WorkCalendar::with(['holiday', 'schedule'])
            ->where('calendar_date', $carbonDate->toDateString())
            ->first();

        $isWorkingDay = $calendar ? $calendar->is_working_day : (!$carbonDate->isWeekend());
        $dayStatus = $calendar && $calendar->holiday
            ? $calendar->holiday->holiday_name
            : ($isWorkingDay ? 'HARI KERJA' : 'HARI LIBUR / AKHIR PEKAN');

        // 2. Statistik Pegawai
        $totalEmployees = Employee::where('is_active', true)->count();

        // 3. Rekap Kehadiran Harian
        $dailyRecords = AttendanceDaily::with('employee')
            ->where('attendance_date', $carbonDate->toDateString())
            ->get();

        $stats = [
            'total_pegawai' => $totalEmployees,
            'hadir_tepat_waktu' => $dailyRecords->where('attendance_status', 'HADIR TEPAT WAKTU')->count(),
            'terlambat' => $dailyRecords->filter(fn($r) => str_contains($r->attendance_status, 'TERLAMBAT'))->count(),
            'pulang_cepat' => $dailyRecords->filter(fn($r) => str_contains($r->attendance_status, 'PULANG CEPAT'))->count(),
            'tidak_absen_masuk' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN MASUK')->count(),
            'tidak_absen_pulang' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN PULANG')->count(),
            'tidak_hadir' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN MASUK & PULANG')->count(),
            'libur' => $dailyRecords->filter(fn($r) => in_array($r->attendance_status, ['LIBUR NASIONAL', 'CUTI BERSAMA', 'LIBUR KHUSUS']))->count(),
            'total_potongan' => $dailyRecords->sum('total_penalty'),
        ];

        // 4. Data Transaksi Mentah Terbaru (50 baris terakhir)
        $recentRaw = AttendanceRaw::with('employee')
            ->where('attendance_date', $carbonDate->toDateString())
            ->orderBy('attendance_time', 'desc')
            ->take(15)
            ->get();

        // 5. Pengaturan Aturan Jam & Denda Aktif
        $rules = [
            'clock_in' => Setting::get('work_start_time', '08:15'),
            'clock_out_mon_thu' => Setting::get('work_end_time_mon_thu', '16:30'),
            'clock_out_fri' => Setting::get('work_end_time_fri', '17:00'),
            'late_threshold' => Setting::get('late_threshold_minutes', 60),
            'late_under' => Setting::get('late_penalty_under_threshold', 7500),
            'late_over' => Setting::get('late_penalty_over_threshold', 10000),
            'early_leave' => Setting::get('early_leave_penalty', 10000),
            'missing_in' => Setting::get('missing_in_penalty', 10000),
            'missing_out' => Setting::get('missing_out_penalty', 10000),
            'missing_both' => Setting::get('missing_both_penalty', 20000),
        ];

        return view('dashboard.index', compact(
            'selectedDate',
            'carbonDate',
            'calendar',
            'isWorkingDay',
            'dayStatus',
            'stats',
            'dailyRecords',
            'recentRaw',
            'rules'
        ));
    }
}
