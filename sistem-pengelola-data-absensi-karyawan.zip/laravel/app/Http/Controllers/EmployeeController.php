<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\AuditLog;
use App\Http\Requests\StoreEmployeeRequest;
use App\Http\Requests\UpdateEmployeeRequest;
use App\Imports\EmployeesImport;
use App\Exports\EmployeesExport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $department = $request->input('department');
        $status = $request->input('status'); // '1' = aktif, '0' = nonaktif, null = all

        $query = Employee::query();

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('employee_code', 'like', "%{$search}%")
                  ->orWhere('nip', 'like', "%{$search}%")
                  ->orWhere('position', 'like', "%{$search}%");
            });
        }

        if ($department) {
            $query->where('department', $department);
        }

        if ($status !== null && $status !== '') {
            $query->where('is_active', (bool)$status);
        }

        $employees = $query->orderBy('department')
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        // Statistik Ringkas
        $stats = [
            'total' => Employee::count(),
            'active' => Employee::where('is_active', true)->count(),
            'inactive' => Employee::where('is_active', false)->count(),
            'departments' => Employee::distinct('department')->count('department'),
        ];

        $departmentList = Employee::distinct()->pluck('department')->filter()->values();

        return view('employees.index', compact('employees', 'stats', 'departmentList', 'search', 'department', 'status'));
    }

    public function create()
    {
        $departments = [
            'Sekretariat',
            'Bagian Keuangan & Aset',
            'Bagian Kepegawaian & SDM',
            'Teknologi Informasi & Sistem',
            'Perencanaan & Evaluasi',
            'Hukum & Humas',
            'Operasional Lapangan'
        ];

        $statuses = ['PNS', 'PPPK', 'Tetap', 'Kontrak', 'Magang'];

        return view('employees.create', compact('departments', 'statuses'));
    }

    public function store(StoreEmployeeRequest $request)
    {
        $validated = $request->validated();
        $validated['is_active'] = $request->boolean('is_active', true);

        $employee = Employee::create($validated);

        // Audit Trail
        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'CREATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'new_values' => $employee->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Pegawai '{$employee->name}' ({$employee->employee_code}) berhasil ditambahkan.");
    }

    public function show(Employee $employee)
    {
        $employee->load([
            'attendanceDaily' => function ($q) {
                $q->latest('attendance_date')->limit(15);
            }
        ]);

        // Rekapitulasi absensi pegawai
        $attendanceStats = [
            'total_recorded' => $employee->attendanceDaily()->count(),
            'on_time' => $employee->attendanceDaily()->where('attendance_status', 'HADIR TEPAT WAKTU')->count(),
            'late' => $employee->attendanceDaily()->where('late_minutes', '>', 0)->count(),
            'missing_in_out' => $employee->attendanceDaily()->where(function ($q) {
                $q->whereNull('first_in')->orWhereNull('last_out');
            })->count(),
            'total_penalties' => $employee->attendanceDaily()->sum('total_penalty'),
        ];

        return view('employees.show', compact('employee', 'attendanceStats'));
    }

    public function edit(Employee $employee)
    {
        $departments = [
            'Sekretariat',
            'Bagian Keuangan & Aset',
            'Bagian Kepegawaian & SDM',
            'Teknologi Informasi & Sistem',
            'Perencanaan & Evaluasi',
            'Hukum & Humas',
            'Operasional Lapangan'
        ];

        $statuses = ['PNS', 'PPPK', 'Tetap', 'Kontrak', 'Magang'];

        return view('employees.edit', compact('employee', 'departments', 'statuses'));
    }

    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {
        $oldValues = $employee->toArray();
        $validated = $request->validated();
        $validated['is_active'] = $request->boolean('is_active');

        $employee->update($validated);

        // Audit Trail
        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'UPDATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => $oldValues,
            'new_values' => $employee->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Data pegawai '{$employee->name}' berhasil diperbarui.");
    }

    public function destroy(Request $request, Employee $employee)
    {
        $oldValues = $employee->toArray();
        $name = $employee->name;
        $employee->delete(); // Soft delete

        // Audit Trail
        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'DELETE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => $oldValues,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Pegawai '{$name}' berhasil dinonaktifkan / dihapus (Soft Delete).");
    }

    public function toggleStatus(Request $request, Employee $employee)
    {
        $oldStatus = $employee->is_active;
        $employee->is_active = !$oldStatus;
        $employee->save();

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => $employee->is_active ? 'ACTIVATE_EMPLOYEE' : 'DEACTIVATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => ['is_active' => $oldStatus],
            'new_values' => ['is_active' => $employee->is_active],
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        $statusText = $employee->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return redirect()->back()->with('success', "Status pegawai '{$employee->name}' berhasil {$statusText}.");
    }

    public function importView()
    {
        return view('employees.import');
    }

    public function import(Request $request)
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx,xls,csv', 'max:10240'], // max 10MB
        ]);

        try {
            $import = new EmployeesImport();
            Excel::import($import, $request->file('file'));

            $imported = $import->getImportedCount();
            $updated = $import->getUpdatedCount();
            $failures = count($import->failures());

            AuditLog::create([
                'user_id' => auth()->id(),
                'action' => 'IMPORT_EMPLOYEES',
                'module' => 'EMPLOYEES',
                'new_values' => [
                    'imported' => $imported,
                    'updated' => $updated,
                    'failures' => $failures,
                    'filename' => $request->file('file')->getClientOriginalName(),
                ],
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            return redirect()->route('employees.index')
                ->with('success', "Import berhasil! {$imported} pegawai baru ditambahkan, {$updated} diperbarui. (Gagal: {$failures})");
        } catch (\Exception $e) {
            return redirect()->back()->with('error', "Gagal mengimpor file: " . $e->getMessage());
        }
    }

    public function export(Request $request)
    {
        $search = $request->input('search');
        $department = $request->input('department');
        $status = $request->input('status');

        $filename = 'data_pegawai_' . now()->format('Ymd_His') . '.xlsx';

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'EXPORT_EMPLOYEES',
            'module' => 'EMPLOYEES',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return Excel::download(new EmployeesExport($search, $department, $status), $filename);
    }
}
