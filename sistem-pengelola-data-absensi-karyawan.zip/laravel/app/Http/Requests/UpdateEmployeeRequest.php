<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->isOperator();
    }

    public function rules(): array
    {
        $employeeId = $this->route('employee')?->id ?? $this->route('employee');

        return [
            'employee_code' => [
                'required',
                'string',
                'max:50',
                Rule::unique('employees', 'employee_code')->ignore($employeeId)->withoutTrashed(),
            ],
            'nip' => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('employees', 'nip')->ignore($employeeId)->withoutTrashed(),
            ],
            'name' => ['required', 'string', 'max:255'],
            'department' => ['required', 'string', 'max:100'],
            'position' => ['required', 'string', 'max:100'],
            'employment_status' => ['required', 'string', Rule::in(['PNS', 'PPPK', 'Tetap', 'Kontrak', 'Magang'])],
            'is_active' => ['boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'employee_code.required' => 'Kode Pegawai wajib diisi.',
            'employee_code.unique' => 'Kode Pegawai sudah digunakan oleh pegawai lain.',
            'nip.unique' => 'NIP sudah terdaftar di sistem.',
            'name.required' => 'Nama lengkap pegawai wajib diisi.',
            'department.required' => 'Unit / Departemen wajib dipilih.',
            'position.required' => 'Jabatan wajib diisi.',
            'employment_status.required' => 'Status kepegawaian wajib dipilih.',
        ];
    }
}
