<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Holiday extends Model
{
    use HasFactory;

    protected $fillable = [
        'holiday_date',
        'holiday_name',
        'holiday_type',
        'description',
    ];

    protected $casts = [
        'holiday_date' => 'date',
    ];

    public function calendars()
    {
        return $this->hasMany(WorkCalendar::class, 'holiday_id');
    }
}
