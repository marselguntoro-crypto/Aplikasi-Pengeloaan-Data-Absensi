<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkSchedule extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'day_type',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'saturday',
        'sunday',
        'clock_in',
        'clock_out',
        'friday_clock_out',
        'late_threshold_minutes',
        'late_penalty_under_threshold',
        'late_penalty_over_threshold',
        'early_leave_penalty',
        'missing_in_penalty',
        'missing_out_penalty',
        'missing_both_penalty',
        'is_active',
    ];

    protected $casts = [
        'monday' => 'boolean',
        'tuesday' => 'boolean',
        'wednesday' => 'boolean',
        'thursday' => 'boolean',
        'friday' => 'boolean',
        'saturday' => 'boolean',
        'sunday' => 'boolean',
        'is_active' => 'boolean',
        'late_threshold_minutes' => 'integer',
        'late_penalty_under_threshold' => 'decimal:2',
        'late_penalty_over_threshold' => 'decimal:2',
        'early_leave_penalty' => 'decimal:2',
        'missing_in_penalty' => 'decimal:2',
        'missing_out_penalty' => 'decimal:2',
        'missing_both_penalty' => 'decimal:2',
    ];

    public function calendars()
    {
        return $this->hasMany(WorkCalendar::class, 'schedule_id');
    }
}
