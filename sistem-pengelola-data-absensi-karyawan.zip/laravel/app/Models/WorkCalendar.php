<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkCalendar extends Model
{
    use HasFactory;

    protected $table = 'work_calendars';

    protected $fillable = [
        'calendar_date',
        'day_name',
        'is_working_day',
        'holiday_id',
        'schedule_id',
        'description',
    ];

    protected $casts = [
        'calendar_date' => 'date',
        'is_working_day' => 'boolean',
    ];

    public function holiday()
    {
        return $this->belongsTo(Holiday::class, 'holiday_id');
    }

    public function schedule()
    {
        return $this->belongsTo(WorkSchedule::class, 'schedule_id');
    }
}
