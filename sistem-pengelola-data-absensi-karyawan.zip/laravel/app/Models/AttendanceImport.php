<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceImport extends Model
{
    use HasFactory;

    protected $fillable = [
        'filename',
        'original_filename',
        'file_path',
        'uploaded_by',
        'total_rows',
        'success_rows',
        'duplicate_rows',
        'failed_rows',
        'status',
        'notes',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function logs()
    {
        return $this->hasMany(AttendanceImportLog::class, 'import_id');
    }

    public function rawAttendances()
    {
        return $this->hasMany(AttendanceRaw::class, 'import_id');
    }
}
