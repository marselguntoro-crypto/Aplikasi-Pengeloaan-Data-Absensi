<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceRaw extends Model
{
    use HasFactory;

    protected $table = 'attendance_raw';

    protected $fillable = [
        'employee_id',
        'employee_code',
        'employee_name',
        'attendance_date',
        'attendance_time',
        'attendance_type',
        'machine_id',
        'raw_data',
        'import_id',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'raw_data' => 'array',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function import()
    {
        return $this->belongsTo(AttendanceImport::class, 'import_id');
    }
}
