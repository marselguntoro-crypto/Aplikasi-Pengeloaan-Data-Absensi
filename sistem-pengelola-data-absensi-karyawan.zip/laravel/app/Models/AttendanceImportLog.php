<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceImportLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'import_id',
        'row_number',
        'employee_code',
        'raw_payload',
        'error_message',
        'status',
    ];

    protected $casts = [
        'raw_payload' => 'array',
        'row_number' => 'integer',
    ];

    public function import()
    {
        return $this->belongsTo(AttendanceImport::class, 'import_id');
    }
}
