<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceDaily extends Model
{
    use HasFactory;

    protected $table = 'attendance_daily';

    protected $fillable = [
        'employee_id',
        'attendance_date',
        'schedule_in',
        'schedule_out',
        'first_in',
        'last_out',
        'late_minutes',
        'early_leave_minutes',
        'attendance_status',
        'late_penalty',
        'early_leave_penalty',
        'missing_in_penalty',
        'missing_out_penalty',
        'total_penalty',
        'notes',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'late_minutes' => 'integer',
        'early_leave_minutes' => 'integer',
        'late_penalty' => 'decimal:2',
        'early_leave_penalty' => 'decimal:2',
        'missing_in_penalty' => 'decimal:2',
        'missing_out_penalty' => 'decimal:2',
        'total_penalty' => 'decimal:2',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function deductions()
    {
        return $this->hasMany(Deduction::class, 'attendance_daily_id');
    }
}
