<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Deduction extends Model
{
    use HasFactory;

    protected $fillable = [
        'attendance_daily_id',
        'employee_id',
        'deduction_type',
        'amount',
        'calculation_date',
        'notes',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'calculation_date' => 'date',
    ];

    public function dailyAttendance()
    {
        return $this->belongsTo(AttendanceDaily::class, 'attendance_daily_id');
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }
}
