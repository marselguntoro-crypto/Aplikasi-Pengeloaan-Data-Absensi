<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceAdjustment extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_id',
        'attendance_date',
        'old_value',
        'new_value',
        'reason',
        'adjusted_by',
        'adjusted_at',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'old_value' => 'array',
        'new_value' => 'array',
        'adjusted_at' => 'datetime',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'adjusted_by');
    }
}
