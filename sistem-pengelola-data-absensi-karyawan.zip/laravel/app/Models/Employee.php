<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'employee_code',
        'nip',
        'name',
        'department',
        'position',
        'employment_status',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function rawAttendances()
    {
        return $this->hasMany(AttendanceRaw::class, 'employee_id');
    }

    public function dailyAttendances()
    {
        return $this->hasMany(AttendanceDaily::class, 'employee_id');
    }

    public function deductions()
    {
        return $this->hasMany(Deduction::class, 'employee_id');
    }

    public function adjustments()
    {
        return $this->hasMany(AttendanceAdjustment::class, 'employee_id');
    }
}
