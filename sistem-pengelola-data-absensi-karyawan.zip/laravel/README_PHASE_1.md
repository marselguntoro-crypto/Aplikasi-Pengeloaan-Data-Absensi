# SISTEM PENGELOLA DATA ABSENSI KARYAWAN (PHASE 1)

## 1. Persyaratan Sistem
- PHP 8.2+
- Composer 2+
- MySQL 8.0+
- Node.js 18+ (NPM / Vite)

## 2. Langkah Instalasi Langkah demi Langkah
1. Clone / Salin file project Laravel.
2. Salin file environment:
   ```bash
   cp .env.example .env
   ```
3. Konfigurasi koneksi MySQL di `.env`:
   ```env
   APP_NAME="SIM-ABSENSI"
   APP_ENV=local
   APP_KEY=
   APP_DEBUG=true
   APP_TIMEZONE=Asia/Jakarta
   APP_URL=http://localhost:8000

   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=db_absensi_karyawan
   DB_USERNAME=root
   DB_PASSWORD=
   ```
4. Install dependensi composer:
   ```bash
   composer install
   ```
5. Generate application key:
   ```bash
   php artisan key:generate
   ```
6. Jalankan Database Migration & Seeder:
   ```bash
   php artisan migrate --seed
   ```
   Atau untuk reset database dari nol:
   ```bash
   php artisan migrate:fresh --seed
   ```
7. Jalankan development server:
   ```bash
   php artisan serve
   ```
   Di terminal terpisah, jalankan build asset (Tailwind / Vite):
   ```bash
   npm install && npm run dev
   ```

## 3. Akun Bawaan Seeder
- **Administrator**: `admin@kepegawaian.go.id` / `AdminAbsensi2026!` (Akses penuh)
- **Operator**: `operator@kepegawaian.go.id` / `OperatorAbsensi2026!` (Import & pengolahan)
- **Viewer**: `viewer@kepegawaian.go.id` / `ViewerAbsensi2026!` (Laporan pimpinan)

## 4. Struktur Database Phase 1
- `users`: Pengguna aplikasi dengan RBAC (admin, operator, viewer)
- `employees`: Data pegawai dengan NIP, Departemen, Soft Deletes
- `holidays`: Hari libur nasional, cuti bersama, libur khusus
- `work_schedules`: Jam kerja (Senin-Kamis 08:15-16:30, Jumat 08:15-17:00) & konfigurasi denda
- `work_calendars`: Kalender kerja harian, penentu status hari kerja vs libur
- `attendance_imports`: Riwayat batch import file .xlsx/.csv
- `attendance_import_logs`: Log detil error & baris import
- `attendance_raw`: Penyimpanan data mentah mesin fingerprint/face recognition
- `attendance_daily`: Hasil kalkulasi harian idempotent (unique `employee_id` + `attendance_date`)
- `attendance_adjustments`: Log koreksi manual administrator (tanpa merusak raw)
- `deductions`: Rincian per jenis potongan
- `settings`: Tabel konfigurasi dinamis key-value
- `audit_logs`: Audit jejak aktivitas user (login, import, perubahan aturan, dsb)
