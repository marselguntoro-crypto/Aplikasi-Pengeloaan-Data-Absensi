<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\WorkSchedule;
use App\Models\WorkCalendar;
use App\Models\Holiday;
use Carbon\Carbon;

class WorkScheduleSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Jadwal Standar (Senin-Kamis: 08:15 - 16:30, Jumat: 08:15 - 17:00, Sabtu-Minggu: Libur)
        $schedule = WorkSchedule::updateOrCreate(
            ['name' => 'Jadwal Standar Kantor (WIB)'],
            [
                'day_type' => 'regular',
                'monday' => true,
                'tuesday' => true,
                'wednesday' => true,
                'thursday' => true,
                'friday' => true,
                'saturday' => false,
                'sunday' => false,
                'clock_in' => '08:15:00',
                'clock_out' => '16:30:00',
                'friday_clock_out' => '17:00:00',
                'late_threshold_minutes' => 60,
                'late_penalty_under_threshold' => 7500.00,
                'late_penalty_over_threshold' => 10000.00,
                'early_leave_penalty' => 10000.00,
                'missing_in_penalty' => 10000.00,
                'missing_out_penalty' => 10000.00,
                'missing_both_penalty' => 20000.00,
                'is_active' => true,
            ]
        );

        // 2. Seeder Contoh Hari Libur Nasional (misal 17 Agustus 2026 Hari Kemerdekaan RI)
        $holiday17Aug = Holiday::updateOrCreate(
            ['holiday_date' => '2026-08-17'],
            [
                'holiday_name' => 'Hari Kemerdekaan Republik Indonesia ke-81',
                'holiday_type' => 'national',
                'description' => 'Libur Nasional Kemerdekaan RI - tidak dikenakan denda absensi',
            ]
        );

        // 3. Generate Kalender Kerja untuk Bulan Berjalan (contoh Agustus 2026)
        $startDate = Carbon::create(2026, 8, 1);
        $endDate = Carbon::create(2026, 8, 31);

        $dayNamesIndo = [
            0 => 'Minggu',
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
        ];

        for ($date = $startDate->copy(); $date->lte($endDate); $date->addDay()) {
            $dayOfWeek = $date->dayOfWeek; // 0 = Sunday, 6 = Saturday
            $isWeekend = ($dayOfWeek === 0 || $dayOfWeek === 6);
            $isAug17 = ($date->toDateString() === '2026-08-17');

            $isWorkingDay = !$isWeekend && !$isAug17;
            $holidayId = $isAug17 ? $holiday17Aug->id : null;
            $desc = $isAug17 ? 'Hari Kemerdekaan RI' : ($isWeekend ? 'Akhir Pekan' : 'Hari Kerja Reguler');

            WorkCalendar::updateOrCreate(
                ['calendar_date' => $date->toDateString()],
                [
                    'day_name' => $dayNamesIndo[$dayOfWeek],
                    'is_working_day' => $isWorkingDay,
                    'holiday_id' => $holidayId,
                    'schedule_id' => $schedule->id,
                    'description' => $desc,
                ]
            );
        }
    }
}
