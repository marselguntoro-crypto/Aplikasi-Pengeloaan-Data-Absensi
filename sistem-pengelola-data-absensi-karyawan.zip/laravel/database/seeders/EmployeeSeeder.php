<?php

namespace Database\Seeders;

use App\Models\Employee;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    public function run(): void
    {
        $employees = [
            [
                'employee_code' => 'PEG001',
                'nip' => '198205122008011005',
                'name' => 'Ahmad Fauzi, S.Kom., M.T.I.',
                'department' => 'Teknologi Informasi & Sistem',
                'position' => 'Kepala Bagian IT & Infrastruktur',
                'employment_status' => 'PNS',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG002',
                'nip' => '198711032011012008',
                'name' => 'Siti Nurhaliza, S.E., M.Ak.',
                'department' => 'Bagian Keuangan & Aset',
                'position' => 'Bendahara Pengeluaran Pembantu',
                'employment_status' => 'PNS',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG003',
                'nip' => '199008242015031002',
                'name' => 'Bambang Trianto, S.Sos.',
                'department' => 'Bagian Kepegawaian & SDM',
                'position' => 'Analis SDM Aparatur Ahli Muda',
                'employment_status' => 'PNS',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG004',
                'nip' => '199302192019022004',
                'name' => 'Dewi Anggraini, S.Si.',
                'department' => 'Perencanaan & Evaluasi',
                'position' => 'Statistisi Ahli Pertama',
                'employment_status' => 'PNS',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG005',
                'nip' => '199507112022031001',
                'name' => 'Eko Prasetyo, S.H.',
                'department' => 'Hukum & Humas',
                'position' => 'Pranata Humas Ahli Pertama',
                'employment_status' => 'PPPK',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG006',
                'nip' => '199604152023022003',
                'name' => 'Fitri Handayani, A.Md.',
                'department' => 'Sekretariat',
                'position' => 'Pengadministrasi Perkantoran',
                'employment_status' => 'PPPK',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG007',
                'nip' => null,
                'name' => 'Guruh Wibowo',
                'department' => 'Operasional Lapangan',
                'position' => 'Teknisi Jaringan & Komunikasi',
                'employment_status' => 'Tetap',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG008',
                'nip' => null,
                'name' => 'Hendra Kusuma',
                'department' => 'Teknologi Informasi & Sistem',
                'position' => 'Programmer Web & Database',
                'employment_status' => 'Kontrak',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG009',
                'nip' => null,
                'name' => 'Intan Permatasari',
                'department' => 'Sekretariat',
                'position' => 'Resepsionis & Layanan Informasi',
                'employment_status' => 'Kontrak',
                'is_active' => true,
            ],
            [
                'employee_code' => 'PEG010',
                'nip' => null,
                'name' => 'Joko Santoso (Pensiun)',
                'department' => 'Bagian Keuangan & Aset',
                'position' => 'Staf Arsip Keuangan (Purna)',
                'employment_status' => 'PNS',
                'is_active' => false,
            ],
        ];

        foreach ($employees as $data) {
            Employee::updateOrCreate(
                ['employee_code' => $data['employee_code']],
                $data
            );
        }
    }
}
