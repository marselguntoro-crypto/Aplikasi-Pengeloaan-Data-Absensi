<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            DefaultUserSeeder::class,
            SettingsSeeder::class,
            WorkScheduleSeeder::class,
            EmployeeSeeder::class,
        ]);
    }
}
