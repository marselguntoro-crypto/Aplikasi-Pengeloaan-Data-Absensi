<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DefaultUserSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Administrator
        User::updateOrCreate(
            ['email' => 'admin@kepegawaian.go.id'],
            [
                'name' => 'Administrator Kepegawaian',
                'password' => Hash::make('AdminAbsensi2026!'),
                'role' => 'admin',
                'is_active' => true,
            ]
        );

        // 2. Operator Absensi
        User::updateOrCreate(
            ['email' => 'operator@kepegawaian.go.id'],
            [
                'name' => 'Operator Data Absensi',
                'password' => Hash::make('OperatorAbsensi2026!'),
                'role' => 'operator',
                'is_active' => true,
            ]
        );

        // 3. Viewer (Pimpinan/Auditor)
        User::updateOrCreate(
            ['email' => 'viewer@kepegawaian.go.id'],
            [
                'name' => 'Viewer Laporan Pimpinan',
                'password' => Hash::make('ViewerAbsensi2026!'),
                'role' => 'viewer',
                'is_active' => true,
            ]
        );
    }
}
