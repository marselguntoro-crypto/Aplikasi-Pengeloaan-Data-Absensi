<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Setting;

class SettingsSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // Jam Kerja
            ['key' => 'work_start_time', 'value' => '08:15', 'group' => 'schedule', 'description' => 'Jam Masuk Kerja Normal (WIB)'],
            ['key' => 'work_end_time_mon_thu', 'value' => '16:30', 'group' => 'schedule', 'description' => 'Jam Pulang Kerja Senin-Kamis (WIB)'],
            ['key' => 'work_end_time_fri', 'value' => '17:00', 'group' => 'schedule', 'description' => 'Jam Pulang Kerja Jumat (WIB)'],
            
            // Aturan Keterlambatan & Denda
            ['key' => 'late_threshold_minutes', 'value' => '60', 'group' => 'penalty', 'description' => 'Ambang batas toleransi keterlambatan (menit)'],
            ['key' => 'late_penalty_under_threshold', 'value' => '7500', 'group' => 'penalty', 'description' => 'Denda keterlambatan <= 60 menit (Rp)'],
            ['key' => 'late_penalty_over_threshold', 'value' => '10000', 'group' => 'penalty', 'description' => 'Denda keterlambatan > 60 menit (Rp)'],
            ['key' => 'early_leave_penalty', 'value' => '10000', 'group' => 'penalty', 'description' => 'Denda pulang cepat sebelum jam pulang (Rp)'],
            ['key' => 'missing_in_penalty', 'value' => '10000', 'group' => 'penalty', 'description' => 'Denda tidak absen masuk (ada absen pulang) (Rp)'],
            ['key' => 'missing_out_penalty', 'value' => '10000', 'group' => 'penalty', 'description' => 'Denda tidak absen pulang (ada absen masuk) (Rp)'],
            ['key' => 'missing_both_penalty', 'value' => '20000', 'group' => 'penalty', 'description' => 'Denda tidak absen masuk & pulang pada hari kerja (Rp)'],

            // Sistem
            ['key' => 'institution_name', 'value' => 'Biro Kepegawaian dan Sumber Daya Manusia', 'group' => 'general', 'description' => 'Nama Instansi / Perusahaan'],
            ['key' => 'timezone', 'value' => 'Asia/Jakarta', 'group' => 'general', 'description' => 'Timezone Aplikasi'],
        ];

        foreach ($settings as $item) {
            Setting::updateOrCreate(
                ['key' => $item['key']],
                [
                    'value' => $item['value'],
                    'group' => $item['group'],
                    'description' => $item['description'],
                ]
            );
        }
    }
}
