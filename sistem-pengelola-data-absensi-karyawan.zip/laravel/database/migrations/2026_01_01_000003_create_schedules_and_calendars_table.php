<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('holidays', function (Blueprint $table) {
            $table->id();
            $table->date('holiday_date')->unique();
            $table->string('holiday_name');
            $table->enum('holiday_type', ['national', 'collective_leave', 'special_holiday'])->default('national');
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::create('work_schedules', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('day_type')->default('regular'); // regular, special, shift
            $table->boolean('monday')->default(true);
            $table->boolean('tuesday')->default(true);
            $table->boolean('wednesday')->default(true);
            $table->boolean('thursday')->default(true);
            $table->boolean('friday')->default(true);
            $table->boolean('saturday')->default(false);
            $table->boolean('sunday')->default(false);
            $table->time('clock_in')->default('08:15:00');
            $table->time('clock_out')->default('16:30:00');
            $table->time('friday_clock_out')->default('17:00:00');
            $table->integer('late_threshold_minutes')->default(60);
            $table->decimal('late_penalty_under_threshold', 12, 2)->default(7500.00);
            $table->decimal('late_penalty_over_threshold', 12, 2)->default(10000.00);
            $table->decimal('early_leave_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_in_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_out_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_both_penalty', 12, 2)->default(20000.00);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('work_calendars', function (Blueprint $table) {
            $table->id();
            $table->date('calendar_date')->unique();
            $table->string('day_name', 20); // Senin, Selasa, ...
            $table->boolean('is_working_day')->default(true)->index();
            $table->foreignId('holiday_id')->nullable()->constrained('holidays')->nullOnDelete();
            $table->foreignId('schedule_id')->nullable()->constrained('work_schedules')->nullOnDelete();
            $table->string('description')->nullable();
            $table->timestamps();
            $table->index(['calendar_date', 'is_working_day']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('work_calendars');
        Schema::dropIfExists('work_schedules');
        Schema::dropIfExists('holidays');
    }
};
