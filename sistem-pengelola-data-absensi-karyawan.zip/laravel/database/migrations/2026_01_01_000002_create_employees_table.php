<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('employee_code', 50)->unique();
            $table->string('nip', 50)->nullable()->index();
            $table->string('name');
            $table->string('department', 100)->nullable()->index();
            $table->string('position', 100)->nullable();
            $table->string('employment_status', 50)->default('Tetap'); // Tetap, Kontrak, Magang, dll
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
