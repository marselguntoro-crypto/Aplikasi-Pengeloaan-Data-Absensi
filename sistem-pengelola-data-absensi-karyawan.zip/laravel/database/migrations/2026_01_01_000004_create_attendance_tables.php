<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Imports
        Schema::create('attendance_imports', function (Blueprint $table) {
            $table->id();
            $table->string('filename');
            $table->string('original_filename');
            $table->string('file_path')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->unsignedInteger('total_rows')->default(0);
            $table->unsignedInteger('success_rows')->default(0);
            $table->unsignedInteger('duplicate_rows')->default(0);
            $table->unsignedInteger('failed_rows')->default(0);
            $table->enum('status', ['pending', 'processing', 'completed', 'failed'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        // 2. Import Logs
        Schema::create('attendance_import_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('import_id')->constrained('attendance_imports')->cascadeOnDelete();
            $table->unsignedInteger('row_number')->nullable();
            $table->string('employee_code', 50)->nullable();
            $table->json('raw_payload')->nullable();
            $table->text('error_message')->nullable();
            $table->enum('status', ['success', 'duplicate', 'failed', 'employee_not_found'])->default('success');
            $table->timestamps();
        });

        // 3. Raw Data
        Schema::create('attendance_raw', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->nullable()->constrained('employees')->nullOnDelete();
            $table->string('employee_code', 50)->index();
            $table->string('employee_name')->nullable();
            $table->date('attendance_date')->index();
            $table->time('attendance_time');
            $table->string('attendance_type', 20)->nullable(); // IN, OUT, Check In, Check Out
            $table->string('machine_id', 50)->nullable();
            $table->json('raw_data')->nullable();
            $table->foreignId('import_id')->nullable()->constrained('attendance_imports')->nullOnDelete();
            $table->timestamps();

            // Mencegah duplikasi data mentah
            $table->unique(
                ['employee_code', 'attendance_date', 'attendance_time', 'machine_id'],
                'unique_raw_attendance_record'
            );
        });

        // 4. Daily Attendance
        Schema::create('attendance_daily', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date');

            $table->time('schedule_in')->nullable();
            $table->time('schedule_out')->nullable();

            $table->time('first_in')->nullable();
            $table->time('last_out')->nullable();

            $table->unsignedInteger('late_minutes')->default(0);
            $table->unsignedInteger('early_leave_minutes')->default(0);

            $table->string('attendance_status', 100)->default('HADIR TEPAT WAKTU');

            $table->decimal('late_penalty', 12, 2)->default(0.00);
            $table->decimal('early_leave_penalty', 12, 2)->default(0.00);
            $table->decimal('missing_in_penalty', 12, 2)->default(0.00);
            $table->decimal('missing_out_penalty', 12, 2)->default(0.00);

            $table->decimal('total_penalty', 12, 2)->default(0.00);

            $table->text('notes')->nullable();
            $table->timestamps();

            // Sesuai requirement spesifikasi: Unique index employee_id + attendance_date
            $table->unique(['employee_id', 'attendance_date'], 'unique_emp_daily_attendance');
            $table->index(['attendance_date', 'attendance_status']);
        });

        // 5. Attendance Adjustments (Koreksi manual tanpa mengubah raw data)
        Schema::create('attendance_adjustments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date');
            $table->json('old_value')->nullable();
            $table->json('new_value')->nullable();
            $table->text('reason');
            $table->foreignId('adjusted_by')->constrained('users');
            $table->timestamp('adjusted_at');
            $table->timestamps();
        });

        // 6. Deductions
        Schema::create('deductions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('attendance_daily_id')->constrained('attendance_daily')->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->string('deduction_type', 50); // late, early_leave, missing_in, missing_out, missing_both
            $table->decimal('amount', 12, 2);
            $table->date('calculation_date');
            $table->string('notes')->nullable();
            $table->timestamps();
            $table->index(['employee_id', 'calculation_date']);
        });

        // 7. Settings
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->string('group', 50)->default('general');
            $table->string('description')->nullable();
            $table->timestamps();
        });

        // 8. Audit Logs
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('action', 100); // login, logout, import, generate, correction, settings_update
            $table->string('module', 50);  // auth, attendance, employee, calendar, settings
            $table->string('record_id')->nullable();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->timestamps();
            $table->index(['module', 'action', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('settings');
        Schema::dropIfExists('deductions');
        Schema::dropIfExists('attendance_adjustments');
        Schema::dropIfExists('attendance_daily');
        Schema::dropIfExists('attendance_raw');
        Schema::dropIfExists('attendance_import_logs');
        Schema::dropIfExists('attendance_imports');
    }
};
