import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { getSupabase, getSupabaseConfig, testSupabaseConnection } from './src/server/supabase.js';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ==========================================
// SUPABASE API ROUTES
// ==========================================

// Health / Connection Check
app.get('/api/supabase/status', async (req: Request, res: Response) => {
  try {
    const result = await testSupabaseConnection();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({
      connected: false,
      message: error.message || 'Internal server error checking Supabase',
      error: String(error),
    });
  }
});

// Get Config Details (Masked key for security)
app.get('/api/supabase/config', (req: Request, res: Response) => {
  const config = getSupabaseConfig();
  const maskedKey = config.key 
    ? `${config.key.substring(0, 10)}...${config.key.substring(config.key.length - 6)}` 
    : '';

  res.json({
    url: config.url,
    isConfigured: config.isConfigured,
    maskedKey,
    hasServiceRole: config.key.startsWith('sb_secret_') || config.key.includes('service_role'),
  });
});

// Inspect Tables in Supabase
app.get('/api/supabase/tables', async (req: Request, res: Response) => {
  try {
    const status = await testSupabaseConnection();
    if (!status.connected) {
      return res.status(502).json({ error: 'Supabase is not connected', details: status.message });
    }

    const client = getSupabase();
    if (!client) {
      return res.status(500).json({ error: 'Supabase client could not be initialized' });
    }

    // Check presence of specific attendance tables
    const tableChecks = ['employees', 'attendance_raw', 'attendance_daily', 'deductions'];
    const detected: Record<string, { exists: boolean; count: number; error?: string }> = {};

    for (const table of tableChecks) {
      try {
        const { data, error, count } = await client
          .from(table)
          .select('*', { count: 'exact' })
          .limit(1);

        if (error) {
          detected[table] = { exists: false, count: 0, error: error.message };
        } else {
          detected[table] = { exists: true, count: count ?? (data?.length || 0) };
        }
      } catch (err: any) {
        detected[table] = { exists: false, count: 0, error: err.message };
      }
    }

    res.json({
      connected: true,
      url: status.url,
      openApiTables: status.tables || [],
      attendanceTables: detected,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch Rows from a Supabase Table
app.get('/api/supabase/data/:table', async (req: Request, res: Response) => {
  const { table } = req.params;
  const client = getSupabase();
  if (!client) {
    return res.status(500).json({ error: 'Supabase client is not available' });
  }

  try {
    const limit = Math.min(Number(req.query.limit) || 50, 200);
    const { data, error } = await client.from(table).select('*').limit(limit);

    if (error) {
      return res.status(400).json({ error: error.message, code: error.code });
    }

    res.json({ table, count: data?.length ?? 0, data });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Upsert User Uploaded Employees into Supabase
app.post('/api/supabase/employees/batch', async (req: Request, res: Response) => {
  const client = getSupabase();
  if (!client) {
    return res.status(500).json({ error: 'Supabase client is not available' });
  }

  const { employees } = req.body;
  if (!Array.isArray(employees) || employees.length === 0) {
    return res.status(400).json({ error: 'Data pegawai harus berupa array dan tidak boleh kosong' });
  }

  const sanitized = employees.map((emp: any) => ({
    employee_code: String(emp.employee_code || emp.code || '').trim(),
    nip: emp.nip ? String(emp.nip).trim() : null,
    name: String(emp.name || '').trim(),
    department: String(emp.department || 'Umum').trim(),
    position: String(emp.position || 'Staf').trim(),
    employee_type: String(emp.employment_status || emp.employee_type || 'PNS').trim(),
    is_active: emp.is_active ?? true,
  })).filter((e: any) => e.employee_code && e.name);

  if (sanitized.length === 0) {
    return res.status(400).json({ error: 'Tidak ada baris pegawai yang valid (wajib memiliki kode dan nama)' });
  }

  try {
    const { data, error } = await client
      .from('employees')
      .upsert(sanitized, { onConflict: 'employee_code' })
      .select();

    if (error) {
      return res.status(400).json({ success: false, error: error.message });
    }

    res.json({
      success: true,
      message: `Berhasil menyimpan ${data?.length || sanitized.length} peserta ke Supabase`,
      count: data?.length || sanitized.length,
      data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Insert/Sync Sample Employees into Supabase
app.post('/api/supabase/seed-employees', async (req: Request, res: Response) => {
  const client = getSupabase();
  if (!client) {
    return res.status(500).json({ error: 'Supabase client is not available' });
  }

  const sampleEmployees = [
    {
      nip: '198503152010011012',
      employee_code: 'EMP-001',
      name: 'Dr. Hendra Kusuma, S.Kom., M.T.',
      department: 'Dinas Komunikasi dan Informatika',
      position: 'Kepala Bidang Infrastruktur & Keamanan Informasi',
      employee_type: 'PNS',
      is_active: true,
    },
    {
      nip: '199008212014032005',
      employee_code: 'EMP-002',
      name: 'Rina Kartika, S.STP',
      department: 'Badan Kepegawaian dan PSDM',
      position: 'Analis Kepegawaian Ahli Muda',
      employee_type: 'PNS',
      is_active: true,
    },
    {
      nip: '199512102022211003',
      employee_code: 'EMP-003',
      name: 'Budi Santoso, S.T.',
      department: 'Dinas Pekerjaan Umum dan Penataan Ruang',
      position: 'Teknik Pengairan Pertama',
      employee_type: 'PPPK',
      is_active: true,
    },
    {
      nip: '199204052019022008',
      employee_code: 'EMP-004',
      name: 'Dewi Anggraini, S.E.',
      department: 'Badan Pengelolaan Keuangan dan Aset Daerah',
      position: 'Pengelola Gaji dan Tunjangan',
      employee_type: 'PNS',
      is_active: true,
    },
    {
      nip: '199806142023211009',
      employee_code: 'EMP-005',
      name: 'Ahmad Fauzi, S.Kom.',
      department: 'Dinas Komunikasi dan Informatika',
      position: 'Pranata Komputer Pertama',
      employee_type: 'PPPK',
      is_active: true,
    },
    {
      nip: '198711032011012014',
      employee_code: 'EMP-006',
      name: 'Siti Nurhaliza, S.Sos.',
      department: 'Dinas Penanaman Modal & Pelayanan Terpadu',
      position: 'Penata Perizinan Ahli Madya',
      employee_type: 'PNS',
      is_active: true,
    },
  ];

  try {
    const { data, error } = await client
      .from('employees')
      .upsert(sampleEmployees, { onConflict: 'employee_code' })
      .select();

    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
        hint: 'Pastikan tabel "employees" sudah dibuat di Supabase SQL Editor.',
      });
    }

    res.json({
      success: true,
      message: `Berhasil sinkronisasi ${data?.length || sampleEmployees.length} pegawai ke Supabase.`,
      data,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Provide SQL DDL Schema Script for Supabase SQL Editor
app.get('/api/supabase/sql-schema', (req: Request, res: Response) => {
  const sqlScript = `-- SKRIP DDL POSTGRESQL UNTUK SUPABASE
-- Sistem Pengelola Data Absensi & Potongan Denda Tukin

-- 1. Tabel Master Pegawai
CREATE TABLE IF NOT EXISTS public.employees (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    nip VARCHAR(30) UNIQUE NOT NULL,
    employee_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    position VARCHAR(255) NOT NULL,
    employee_type VARCHAR(20) DEFAULT 'PNS',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Tabel Raw Absensi Mesin / Fingerprint
CREATE TABLE IF NOT EXISTS public.attendance_raw (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL REFERENCES public.employees(employee_code) ON DELETE CASCADE,
    attendance_date DATE NOT NULL,
    attendance_time TIME NOT NULL,
    attendance_type VARCHAR(20), -- 'IN', 'OUT'
    machine_id VARCHAR(50),
    raw_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    CONSTRAINT unique_raw_scan UNIQUE (employee_code, attendance_date, attendance_time, machine_id)
);

-- 3. Tabel Rekonsiliasi Harian
CREATE TABLE IF NOT EXISTS public.attendance_daily (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL REFERENCES public.employees(employee_code) ON DELETE CASCADE,
    attendance_date DATE NOT NULL,
    first_in TIME,
    last_out TIME,
    total_scans INT DEFAULT 0,
    attendance_status VARCHAR(50) NOT NULL,
    late_minutes INT DEFAULT 0,
    early_departure_minutes INT DEFAULT 0,
    total_penalty DECIMAL(12, 2) DEFAULT 0,
    is_locked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    CONSTRAINT unique_daily_attendance UNIQUE (employee_code, attendance_date)
);

-- 4. Tabel Rincian Potongan Denda Tukin
CREATE TABLE IF NOT EXISTS public.deductions (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    daily_attendance_id BIGINT REFERENCES public.attendance_daily(id) ON DELETE CASCADE,
    employee_code VARCHAR(50) NOT NULL REFERENCES public.employees(employee_code) ON DELETE CASCADE,
    deduction_date DATE NOT NULL,
    violation_type VARCHAR(100) NOT NULL,
    duration_minutes INT DEFAULT 0,
    penalty_amount DECIMAL(12, 2) NOT NULL,
    slip_number VARCHAR(100),
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS (Row Level Security) jika diperlukan
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_raw ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_daily ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deductions ENABLE ROW LEVEL SECURITY;

-- Kebijakan Akses Penuh untuk Service Role Key
CREATE POLICY "Full access for service role" ON public.employees FOR ALL USING (true);
CREATE POLICY "Full access for service role" ON public.attendance_raw FOR ALL USING (true);
CREATE POLICY "Full access for service role" ON public.attendance_daily FOR ALL USING (true);
CREATE POLICY "Full access for service role" ON public.deductions FOR ALL USING (true);
`;

  res.json({
    title: 'Skrip DDL Schema Supabase (PostgreSQL)',
    instructions: 'Buka Dashboard Supabase -> Masuk ke SQL Editor -> Paste skrip ini -> Klik Run.',
    sql: sqlScript,
  });
});

// ==========================================
// VITE & STATIC SERVING CONFIGURATION
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✓ Sistem Absensi server running on http://0.0.0.0:${PORT}`);
    console.log(`✓ Supabase Target: https://vwzzhkbivgsptcldodor.supabase.co`);
  });
}

startServer();
