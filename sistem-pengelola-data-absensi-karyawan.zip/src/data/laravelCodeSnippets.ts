export interface CodeFile {
  title: string;
  category: 'Migration' | 'Model' | 'Seeder' | 'Controller' | 'View' | 'Route & Config' | 'Artisan & CLI' | 'Service';
  path: string;
  description: string;
  code: string;
}

export const LARAVEL_PHASE1_FILES: CodeFile[] = [
  {
    title: 'Migration: 12 Tabel Inti Absensi',
    category: 'Migration',
    path: 'database/migrations/2026_01_01_000004_create_attendance_tables.php',
    description: 'Menyediakan tabel attendance_raw, attendance_daily, adjustments, deductions, settings, audit_logs dengan unique key employee_id + attendance_date.',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Imports Batch
        Schema::create('attendance_imports', function (Blueprint $table) {
            $table->id();
            $table->string('filename');
            $table->string('original_filename');
            $table->string('file_path')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->unsignedInteger('total_rows')->default(0);
            $table->unsignedInteger('success_rows')->default(0);
            $table->unsignedInteger('duplicate_rows')->default(0);
            $table->unsignedInteger('failed_rows')->default(0);
            $table->enum('status', ['pending', 'processing', 'completed', 'failed'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        // 2. Raw Data Absensi (TIDAK BOLEH BERUBAH)
        Schema::create('attendance_raw', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->nullable()->constrained('employees')->nullOnDelete();
            $table->string('employee_code', 50)->index();
            $table->string('employee_name')->nullable();
            $table->date('attendance_date')->index();
            $table->time('attendance_time');
            $table->string('attendance_type', 20)->nullable(); // IN, OUT
            $table->string('machine_id', 50)->nullable();
            $table->json('raw_data')->nullable();
            $table->foreignId('import_id')->nullable()->constrained('attendance_imports')->nullOnDelete();
            $table->timestamps();

            // Cegah duplikasi transaksi mentah
            $table->unique(
                ['employee_code', 'attendance_date', 'attendance_time', 'machine_id'],
                'unique_raw_attendance_record'
            );
        });

        // 3. Daily Attendance (Hasil Proses Kalkulasi Idempotent)
        Schema::create('attendance_daily', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date');
            $table->time('schedule_in')->nullable();
            $table->time('schedule_out')->nullable();
            $table->time('first_in')->nullable();
            $table->time('last_out')->nullable();
            $table->unsignedInteger('late_minutes')->default(0);
            $table->unsignedInteger('early_leave_minutes')->default(0);
            $table->string('attendance_status', 100)->default('HADIR TEPAT WAKTU');
            $table->decimal('late_penalty', 12, 2)->default(0.00);
            $table->decimal('early_leave_penalty', 12, 2)->default(0.00);
            $table->decimal('missing_in_penalty', 12, 2)->default(0.00);
            $table->decimal('missing_out_penalty', 12, 2)->default(0.00);
            $table->decimal('total_penalty', 12, 2)->default(0.00);
            $table->text('notes')->nullable();
            $table->timestamps();

            // Mencegah duplikasi kalkulasi harian
            $table->unique(['employee_id', 'attendance_date'], 'unique_emp_daily_attendance');
            $table->index(['attendance_date', 'attendance_status']);
        });

        // 4. Koreksi Manual (Audit adjustment)
        Schema::create('attendance_adjustments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date');
            $table->json('old_value')->nullable();
            $table->json('new_value')->nullable();
            $table->text('reason');
            $table->foreignId('adjusted_by')->constrained('users');
            $table->timestamp('adjusted_at');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendance_adjustments');
        Schema::dropIfExists('attendance_daily');
        Schema::dropIfExists('attendance_raw');
        Schema::dropIfExists('attendance_imports');
    }
};`
  },
  {
    title: 'Migration: Jadwal & Kalender Kerja',
    category: 'Migration',
    path: 'database/migrations/2026_01_01_000003_create_schedules_and_calendars_table.php',
    description: 'Tabel work_schedules, holidays, dan work_calendars sebagai acuan mutlak kalkulasi denda & hari libur.',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('holidays', function (Blueprint $table) {
            $table->id();
            $table->date('holiday_date')->unique();
            $table->string('holiday_name');
            $table->enum('holiday_type', ['national', 'collective_leave', 'special_holiday'])->default('national');
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::create('work_schedules', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('day_type')->default('regular');
            $table->boolean('monday')->default(true);
            $table->boolean('tuesday')->default(true);
            $table->boolean('wednesday')->default(true);
            $table->boolean('thursday')->default(true);
            $table->boolean('friday')->default(true);
            $table->boolean('saturday')->default(false);
            $table->boolean('sunday')->default(false);
            $table->time('clock_in')->default('08:15:00');
            $table->time('clock_out')->default('16:30:00');
            $table->time('friday_clock_out')->default('17:00:00');
            $table->integer('late_threshold_minutes')->default(60);
            $table->decimal('late_penalty_under_threshold', 12, 2)->default(7500.00);
            $table->decimal('late_penalty_over_threshold', 12, 2)->default(10000.00);
            $table->decimal('early_leave_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_in_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_out_penalty', 12, 2)->default(10000.00);
            $table->decimal('missing_both_penalty', 12, 2)->default(20000.00);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('work_calendars', function (Blueprint $table) {
            $table->id();
            $table->date('calendar_date')->unique();
            $table->string('day_name', 20);
            $table->boolean('is_working_day')->default(true)->index();
            $table->foreignId('holiday_id')->nullable()->constrained('holidays')->nullOnDelete();
            $table->foreignId('schedule_id')->nullable()->constrained('work_schedules')->nullOnDelete();
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('work_calendars');
        Schema::dropIfExists('work_schedules');
        Schema::dropIfExists('holidays');
    }
};`
  },
  {
    title: 'Model: AttendanceDaily',
    category: 'Model',
    path: 'app/Models/AttendanceDaily.php',
    description: 'Model utama kalkulasi absensi harian dengan relasi Employee dan Deductions.',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;

class AttendanceDaily extends Model
{
    use HasFactory;

    protected $table = 'attendance_daily';

    protected $fillable = [
        'employee_id',
        'attendance_date',
        'schedule_in',
        'schedule_out',
        'first_in',
        'last_out',
        'late_minutes',
        'early_leave_minutes',
        'attendance_status',
        'late_penalty',
        'early_leave_penalty',
        'missing_in_penalty',
        'missing_out_penalty',
        'total_penalty',
        'notes',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'late_minutes' => 'integer',
        'early_leave_minutes' => 'integer',
        'late_penalty' => 'decimal:2',
        'early_leave_penalty' => 'decimal:2',
        'missing_in_penalty' => 'decimal:2',
        'missing_out_penalty' => 'decimal:2',
        'total_penalty' => 'decimal:2',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function deductions()
    {
        return $this->hasMany(Deduction::class, 'attendance_daily_id');
    }
}`
  },
  {
    title: 'Seeder: Default User & Schedules',
    category: 'Seeder',
    path: 'database/seeders/WorkScheduleSeeder.php',
    description: 'Menyiapkan aturan default jam kerja: Senin-Kamis 08:15-16:30, Jumat 08:15-17:00, dan denda keterlambatan.',
    code: `<?php

namespace Database\\Seeders;

use Illuminate\\Database\\Seeder;
use App\\Models\\WorkSchedule;
use App\\Models\\WorkCalendar;
use App\\Models\\Holiday;
use Carbon\\Carbon;

class WorkScheduleSeeder extends Seeder
{
    public function run(): void
    {
        $schedule = WorkSchedule::updateOrCreate(
            ['name' => 'Jadwal Standar Kantor (WIB)'],
            [
                'day_type' => 'regular',
                'monday' => true,
                'tuesday' => true,
                'wednesday' => true,
                'thursday' => true,
                'friday' => true,
                'saturday' => false,
                'sunday' => false,
                'clock_in' => '08:15:00',
                'clock_out' => '16:30:00',
                'friday_clock_out' => '17:00:00',
                'late_threshold_minutes' => 60,
                'late_penalty_under_threshold' => 7500.00,
                'late_penalty_over_threshold' => 10000.00,
                'early_leave_penalty' => 10000.00,
                'missing_in_penalty' => 10000.00,
                'missing_out_penalty' => 10000.00,
                'missing_both_penalty' => 20000.00,
                'is_active' => true,
            ]
        );

        // Contoh Libur Nasional 17 Agustus 2026
        $holiday = Holiday::updateOrCreate(
            ['holiday_date' => '2026-08-17'],
            [
                'holiday_name' => 'Hari Kemerdekaan Republik Indonesia ke-81',
                'holiday_type' => 'national',
                'description' => 'Libur Nasional Kemerdekaan RI - tidak dikenakan denda absensi',
            ]
        );
    }
}`
  },
  {
    title: 'Controller: DashboardController',
    category: 'Controller',
    path: 'app/Http/Controllers/DashboardController.php',
    description: 'Controller untuk menyajikan ringkasan 8 metrik kehadiran, verifikasi kalender kerja, dan transaksi mentah.',
    code: `<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;
use App\\Models\\Employee;
use App\\Models\\AttendanceDaily;
use App\\Models\\AttendanceRaw;
use App\\Models\\WorkCalendar;
use App\\Models\\Setting;
use Carbon\\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $selectedDate = $request->input('date', Carbon::now('Asia/Jakarta')->toDateString());
        $carbonDate = Carbon::parse($selectedDate);

        $calendar = WorkCalendar::with(['holiday', 'schedule'])
            ->where('calendar_date', $carbonDate->toDateString())
            ->first();

        $isWorkingDay = $calendar ? $calendar->is_working_day : (!$carbonDate->isWeekend());
        $dayStatus = $calendar && $calendar->holiday
            ? $calendar->holiday->holiday_name
            : ($isWorkingDay ? 'HARI KERJA' : 'HARI LIBUR / AKHIR PEKAN');

        $totalEmployees = Employee::where('is_active', true)->count();
        $dailyRecords = AttendanceDaily::with('employee')
            ->where('attendance_date', $carbonDate->toDateString())
            ->get();

        $stats = [
            'total_pegawai' => $totalEmployees,
            'hadir_tepat_waktu' => $dailyRecords->where('attendance_status', 'HADIR TEPAT WAKTU')->count(),
            'terlambat' => $dailyRecords->filter(fn($r) => str_contains($r->attendance_status, 'TERLAMBAT'))->count(),
            'pulang_cepat' => $dailyRecords->filter(fn($r) => str_contains($r->attendance_status, 'PULANG CEPAT'))->count(),
            'tidak_absen_masuk' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN MASUK')->count(),
            'tidak_absen_pulang' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN PULANG')->count(),
            'tidak_hadir' => $dailyRecords->where('attendance_status', 'TIDAK ABSEN MASUK & PULANG')->count(),
            'total_potongan' => $dailyRecords->sum('total_penalty'),
        ];

        return view('dashboard.index', compact(
            'selectedDate', 'carbonDate', 'calendar', 'isWorkingDay', 'dayStatus', 'stats'
        ));
    }
}`
  },
  {
    title: 'Controller: MonthlyReportSlipController',
    category: 'Controller',
    path: 'app/Http/Controllers/MonthlyReportSlipController.php',
    description: 'Controller untuk rekapitulasi bulanan, export CSV/Excel, serta generasi slip potongan denda per pegawai (PDF & Excel).',
    code: `<?php

namespace App\\Http\\Controllers;

use App\\Models\\Employee;
use App\\Services\\MonthlyPayrollReportService;
use Barryvdh\\DomPDF\\Facade\\Pdf;
use Illuminate\\Http\\Request;
use Symfony\\Component\\HttpFoundation\\StreamedResponse;

class MonthlyReportSlipController extends Controller
{
    protected MonthlyPayrollReportService $reportService;

    public function __construct(MonthlyPayrollReportService $reportService)
    {
        $this->reportService = $reportService;
    }

    /**
     * Tampilkan Halaman Rekapitulasi Bulanan
     */
    public function index(Request $request)
    {
        $year = (int) $request->input('year', now()->year);
        $month = (int) $request->input('month', now()->month);
        $departmentId = $request->input('department_id');

        $reportData = $this->reportService->generateMonthlyReport($year, $month, $departmentId);

        return view('reports.monthly', compact('reportData', 'year', 'month'));
    }

    /**
     * Unduh Slip Potongan Pegawai format PDF Resmi
     */
    public function downloadSlipPdf(Employee $employee, Request $request)
    {
        $year = (int) $request->input('year', now()->year);
        $month = (int) $request->input('month', now()->month);

        $slipData = $this->reportService->getEmployeeSlipData($employee, $year, $month);

        $pdf = Pdf::loadView('reports.slips.pdf', [
            'employee' => $employee,
            'slip' => $slipData,
            'year' => $year,
            'month' => $month,
        ])->setPaper('a4', 'portrait');

        $filename = sprintf('Slip_Tukin_%s_%s_%04d_%02d.pdf', 
            $employee->employee_code, 
            str_replace(' ', '_', $employee->name),
            $year, 
            $month
        );

        return $pdf->download($filename);
    }

    /**
     * Unduh Slip Potongan Pegawai format Excel (.CSV UTF-8)
     */
    public function downloadSlipExcel(Employee $employee, Request $request): StreamedResponse
    {
        $year = (int) $request->input('year', now()->year);
        $month = (int) $request->input('month', now()->month);

        $slipData = $this->reportService->getEmployeeSlipData($employee, $year, $month);
        $filename = sprintf('Slip_Tukin_%s_%04d_%02d.csv', $employee->employee_code, $year, $month);

        return response()->streamDownload(function () use ($employee, $slipData, $year, $month) {
            $handle = fopen('php://output', 'w');
            // Tambahkan BOM UTF-8 agar karakter terbaca sempurna di Microsoft Excel
            fputs($handle, chr(0xEF).chr(0xBB).chr(0xBF));

            fputcsv($handle, ['PEMERINTAH DAERAH PROVINSI / KOTA']);
            fputcsv($handle, ['BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA (BKPSDM)']);
            fputcsv($handle, ['SLIP RESMI POTONGAN TUNJANGAN KINERJA (TUKIN) ABSENSI']);
            fputcsv($handle, []);
            fputcsv($handle, ['Nama Pegawai', $employee->name]);
            fputcsv($handle, ['NIP', "'".$employee->nip]);
            fputcsv($handle, ['Kode Pegawai', $employee->employee_code]);
            fputcsv($handle, ['Unit Kerja', $employee->department?->name ?? '-']);
            fputcsv($handle, ['Periode', sprintf('%02d/%04d', $month, $year)]);
            fputcsv($handle, []);
            fputcsv($handle, ['No', 'Tanggal', 'Hari', 'Jam Masuk', 'Jam Pulang', 'Pelanggaran', 'Denda (Rp)']);

            $no = 1;
            foreach ($slipData['violations'] as $v) {
                fputcsv($handle, [
                    $no++,
                    $v['date'],
                    $v['day_name'],
                    $v['first_in'] ?? '-',
                    $v['last_out'] ?? '-',
                    $v['violation_type'],
                    $v['amount'],
                ]);
            }

            fputcsv($handle, []);
            fputcsv($handle, ['', '', '', '', '', 'TOTAL POTONGAN DENDA:', $slipData['total_penalty']]);
            fputcsv($handle, ['', '', '', '', '', 'TERBILANG:', $slipData['terbilang']]);
            fclose($handle);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ]);
    }
}`
  },
  {
    title: 'Web Routes: routes/web.php',
    category: 'Route & Config',
    path: 'routes/web.php',
    description: 'Routing rapi untuk Authentication, Dashboard, Pegawai, Raw Attendance, Kalender, dan Laporan.',
    code: `<?php

use Illuminate\\Support\\Facades\\Route;
use App\\Http\\Controllers\\AuthController;
use App\\Http\\Controllers\\DashboardController;

Route::get('/', fn() => redirect()->route('dashboard'));

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::prefix('employees')->name('employees.')->group(function () {
        Route::get('/', fn() => view('employees.index'))->name('index');
        Route::get('/create', fn() => view('employees.create'))->name('create');
    });
    Route::prefix('attendance')->name('attendance.')->group(function () {
        Route::get('/raw', fn() => view('attendance.raw'))->name('raw');
        Route::get('/import', fn() => view('attendance.import'))->name('import');
        Route::get('/calendar', fn() => view('attendance.calendar'))->name('calendar');
        Route::post('/process', fn() => back()->with('success', 'Proses kalkulasi selesai.'))->name('process');
    });
    Route::get('/calendar', fn() => view('calendar.index'))->name('calendar.index');
    Route::get('/reports/monthly', fn() => view('reports.monthly'))->name('reports.monthly');
    Route::get('/reports/deductions', fn() => view('reports.deductions'))->name('reports.deductions');
    Route::get('/settings', fn() => view('settings.index'))->name('settings.index');
    Route::get('/audit-logs', fn() => view('audit_logs.index'))->name('audit_logs.index');
});`
  },
  {
    title: 'Command Artisan & Setup Terminal',
    category: 'Artisan & CLI',
    path: 'artisan-commands.sh',
    description: 'Instruksi instalasi dan artisan command yang harus dijalankan.',
    code: `# 1. Salin environment & buat App Key
cp .env.example .env
composer install
php artisan key:generate

# 2. Setup Database & Jalankan Migration + Seeder
php artisan migrate:fresh --seed

# 3. Jalankan Server Dev & Asset Vite
php artisan serve --port=8000
npm install && npm run dev

# 4. Akun Login Default
# Administrator: admin@kepegawaian.go.id / AdminAbsensi2026!
# Operator: operator@kepegawaian.go.id / OperatorAbsensi2026!
# Viewer: viewer@kepegawaian.go.id / ViewerAbsensi2026!`
  }
];
