import * as XLSX from 'xlsx';

export interface EmployeeRecord {
  id: number;
  employee_code: string;
  nip: string | null;
  name: string;
  department: string;
  position: string;
  employment_status: string;
  is_active: boolean;
  created_at: string;
  stats?: {
    recorded: number;
    onTime: number;
    late: number;
    missing: number;
    penalties: number;
  };
}

const STORAGE_KEY = 'attendance_app_participants_v1';

/**
 * Loads stored employees from localStorage.
 * Defaults to EMPTY ARRAY [] because dummy participants have been removed as requested by user.
 */
export function getStoredEmployees(): EmployeeRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return []; // Clean empty state, no dummy participants
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (e) {
    console.error('Error loading stored participants:', e);
    return [];
  }
}

/**
 * Saves employees to localStorage and notifies other components.
 */
export function saveStoredEmployees(employees: EmployeeRecord[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
    window.dispatchEvent(new CustomEvent('participants_updated', { detail: employees }));
  } catch (e) {
    console.error('Error saving participants:', e);
  }
}

/**
 * Clears all participants from storage.
 */
export function clearStoredEmployees(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
    window.dispatchEvent(new CustomEvent('participants_updated', { detail: [] }));
  } catch (e) {
    console.error('Error clearing participants:', e);
  }
}

/**
 * Generates and downloads a standard CSV template for participant upload.
 */
export function downloadParticipantTemplateCSV(): void {
  const headers = ['kode_pegawai', 'nip', 'nama_lengkap', 'departemen', 'jabatan', 'status_kepegawaian'];
  const sampleRows = [
    ['EMP-001', '198503152010011012', 'Ahmad Fauzi, S.Kom', 'Dinas Komunikasi dan Informatika', 'Pranata Komputer', 'PNS'],
    ['EMP-002', '199008212014032005', 'Siti Rahmawati, S.E', 'Badan Kepegawaian & SDM', 'Analis SDM Aparatur', 'PNS'],
    ['EMP-003', '199512102022211003', 'Budi Santoso, S.T', 'Dinas Pekerjaan Umum', 'Teknik Pertama', 'PPPK'],
  ];

  const csvContent = [
    headers.join(','),
    ...sampleRows.map(row => row.map(cell => `"${cell}"`).join(',')),
  ].join('\r\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'template_upload_peserta.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Generates and downloads a standard Excel (.xlsx) template for participant upload.
 */
export function downloadParticipantTemplateExcel(): void {
  const data = [
    {
      kode_pegawai: 'EMP-001',
      nip: '198503152010011012',
      nama_lengkap: 'Ahmad Fauzi, S.Kom',
      departemen: 'Dinas Komunikasi dan Informatika',
      jabatan: 'Pranata Komputer',
      status_kepegawaian: 'PNS',
    },
    {
      kode_pegawai: 'EMP-002',
      nip: '199008212014032005',
      nama_lengkap: 'Siti Rahmawati, S.E',
      departemen: 'Badan Kepegawaian & SDM',
      jabatan: 'Analis SDM Aparatur',
      status_kepegawaian: 'PNS',
    },
    {
      kode_pegawai: 'EMP-003',
      nip: '199512102022211003',
      nama_lengkap: 'Budi Santoso, S.T',
      departemen: 'Dinas Pekerjaan Umum',
      jabatan: 'Teknik Pertama',
      status_kepegawaian: 'PPPK',
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Peserta');

  XLSX.writeFile(workbook, 'template_upload_peserta.xlsx');
}

/**
 * Pushes participants to Supabase if connected
 */
export async function syncEmployeesToSupabaseApi(employees: EmployeeRecord[]): Promise<{
  success: boolean;
  message: string;
  count?: number;
}> {
  try {
    const res = await fetch('/api/supabase/employees/batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ employees }),
    });
    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, message: err.message };
  }
}
