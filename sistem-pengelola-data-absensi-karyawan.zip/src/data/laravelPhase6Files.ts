import { CodeFile } from './laravelCodeSnippets';

export const LARAVEL_PHASE6_FILES: CodeFile[] = [
  {
    title: 'Migration: Tabel Rekap Harian & Rincian Denda Potongan',
    category: 'Migration',
    path: 'database/migrations/2026_01_01_000006_create_daily_attendance_summaries_and_penalties_tables.php',
    description: 'Menyediakan tabel daily_attendance_summaries dan attendance_penalties untuk menyimpan hasil kalkulasi definitif rekonsiliasi log mentah, status kehadiran, menit keterlambatan, dan denda.',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Tabel Ringkasan Kehadiran Harian Pegawai (Hasil Rekonsiliasi)
        Schema::create('daily_attendance_summaries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->date('attendance_date');
            
            // Waktu Scan Definitif
            $table->time('first_in')->nullable()->comment('Scan masuk valid pertama');
            $table->time('last_out')->nullable()->comment('Scan pulang valid terakhir');
            $table->unsignedInteger('raw_scan_count')->default(0)->comment('Jumlah log mentah yang terdeteksi');

            // Jadwal yang Berlaku pada Tanggal Tersebut
            $table->time('expected_in')->nullable();
            $table->time('expected_out')->nullable();
            $table->boolean('is_workday')->default(true);
            $table->boolean('is_holiday')->default(false);
            $table->string('holiday_name', 150)->nullable();

            // Status Kehadiran
            $table->enum('status', [
                'ONTIME',               // Hadir tepat waktu
                'LATE_UNDER_60',        // Terlambat <= 60 menit (Rp 7.500)
                'LATE_OVER_60',         // Terlambat > 60 menit (Rp 10.000)
                'EARLY_DEPARTURE',      // Pulang cepat (Rp 10.000)
                'LATE_AND_EARLY',       // Terlambat + Pulang cepat
                'MISSING_IN',           // Tidak absen masuk (Rp 10.000)
                'MISSING_OUT',          // Tidak absen pulang (Rp 10.000)
                'ALPHA',                // Tidak hadir tanpa keterangan (Rp 20.000)
                'LEAVE_SICK',           // Sakit berdokumen (Rp 0)
                'LEAVE_ANNUAL',         // Cuti Tahunan (Rp 0)
                'DUTY_EXTERNAL',        // Dinas Luar (Rp 0)
                'HOLIDAY_EXEMPT',       // Libur Nasional / Cuti Bersama (Rp 0)
                'WEEKEND_EXEMPT'        // Libur Akhir Pekan (Rp 0)
            ])->default('ALPHA');

            // Durasi Keterlambatan & Pulang Cepat
            $table->unsignedSmallInteger('late_minutes')->default(0);
            $table->unsignedSmallInteger('early_minutes')->default(0);
            $table->unsignedSmallInteger('work_duration_minutes')->default(0);

            // Akumulasi Denda Rupiah untuk Tanggal Ini
            $table->unsignedDecimal('total_penalty', 12, 2)->default(0.00);

            // Audit & Status Kunci Rekap
            $table->boolean('is_locked')->default(false)->comment('Jika locked, tidak dapat tertimpa auto-reconcile');
            $table->boolean('is_manually_overridden')->default(false);
            $table->text('override_reason')->nullable();
            $table->foreignId('overridden_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('reconciled_at')->nullable();
            $table->timestamps();

            $table->unique(['employee_id', 'attendance_date'], 'unique_emp_attendance_date');
            $table->index(['attendance_date', 'status']);
            $table->index(['attendance_date', 'is_locked']);
        });

        // 2. Tabel Rincian Pelanggaran & Denda (Itemized Penalties)
        Schema::create('attendance_penalties', function (Blueprint $table) {
            $table->id();
            $table->foreignId('daily_summary_id')->constrained('daily_attendance_summaries')->cascadeOnDelete();
            $table->enum('violation_type', [
                'LATE_UNDER_60',    // Rp 7.500
                'LATE_OVER_60',     // Rp 10.000
                'EARLY_DEPARTURE',  // Rp 10.000
                'MISSING_IN',       // Rp 10.000
                'MISSING_OUT',      // Rp 10.000
                'ALPHA'             // Rp 20.000
            ]);
            $table->unsignedDecimal('amount', 10, 2);
            $table->string('description', 255);
            $table->timestamps();

            $table->index('violation_type');
        });

        // 3. Tabel Rekap Bulanan Penggajian & Potongan Tukin
        Schema::create('monthly_payroll_deductions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->unsignedSmallInteger('year');
            $table->unsignedTinyInteger('month');
            
            // Metrik Hari
            $table->unsignedTinyInteger('total_workdays')->default(0);
            $table->unsignedTinyInteger('days_present')->default(0);
            $table->unsignedTinyInteger('days_late')->default(0);
            $table->unsignedTinyInteger('days_early')->default(0);
            $table->unsignedTinyInteger('days_missing_scan')->default(0);
            $table->unsignedTinyInteger('days_alpha')->default(0);
            $table->unsignedTinyInteger('days_approved_leave')->default(0);

            // Total Waktu Pelanggaran
            $table->unsignedInteger('accumulated_late_minutes')->default(0);
            $table->unsignedInteger('accumulated_early_minutes')->default(0);

            // Total Nilai Potongan Tunjangan Kinerja (Tukin)
            $table->unsignedDecimal('total_penalty_amount', 12, 2)->default(0.00);
            $table->enum('payroll_status', ['DRAFT', 'VERIFIED', 'FINALIZED', 'PAID'])->default('DRAFT');
            $table->timestamp('finalized_at')->nullable();
            $table->foreignId('finalized_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->unique(['employee_id', 'year', 'month'], 'unique_emp_monthly_deduction');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('monthly_payroll_deductions');
        Schema::dropIfExists('attendance_penalties');
        Schema::dropIfExists('daily_attendance_summaries');
    }
};`
  },
  {
    title: 'Model: DailyAttendanceSummary (Rekap Harian Definitif)',
    category: 'Model',
    path: 'app/Models/DailyAttendanceSummary.php',
    description: 'Model Eloquent untuk rekapan harian hasil rekonsiliasi yang mencakup status hadir, waktu scan masuk/pulang definitif, denda, dan relasi rincian pelanggaran.',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Carbon\\Carbon;

class DailyAttendanceSummary extends Model
{
    use HasFactory;

    protected $table = 'daily_attendance_summaries';

    protected $fillable = [
        'employee_id',
        'attendance_date',
        'first_in',
        'last_out',
        'raw_scan_count',
        'expected_in',
        'expected_out',
        'is_workday',
        'is_holiday',
        'holiday_name',
        'status',
        'late_minutes',
        'early_minutes',
        'work_duration_minutes',
        'total_penalty',
        'is_locked',
        'is_manually_overridden',
        'override_reason',
        'overridden_by',
        'reconciled_at',
    ];

    protected $casts = [
        'attendance_date' => 'date:Y-m-d',
        'is_workday' => 'boolean',
        'is_holiday' => 'boolean',
        'is_locked' => 'boolean',
        'is_manually_overridden' => 'boolean',
        'late_minutes' => 'integer',
        'early_minutes' => 'integer',
        'work_duration_minutes' => 'integer',
        'total_penalty' => 'float',
        'reconciled_at' => 'datetime',
    ];

    /**
     * Relasi ke Pegawai
     */
    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    /**
     * Relasi ke Rincian Denda
     */
    public function penalties()
    {
        return $this->hasMany(AttendancePenalty::class, 'daily_summary_id');
    }

    /**
     * Relasi ke User pembuat override manual
     */
    public function overrideAuthor()
    {
        return $this->belongsTo(User::class, 'overridden_by');
    }

    /**
     * Label Status Kehadiran dalam Bahasa Indonesia
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'ONTIME' => 'Hadir Tepat Waktu',
            'LATE_UNDER_60' => 'Terlambat ≤ 60 Menit',
            'LATE_OVER_60' => 'Terlambat > 60 Menit',
            'EARLY_DEPARTURE' => 'Pulang Lebih Awal',
            'LATE_AND_EARLY' => 'Terlambat & Pulang Cepat',
            'MISSING_IN' => 'Tidak Absen Masuk',
            'MISSING_OUT' => 'Tidak Absen Pulang',
            'ALPHA' => 'Tidak Hadir (Alpha)',
            'LEAVE_SICK' => 'Sakit Berdokumen',
            'LEAVE_ANNUAL' => 'Cuti Tahunan',
            'DUTY_EXTERNAL' => 'Dinas Luar',
            'HOLIDAY_EXEMPT' => 'Libur Nasional',
            'WEEKEND_EXEMPT' => 'Akhir Pekan',
            default => 'Belum Direkonsiliasi',
        };
    }
}`
  },
  {
    title: 'AttendanceReconciliationService (Engine Inti Rekonsiliasi & Denda)',
    category: 'Service',
    path: 'app/Services/AttendanceReconciliationService.php',
    description: 'Engine komprehensif yang mengekstrak log mentah per tanggal, mengelompokkan scan masuk/pulang, memvalidasi terhadap jadwal & kalender kerja, menerapkan denda berjenjang, dan mencatat transaksi ke database.',
    code: `<?php

namespace App\\Services;

use App\\Models\\Employee;
use App\\Models\\RawAttendanceLog;
use App\\Models\\DailyAttendanceSummary;
use App\\Models\\AttendancePenalty;
use App\\Models\\AuditLog;
use Carbon\\Carbon;
use Illuminate\\Support\\Facades\\DB;
use Illuminate\\Support\\Facades\\Log;

class AttendanceReconciliationService
{
    protected HolidayCalendarService $calendarService;

    // Nilai Nominal Sanksi Denda Instansi (Sesuai Peraturan)
    public const PENALTY_LATE_UNDER_60 = 7500.00;
    public const PENALTY_LATE_OVER_60 = 10000.00;
    public const PENALTY_EARLY_DEPARTURE = 10000.00;
    public const PENALTY_MISSING_IN = 10000.00;
    public const PENALTY_MISSING_OUT = 10000.00;
    public const PENALTY_ALPHA = 20000.00;

    public function __construct(HolidayCalendarService $calendarService)
    {
        $this->calendarService = $calendarService;
    }

    /**
     * Rekonsiliasi seluruh pegawai untuk satu tanggal tertentu
     * 
     * @param string $dateStr Format YYYY-MM-DD
     * @param bool $dryRun Jika true, hanya kalkulasi di memori tanpa commit DB
     * @param int|null $departmentId Filter spesifik unit kerja
     */
    public function reconcileDate(string $dateStr, bool $dryRun = false, ?int $departmentId = null): array
    {
        $date = Carbon::parse($dateStr);
        $dayEval = $this->calendarService->evaluateDate($date);

        // Ambil semua pegawai aktif
        $employeeQuery = Employee::query()->where('is_active', true);
        if ($departmentId) {
            $employeeQuery->where('department_id', $departmentId);
        }
        $employees = $employeeQuery->get();

        // Ambil seluruh log mentah pada tanggal tersebut
        $rawLogs = RawAttendanceLog::whereDate('scan_time', $dateStr)
            ->where('is_processed', false)
            ->orderBy('scan_time', 'asc')
            ->get()
            ->groupBy('employee_id');

        $reconciledRecords = [];
        $totalPenaltiesCount = 0;
        $totalPenaltiesRupiah = 0.00;

        DB::beginTransaction();
        try {
            foreach ($employees as $employee) {
                // Cek apakah summary sudah ada dan berstatus Locked
                $existing = DailyAttendanceSummary::where('employee_id', $employee->id)
                    ->where('attendance_date', $dateStr)
                    ->first();

                if ($existing && $existing->is_locked) {
                    $reconciledRecords[] = $existing;
                    continue; // Skip pegawai yang rekapnya telah dikunci
                }

                // Ambil log mentah pegawai
                $empLogs = $rawLogs->get($employee->id, collect());
                $summaryResult = $this->processEmployeeAttendance($employee, $date, $dayEval, $empLogs);

                $totalPenaltiesCount += count($summaryResult['penalties']);
                $totalPenaltiesRupiah += $summaryResult['total_penalty'];

                if (!$dryRun) {
                    $record = $this->saveDailySummary($employee->id, $dateStr, $summaryResult);
                    $reconciledRecords[] = $record;
                } else {
                    $reconciledRecords[] = [
                        'employee' => $employee->only(['id', 'employee_code', 'nip', 'name', 'department']),
                        ...$summaryResult
                    ];
                }
            }

            if (!$dryRun) {
                // Tandai raw logs sebagai telah diproses
                RawAttendanceLog::whereDate('scan_time', $dateStr)->update(['is_processed' => true]);
                DB::commit();
            } else {
                DB::rollBack();
            }

            return [
                'status' => 'success',
                'date' => $dateStr,
                'dry_run' => $dryRun,
                'is_workday' => $dayEval['is_workday'],
                'day_type' => $dayEval['status_type'],
                'total_employees_processed' => count($employees),
                'total_penalties_issued' => $totalPenaltiesCount,
                'total_penalties_rupiah' => $totalPenaltiesRupiah,
                'data' => $reconciledRecords
            ];

        } catch (\\Exception $e) {
            DB::rollBack();
            Log::error("Attendance reconciliation failed for {$dateStr}: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Engine evaluasi kehadiran individu pegawai
     */
    public function processEmployeeAttendance(Employee $employee, Carbon $date, array $dayEval, $empLogs): array
    {
        // KONDISI 1: Hari Libur Nasional / Cuti Bersama / Weekend -> Otomatis Bebas Denda (Rp 0)
        if (!$dayEval['is_workday']) {
            $isHoliday = in_array($dayEval['status_type'], ['national_holiday', 'joint_leave', 'holiday_override']);
            return [
                'first_in' => $empLogs->first()?->scan_time?->format('H:i:s'),
                'last_out' => $empLogs->last()?->scan_time?->format('H:i:s'),
                'raw_scan_count' => $empLogs->count(),
                'expected_in' => null,
                'expected_out' => null,
                'is_workday' => false,
                'is_holiday' => $isHoliday,
                'holiday_name' => $dayEval['title'],
                'status' => $isHoliday ? 'HOLIDAY_EXEMPT' : 'WEEKEND_EXEMPT',
                'late_minutes' => 0,
                'early_minutes' => 0,
                'work_duration_minutes' => 0,
                'total_penalty' => 0.00,
                'penalties' => []
            ];
        }

        // KONDISI 2: Hari Kerja Reguler
        $expectedInTime = Carbon::parse("{$date->toDateString()} {$dayEval['in_time']}");
        $expectedOutTime = Carbon::parse("{$date->toDateString()} {$dayEval['out_time']}");
        $graceMinutes = $dayEval['grace_period'] ?? 0;

        // Ekstrak first IN dan last OUT dari raw logs
        $inLogs = $empLogs->where('punch_type', 'IN');
        $outLogs = $empLogs->where('punch_type', 'OUT');

        // Fallback: Jika punch_type tidak terdefinisi pada mesin lama, filter berdasarkan jam
        $firstInScan = $inLogs->first()?->scan_time 
            ?? $empLogs->where('scan_time', '<=', "{$date->toDateString()} 12:00:00")->first()?->scan_time;
        
        $lastOutScan = $outLogs->last()?->scan_time 
            ?? $empLogs->where('scan_time', '>=', "{$date->toDateString()} 12:00:01")->last()?->scan_time;

        $penalties = [];
        $lateMinutes = 0;
        $earlyMinutes = 0;

        // Sub-Kondisi A: Tidak scan sama sekali (Alpha)
        if (!$firstInScan && !$lastOutScan) {
            $penalties[] = [
                'violation_type' => 'ALPHA',
                'amount' => self::PENALTY_ALPHA,
                'description' => 'Tidak hadir tanpa keterangan (Alpha hari kerja)',
            ];

            return [
                'first_in' => null,
                'last_out' => null,
                'raw_scan_count' => 0,
                'expected_in' => $dayEval['in_time'],
                'expected_out' => $dayEval['out_time'],
                'is_workday' => true,
                'is_holiday' => false,
                'holiday_name' => null,
                'status' => 'ALPHA',
                'late_minutes' => 0,
                'early_minutes' => 0,
                'work_duration_minutes' => 0,
                'total_penalty' => self::PENALTY_ALPHA,
                'penalties' => $penalties
            ];
        }

        // Sub-Kondisi B: Validasi Masuk (IN)
        if ($firstInScan) {
            $scanInTime = Carbon::parse($firstInScan);
            $effectiveLimit = $expectedInTime->copy()->addMinutes($graceMinutes);

            if ($scanInTime->gt($effectiveLimit)) {
                $lateMinutes = $scanInTime->diffInMinutes($expectedInTime);
                if ($lateMinutes <= 60) {
                    $penalties[] = [
                        'violation_type' => 'LATE_UNDER_60',
                        'amount' => self::PENALTY_LATE_UNDER_60,
                        'description' => "Terlambat {$lateMinutes} menit (≤ 60 menit: Denda Rp 7.500)",
                    ];
                } else {
                    $penalties[] = [
                        'violation_type' => 'LATE_OVER_60',
                        'amount' => self::PENALTY_LATE_OVER_60,
                        'description' => "Terlambat {$lateMinutes} menit (> 60 menit: Denda Rp 10.000)",
                    ];
                }
            }
        } else {
            // Missing IN
            $penalties[] = [
                'violation_type' => 'MISSING_IN',
                'amount' => self::PENALTY_MISSING_IN,
                'description' => 'Tidak melakukan absensi scan masuk kantor',
            ];
        }

        // Sub-Kondisi C: Validasi Pulang (OUT)
        if ($lastOutScan) {
            $scanOutTime = Carbon::parse($lastOutScan);
            if ($scanOutTime->lt($expectedOutTime)) {
                $earlyMinutes = $expectedOutTime->diffInMinutes($scanOutTime);
                $penalties[] = [
                    'violation_type' => 'EARLY_DEPARTURE',
                    'amount' => self::PENALTY_EARLY_DEPARTURE,
                    'description' => "Pulang {$earlyMinutes} menit sebelum jam resmi ({$dayEval['out_time']} WIB)",
                ];
            }
        } else {
            // Missing OUT
            $penalties[] = [
                'violation_type' => 'MISSING_OUT',
                'amount' => self::PENALTY_MISSING_OUT,
                'description' => 'Tidak melakukan absensi scan pulang kantor',
            ];
        }

        // Tentukan Status Final
        $status = 'ONTIME';
        if (!$firstInScan) $status = 'MISSING_IN';
        elseif (!$lastOutScan) $status = 'MISSING_OUT';
        elseif ($lateMinutes > 0 && $earlyMinutes > 0) $status = 'LATE_AND_EARLY';
        elseif ($lateMinutes > 0) $status = $lateMinutes <= 60 ? 'LATE_UNDER_60' : 'LATE_OVER_60';
        elseif ($earlyMinutes > 0) $status = 'EARLY_DEPARTURE';

        $totalPenalty = array_sum(array_column($penalties, 'amount'));

        $workDuration = 0;
        if ($firstInScan && $lastOutScan) {
            $workDuration = Carbon::parse($firstInScan)->diffInMinutes(Carbon::parse($lastOutScan));
        }

        return [
            'first_in' => $firstInScan ? Carbon::parse($firstInScan)->format('H:i:s') : null,
            'last_out' => $lastOutScan ? Carbon::parse($lastOutScan)->format('H:i:s') : null,
            'raw_scan_count' => $empLogs->count(),
            'expected_in' => $dayEval['in_time'],
            'expected_out' => $dayEval['out_time'],
            'is_workday' => true,
            'is_holiday' => false,
            'holiday_name' => null,
            'status' => $status,
            'late_minutes' => $lateMinutes,
            'early_minutes' => $earlyMinutes,
            'work_duration_minutes' => $workDuration,
            'total_penalty' => $totalPenalty,
            'penalties' => $penalties
        ];
    }

    /**
     * Simpan record ke database
     */
    protected function saveDailySummary(int $employeeId, string $dateStr, array $result): DailyAttendanceSummary
    {
        $summary = DailyAttendanceSummary::updateOrCreate(
            [
                'employee_id' => $employeeId,
                'attendance_date' => $dateStr,
            ],
            [
                'first_in' => $result['first_in'],
                'last_out' => $result['last_out'],
                'raw_scan_count' => $result['raw_scan_count'],
                'expected_in' => $result['expected_in'],
                'expected_out' => $result['expected_out'],
                'is_workday' => $result['is_workday'],
                'is_holiday' => $result['is_holiday'],
                'holiday_name' => $result['holiday_name'],
                'status' => $result['status'],
                'late_minutes' => $result['late_minutes'],
                'early_minutes' => $result['early_minutes'],
                'work_duration_minutes' => $result['work_duration_minutes'],
                'total_penalty' => $result['total_penalty'],
                'reconciled_at' => now(),
            ]
        );

        // Hapus penalti lama jika di-re-reconcile
        $summary->penalties()->delete();

        // Masukkan rincian penalti baru
        foreach ($result['penalties'] as $item) {
            AttendancePenalty::create([
                'daily_summary_id' => $summary->id,
                'violation_type' => $item['violation_type'],
                'amount' => $item['amount'],
                'description' => $item['description'],
            ]);
        }

        return $summary;
    }
}`
  },
  {
    title: 'MonthlyPayrollReportService (Laporan Agregat & Slip Tukin)',
    category: 'Service',
    path: 'app/Services/MonthlyPayrollReportService.php',
    description: 'Service pembuat laporan akumulasi bulanan per pegawai, kalkulasi total potongan tunjangan kinerja (Tukin), dan kompilasi data slip denda.',
    code: `<?php

namespace App\\Services;

use App\\Models\\Employee;
use App\\Models\\DailyAttendanceSummary;
use App\\Models\\MonthlyPayrollDeduction;
use Illuminate\\Support\\Collection;
use Carbon\\Carbon;

class MonthlyPayrollReportService
{
    /**
     * Agregasi data bulanan untuk seluruh pegawai pada periode tertentu
     */
    public function generateMonthlyReport(int $year, int $month, ?int $departmentId = null): array
    {
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth()->toDateString();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->toDateString();

        $empQuery = Employee::query()->where('is_active', true);
        if ($departmentId) {
            $empQuery->where('department_id', $departmentId);
        }
        $employees = $empQuery->with(['department'])->get();

        $summaries = DailyAttendanceSummary::with('penalties')
            ->whereBetween('attendance_date', [$startDate, $endDate])
            ->get()
            ->groupBy('employee_id');

        $reports = [];
        $grandTotalPenalty = 0;
        $totalLateMinutes = 0;

        foreach ($employees as $emp) {
            $empDailyRecords = $summaries->get($emp->id, collect());
            
            $workdaysCount = $empDailyRecords->where('is_workday', true)->count();
            $presentCount = $empDailyRecords->whereIn('status', ['ONTIME', 'LATE_UNDER_60', 'LATE_OVER_60', 'EARLY_DEPARTURE', 'LATE_AND_EARLY'])->count();
            $lateCount = $empDailyRecords->whereIn('status', ['LATE_UNDER_60', 'LATE_OVER_60', 'LATE_AND_EARLY'])->count();
            $earlyCount = $empDailyRecords->whereIn('status', ['EARLY_DEPARTURE', 'LATE_AND_EARLY'])->count();
            $missingCount = $empDailyRecords->whereIn('status', ['MISSING_IN', 'MISSING_OUT'])->count();
            $alphaCount = $empDailyRecords->where('status', 'ALPHA')->count();

            $totalLateMin = $empDailyRecords->sum('late_minutes');
            $totalEarlyMin = $empDailyRecords->sum('early_minutes');
            $totalPenalty = $empDailyRecords->sum('total_penalty');

            $grandTotalPenalty += $totalPenalty;
            $totalLateMinutes += $totalLateMin;

            $reports[] = [
                'employee_id' => $emp->id,
                'employee_code' => $emp->employee_code,
                'nip' => $emp->nip,
                'name' => $emp->name,
                'department' => $emp->department?->name ?? 'Instansi Umum',
                'position' => $emp->position,
                'employee_type' => $emp->employee_type,
                'total_workdays' => $workdaysCount,
                'present_days' => $presentCount,
                'late_days' => $lateCount,
                'early_days' => $earlyCount,
                'missing_scan_days' => $missingCount,
                'alpha_days' => $alphaCount,
                'accumulated_late_minutes' => $totalLateMin,
                'accumulated_early_minutes' => $totalEarlyMin,
                'total_penalty_rupiah' => (float) $totalPenalty,
                'formatted_penalty' => 'Rp ' . number_format($totalPenalty, 0, ',', '.'),
            ];
        }

        return [
            'period' => [
                'year' => $year,
                'month' => $month,
                'month_name' => Carbon::createFromDate($year, $month, 1)->locale('id')->isoFormat('MMMM YYYY'),
            ],
            'summary_metrics' => [
                'total_employees' => count($employees),
                'grand_total_penalty_rupiah' => $grandTotalPenalty,
                'total_late_minutes' => $totalLateMinutes,
            ],
            'records' => $reports
        ];
    }

    /**
     * Dapatkan rincian slip denda resmi untuk seorang pegawai
     */
    public function getEmployeeDeductionSlip(int $employeeId, int $year, int $month): array
    {
        $employee = Employee::with('department')->findOrFail($employeeId);
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth()->toDateString();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->toDateString();

        $violations = DailyAttendanceSummary::with('penalties')
            ->where('employee_id', $employeeId)
            ->whereBetween('attendance_date', [$startDate, $endDate])
            ->where('total_penalty', '>', 0)
            ->orderBy('attendance_date', 'asc')
            ->get();

        $totalDeduction = $violations->sum('total_penalty');

        return [
            'slip_number' => "SLIP-POT/{$year}/" . str_pad($month, 2, '0', STR_PAD_LEFT) . "/{$employee->employee_code}",
            'employee' => [
                'name' => $employee->name,
                'nip' => $employee->nip,
                'position' => $employee->position,
                'department' => $employee->department?->name ?? 'Pemerintah Daerah',
                'employee_type' => $employee->employee_type
            ],
            'period' => Carbon::createFromDate($year, $month, 1)->locale('id')->isoFormat('MMMM YYYY'),
            'violations_count' => $violations->count(),
            'violations' => $violations->map(function ($item) {
                return [
                    'date' => $item->attendance_date->format('d/m/Y'),
                    'day_name' => $item->attendance_date->locale('id')->isoFormat('dddd'),
                    'first_in' => $item->first_in ?? '-',
                    'last_out' => $item->last_out ?? '-',
                    'status_label' => $item->status_label,
                    'late_minutes' => $item->late_minutes,
                    'penalty_amount' => (float) $item->total_penalty,
                    'penalties_breakdown' => $item->penalties->pluck('description')
                ];
            }),
            'total_deduction_amount' => (float) $totalDeduction,
            'amount_in_words' => $this->numberToWords((int) $totalDeduction) . ' Rupiah',
            'generated_at' => now()->format('d/m/Y H:i:s'),
        ];
    }

    private function numberToWords(int $number): string
    {
        // Konversi nominal rupiah ke teks terbilang Bahasa Indonesia
        $units = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];
        if ($number < 12) return $units[$number];
        if ($number < 20) return $this->numberToWords($number - 10) . ' Belas';
        if ($number < 100) return $this->numberToWords(intdiv($number, 10)) . ' Puluh ' . $this->numberToWords($number % 10);
        if ($number < 200) return 'Seratus ' . $this->numberToWords($number - 100);
        if ($number < 1000) return $this->numberToWords(intdiv($number, 100)) . ' Ratus ' . $this->numberToWords($number % 100);
        if ($number < 2000) return 'Seribu ' . $this->numberToWords($number - 1000);
        if ($number < 1000000) return $this->numberToWords(intdiv($number, 1000)) . ' Ribu ' . $this->numberToWords($number % 1000);
        if ($number < 1000000000) return $this->numberToWords(intdiv($number, 1000000)) . ' Juta ' . $this->numberToWords($number % 1000000);
        return (string) $number;
    }
}`
  },
  {
    title: 'AttendanceReconciliationController (REST API Rekonsiliasi)',
    category: 'Controller',
    path: 'app/Http/Controllers/AttendanceReconciliationController.php',
    description: 'Controller pengelola API eksekusi rekonsiliasi harian, mode dry-run simulasi, penguncian rekap (lock/unlock), serta koreksi override manual dengan audit trail.',
    code: `<?php

namespace App\\Http\\Controllers;

use App\\Services\\AttendanceReconciliationService;
use App\\Models\\DailyAttendanceSummary;
use App\\Models\\AuditLog;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\DB;

class AttendanceReconciliationController extends Controller
{
    protected AttendanceReconciliationService $reconciliationService;

    public function __construct(AttendanceReconciliationService $reconciliationService)
    {
        $this->reconciliationService = $reconciliationService;
    }

    /**
     * Jalankan Engine Rekonsiliasi Harian
     */
    public function execute(Request $request)
    {
        $validated = $request->validate([
            'date' => ['required', 'date'],
            'dry_run' => ['boolean'],
            'department_id' => ['nullable', 'exists:departments,id']
        ]);

        $dryRun = $request->boolean('dry_run', false);
        $result = $this->reconciliationService->reconcileDate(
            $validated['date'],
            $dryRun,
            $validated['department_id'] ?? null
        );

        if (!$dryRun) {
            AuditLog::create([
                'user_id' => auth()->id(),
                'action' => 'RUN_ATTENDANCE_RECONCILIATION',
                'module' => 'RECONCILIATION',
                'record_id' => $validated['date'],
                'new_values' => [
                    'date' => $validated['date'],
                    'penalties_issued' => $result['total_penalties_issued'],
                    'total_rupiah' => $result['total_penalties_rupiah']
                ],
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent()
            ]);
        }

        return response()->json([
            'status' => 'success',
            'message' => $dryRun 
                ? 'Simulasi rekonsiliasi (Dry Run) selesai. Data tidak disimpan.'
                : "Rekonsiliasi tanggal {$validated['date']} berhasil diproses dan disimpan.",
            'result' => $result
        ]);
    }

    /**
     * Kunci / Buka Kunci Rekap Harian (Locking Period)
     */
    public function toggleLock(Request $request)
    {
        $request->validate([
            'date' => ['required', 'date'],
            'lock' => ['required', 'boolean']
        ]);

        $date = $request->input('date');
        $lock = $request->boolean('lock');

        DailyAttendanceSummary::where('attendance_date', $date)->update([
            'is_locked' => $lock
        ]);

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => $lock ? 'LOCK_DAILY_ATTENDANCE' : 'UNLOCK_DAILY_ATTENDANCE',
            'module' => 'RECONCILIATION',
            'record_id' => $date,
            'new_values' => ['is_locked' => $lock],
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent()
        ]);

        return response()->json([
            'status' => 'success',
            'message' => "Rekap absensi tanggal {$date} telah " . ($lock ? 'dikunci (Locked)' : 'dibuka kembali (Unlocked)') . "."
        ]);
    }
}`
  },
  {
    title: 'Artisan Command: ReconcileAttendanceDailyCommand',
    category: 'Artisan & CLI',
    path: 'app/Console/Commands/ReconcileAttendanceDailyCommand.php',
    description: 'CLI scheduler otomatis untuk rekonsiliasi harian setiap malam pukul 23:55 WIB atau dipanggil via cron job server.',
    code: `<?php

namespace App\\Console\\Commands;

use Illuminate\\Console\\Command;
use App\\Services\\AttendanceReconciliationService;

class ReconcileAttendanceDailyCommand extends Command
{
    protected $signature = 'attendance:reconcile 
                            {--date= : Tanggal spesifik yang akan direkonsiliasi (format: YYYY-MM-DD, default hari ini)}
                            {--dry-run : Jalankan mode simulasi tanpa commit database}';

    protected $description = 'Jalankan kalkulasi rekonsiliasi kehadiran dan penalti denda otomatis';

    public function handle(AttendanceReconciliationService $service): int
    {
        $dateStr = $this->option('date') ?: now()->toDateString();
        $isDryRun = (bool) $this->option('dry-run');

        $this->info("Memulai rekonsiliasi absensi untuk tanggal: {$dateStr} " . ($isDryRun ? '[DRY RUN MODE]' : ''));

        try {
            $result = $service->reconcileDate($dateStr, $isDryRun);

            $this->table(
                ['Parameter', 'Nilai'],
                [
                    ['Tanggal', $result['date']],
                    ['Hari Kerja?', $result['is_workday'] ? 'YA' : 'TIDAK (Libur/Akhir Pekan)'],
                    ['Pegawai Diproses', $result['total_employees_processed']],
                    ['Pelanggaran Terdeteksi', $result['total_penalties_issued']],
                    ['Total Nilai Denda', 'Rp ' . number_format($result['total_penalties_rupiah'], 0, ',', '.')],
                ]
            );

            $this->info("Rekonsiliasi selesai dengan sukses.");
            return Command::SUCCESS;
        } catch (\\Exception $e) {
            $this->error("Gagal menjalankan rekonsiliasi: " . $e->getMessage());
            return Command::FAILURE;
        }
    }
}`
  }
];
