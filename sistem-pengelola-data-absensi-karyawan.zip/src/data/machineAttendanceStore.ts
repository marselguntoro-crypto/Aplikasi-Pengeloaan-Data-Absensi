import * as XLSX from 'xlsx';
import { EmployeeRecord, saveStoredEmployees, getStoredEmployees } from './participantStore';

export interface MachineRowRaw {
  empNum: string;
  noId: string;
  nik: string;
  name: string;
  dateStr: string; // DD/MM/YYYY or YYYY-MM-DD
  isoDate: string; // YYYY-MM-DD
  scanIn1: string | null;
  scanOut1: string | null;
  scanIn2: string | null;
  scanOut2: string | null;
  scanIn3: string | null;
  scanOut3: string | null;
  scanIn4: string | null;
  scanOut4: string | null;
  scanIn5: string | null;
  scanOut5: string | null;
  totalWorkHours: string | null;
}

export interface CalculatedDailyAttendance {
  id: string;
  empNum: string;
  noId: string;
  name: string;
  nip: string;
  department: string;
  date: string; // YYYY-MM-DD
  dayName: string;
  firstIn: string | null;
  lastOut: string | null;
  allScans: Array<{ time: string; type: 'IN' | 'OUT'; label: string }>;
  status: string;
  statusType: 'ontime' | 'late' | 'early' | 'missing' | 'absent' | 'holiday';
  lateMinutes: number;
  earlyMinutes: number;
  penalty: number;
  penaltyBreakdown: string[];
  isHoliday: boolean;
  isWeekend: boolean;
  totalWorkHours?: string | null;
}

export interface EmployeeMonthlyAggregation {
  id: number;
  code: string;
  nip: string;
  name: string;
  department: string;
  position: string;
  employeeType: string;
  totalWorkdays: number;
  presentDays: number;
  lateDays: number;
  earlyDays: number;
  missingScanDays: number;
  alphaDays: number;
  accumulatedLateMinutes: number;
  accumulatedEarlyMinutes: number;
  totalPenalty: number;
  violations: Array<{
    date: string;
    dayName: string;
    firstIn: string | null;
    lastOut: string | null;
    violationType: string;
    durationMinutes: number;
    amount: number;
  }>;
}

export interface RawPunchEvent {
  id: number;
  employee_id: number;
  employee_code: string;
  employee_name: string;
  department: string;
  attendance_date: string;
  attendance_time: string;
  attendance_type: 'IN' | 'OUT';
  machine_id: string;
  is_duplicate: boolean;
  import_batch_id: number;
  raw_payload: {
    raw_string?: string;
  };
}

// Exact raw data provided by user
export const USER_INITIAL_CSV = `Emp Num.;No. ID.;NIK;Nama;Tanggal;Scan Masuk 1;Scan Pulang 1;Scan Masuk 2;Scan Pulang 2;Scan Masuk 3;Scan Pulang 3;Scan Masuk 4;Scan Pulang 4;Scan Masuk 5;Scan Pulang 5;Total Jam Kerja
1;1;;Suharun Mar.S.Pi.M.Si;03/08/2026;07:54:00;15:17:00;;;;;;;;;07:23:00
1;1;;Suharun Mar.S.Pi.M.Si;04/08/2026;07:09:00;16:34:00;;;;;;;;;09:25:00
1;1;;Suharun Mar.S.Pi.M.Si;05/08/2026;07:51:00;;;;;;;;;;
1;1;;Suharun Mar.S.Pi.M.Si;10/08/2026;07:17:00;;;;;;;;;;
1;1;;Suharun Mar.S.Pi.M.Si;11/08/2026;08:32:00;;;;;;;;;;
1;1;;Suharun Mar.S.Pi.M.Si;12/08/2026;07:35:00;17:40:00;;;;;;;;;10:05:00
1;1;;Suharun Mar.S.Pi.M.Si;13/08/2026;07:34:00;;;;;;;;;;
1;1;;Suharun Mar.S.Pi.M.Si;14/08/2026;07:08:00;16:11:00;;;;;;;;;09:03:00
1;1;;Suharun Mar.S.Pi.M.Si;18/08/2026;08:28:00;15:22:00;;;;;;;;;06:54:00
1;1;;Suharun Mar.S.Pi.M.Si;19/08/2026;08:12:00;16:55:00;;;;;;;;;08:43:00
1;1;;Suharun Mar.S.Pi.M.Si;20/08/2026;07:10:00;17:39:00;;;;;;;;;10:29:00
1;1;;Suharun Mar.S.Pi.M.Si;26/08/2026;08:12:00;18:02:00;;;;;;;;;09:50:00
1;1;;Suharun Mar.S.Pi.M.Si;27/08/2026;07:03:00;;;;;;;;;;
4;4;;Ir Firman M.Si;03/08/2026;07:17:00;17:08:00;;;;;;;;;09:51:00
4;4;;Ir Firman M.Si;04/08/2026;07:28:00;16:31:00;;;;;;;;;09:03:00
4;4;;Ir Firman M.Si;05/08/2026;07:33:00;16:32:00;;;;;;;;;08:59:00
4;4;;Ir Firman M.Si;06/08/2026;07:43:00;16:51:00;;;;;;;;;09:08:00
4;4;;Ir Firman M.Si;07/08/2026;07:23:00;17:01:00;;;;;;;;;09:38:00
4;4;;Ir Firman M.Si;10/08/2026;07:21:00;15:38:00;;;;;;;;;08:17:00
4;4;;Ir Firman M.Si;11/08/2026;07:44:00;;;;;;;;;;
4;4;;Ir Firman M.Si;12/08/2026;;;;;;;;;;;
4;4;;Ir Firman M.Si;13/08/2026;07:36:00;;;;;;;;;;
4;4;;Ir Firman M.Si;14/08/2026;07:45:00;16:58:00;;;;;;;;;09:13:00
4;4;;Ir Firman M.Si;18/08/2026;07:30:00;16:42:00;;;;;;;;;09:12:00
4;4;;Ir Firman M.Si;19/08/2026;08:00:00;16:54:00;;;;;;;;;08:54:00
4;4;;Ir Firman M.Si;20/08/2026;07:40:00;17:15:00;;;;;;;;;09:35:00
4;4;;Ir Firman M.Si;21/08/2026;07:26:00;17:17:00;;;;;;;;;09:51:00
4;4;;Ir Firman M.Si;26/08/2026;07:23:00;16:01:00;;;;;;;;;08:38:00
4;4;;Ir Firman M.Si;27/08/2026;07:52:00;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;01/08/2026;08:31:00;18:16:00;;;;;;;;;09:45:00
6;6;;DedI P .S.Pi.M.Pi;02/08/2026;13:40:00;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;03/08/2026;07:59:00;16:31:00;;;;;;;;;08:32:00
6;6;;DedI P .S.Pi.M.Pi;04/08/2026;;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;05/08/2026;07:24:00;16:48:00;;;;;;;;;09:24:00
6;6;;DedI P .S.Pi.M.Pi;06/08/2026;07:28:00;17:54:00;;;;;;;;;10:26:00
6;6;;DedI P .S.Pi.M.Pi;07/08/2026;07:13:00;17:04:00;;;;;;;;;09:51:00
6;6;;DedI P .S.Pi.M.Pi;08/08/2026;08:33:00;17:51:00;;;;;;;;;09:18:00
6;6;;DedI P .S.Pi.M.Pi;10/08/2026;07:36:00;17:00:00;;;;;;;;;09:24:00
6;6;;DedI P .S.Pi.M.Pi;11/08/2026;07:16:00;16:34:00;;;;;;;;;09:18:00
6;6;;DedI P .S.Pi.M.Pi;12/08/2026;07:23:00;17:16:00;;;;;;;;;09:53:00
6;6;;DedI P .S.Pi.M.Pi;13/08/2026;07:30:00;18:08:00;;;;;;;;;10:38:00
6;6;;DedI P .S.Pi.M.Pi;14/08/2026;;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;15/08/2026;12:17:00;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;17/08/2026;07:12:00;16:52:00;;;;;;;;;09:40:00
6;6;;DedI P .S.Pi.M.Pi;18/08/2026;07:22:00;17:14:00;;;;;;;;;09:52:00
6;6;;DedI P .S.Pi.M.Pi;19/08/2026;07:23:00;17:13:00;;;;;;;;;09:50:00
6;6;;DedI P .S.Pi.M.Pi;20/08/2026;07:24:00;17:47:00;;;;;;;;;10:23:00
6;6;;DedI P .S.Pi.M.Pi;21/08/2026;07:29:00;;;;;;;;;;
6;6;;DedI P .S.Pi.M.Pi;24/08/2026;06:55:00;16:38:00;;;;;;;;;09:43:00
6;6;;DedI P .S.Pi.M.Pi;26/08/2026;08:02:00;16:59:00;;;;;;;;;08:57:00
6;6;;DedI P .S.Pi.M.Pi;27/08/2026;07:38:00;;;;;;;;;;
8;8;;Ir Risvan Anwar M.Si;05/08/2026;08:03:00;;;;;;;;;;
8;8;;Ir Risvan Anwar M.Si;21/08/2026;07:59:00;;;;;;;;;;
14;14;;Ikhsan Hasibuan SP.M.Sc;03/08/2026;09:13:00;;;;;;;;;;
14;14;;Ikhsan Hasibuan SP.M.Sc;04/08/2026;10:37:00;16:42:00;;;;;;;;;06:05:00
14;14;;Ikhsan Hasibuan SP.M.Sc;06/08/2026;08:19:00;17:26:00;;;;;;;;;09:07:00
14;14;;Ikhsan Hasibuan SP.M.Sc;07/08/2026;08:13:00;;;;;;;;;;
14;14;;Ikhsan Hasibuan SP.M.Sc;10/08/2026;11:42:00;17:04:00;;;;;;;;;05:22:00
14;14;;Ikhsan Hasibuan SP.M.Sc;11/08/2026;10:14:00;17:23:00;;;;;;;;;07:09:00
14;14;;Ikhsan Hasibuan SP.M.Sc;12/08/2026;09:08:00;16:47:00;;;;;;;;;07:39:00
14;14;;Ikhsan Hasibuan SP.M.Sc;13/08/2026;08:59:00;17:06:00;;;;;;;;;08:07:00
14;14;;Ikhsan Hasibuan SP.M.Sc;14/08/2026;06:42:00;17:02:00;;;;;;;;;10:20:00
14;14;;Ikhsan Hasibuan SP.M.Sc;18/08/2026;08:18:00;17:08:00;;;;;;;;;08:50:00
14;14;;Ikhsan Hasibuan SP.M.Sc;19/08/2026;08:27:00;16:48:00;;;;;;;;;08:21:00
14;14;;Ikhsan Hasibuan SP.M.Sc;20/08/2026;08:22:00;17:42:00;;;;;;;;;09:20:00
14;14;;Ikhsan Hasibuan SP.M.Sc;21/08/2026;11:29:00;17:48:00;;;;;;;;;06:19:00
14;14;;Ikhsan Hasibuan SP.M.Sc;24/08/2026;08:21:00;16:52:00;;;;;;;;;08:31:00
14;14;;Ikhsan Hasibuan SP.M.Sc;26/08/2026;08:21:00;16:33:00;;;;;;;;;08:12:00
14;14;;Ikhsan Hasibuan SP.M.Sc;27/08/2026;08:22:00;;;;;;;;;;
15;15;;Sazuatmo.ST.MT;11/08/2026;09:36:00;16:54:00;;;;;;;;;07:18:00
15;15;;Sazuatmo.ST.MT;12/08/2026;09:02:00;17:05:00;;;;;;;;;08:03:00
15;15;;Sazuatmo.ST.MT;13/08/2026;11:01:00;16:50:00;;;;;;;;;05:49:00
15;15;;Sazuatmo.ST.MT;14/08/2026;10:21:00;17:32:00;;;;;;;;;07:11:00
15;15;;Sazuatmo.ST.MT;18/08/2026;09:16:00;16:39:00;;;;;;;;;07:23:00
15;15;;Sazuatmo.ST.MT;19/08/2026;09:52:00;16:48:00;;;;;;;;;06:56:00
15;15;;Sazuatmo.ST.MT;20/08/2026;08:17:00;16:31:00;;;;;;;;;08:14:00
15;15;;Sazuatmo.ST.MT;21/08/2026;07:52:00;16:58:00;;;;;;;;;09:06:00
15;15;;Sazuatmo.ST.MT;26/08/2026;08:19:00;;;;;;;;;;
15;15;;Sazuatmo.ST.MT;27/08/2026;08:15:00;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;04/08/2026;;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;05/08/2026;;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;06/08/2026;08:25:00;16:35:00;;;;;;;;;08:10:00
16;16;;Elviza Diana .M.Kom;10/08/2026;;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;11/08/2026;;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;12/08/2026;07:34:00;17:23:00;;;;;;;;;09:49:00
16;16;;Elviza Diana .M.Kom;13/08/2026;07:56:00;17:11:00;;;;;;;;;09:15:00
16;16;;Elviza Diana .M.Kom;14/08/2026;08:06:00;17:33:00;;;;;;;;;09:27:00
16;16;;Elviza Diana .M.Kom;19/08/2026;;;;;;;;;;;
16;16;;Elviza Diana .M.Kom;20/08/2026;09:52:00;16:44:00;;;;;;;;;06:52:00
16;16;;Elviza Diana .M.Kom;21/08/2026;;;;;;;;;;;
24;24;;Edito Dwi Antoro ST.MT;03/08/2026;10:32:00;;;;;;;;;;
24;24;;Edito Dwi Antoro ST.MT;04/08/2026;07:36:00;;;;;;;;;;
24;24;;Edito Dwi Antoro ST.MT;05/08/2026;11:36:00;;;;;;;;;;
24;24;;Edito Dwi Antoro ST.MT;07/08/2026;11:25:00;;;;;;;;;;
24;24;;Edito Dwi Antoro ST.MT;14/08/2026;08:52:00;;;;;;;;;;
28;28;;Adi Ardiansyah.SE;03/08/2026;07:06:00;16:39:00;;;;;;;;;09:33:00
28;28;;Adi Ardiansyah.SE;04/08/2026;07:14:00;16:35:00;;;;;;;;;09:21:00
28;28;;Adi Ardiansyah.SE;05/08/2026;07:05:00;16:36:00;;;;;;;;;09:31:00
28;28;;Adi Ardiansyah.SE;06/08/2026;07:04:00;16:47:00;;;;;;;;;09:43:00
28;28;;Adi Ardiansyah.SE;07/08/2026;07:08:00;17:04:00;;;;;;;;;09:56:00
28;28;;Adi Ardiansyah.SE;10/08/2026;07:08:00;16:54:00;;;;;;;;;09:46:00
28;28;;Adi Ardiansyah.SE;11/08/2026;07:12:00;18:05:00;;;;;;;;;10:53:00
28;28;;Adi Ardiansyah.SE;12/08/2026;07:02:00;17:26:00;;;;;;;;;10:24:00
28;28;;Adi Ardiansyah.SE;13/08/2026;07:07:00;17:21:00;;;;;;;;;10:14:00
28;28;;Adi Ardiansyah.SE;14/08/2026;07:27:00;17:34:00;;;;;;;;;10:07:00
28;28;;Adi Ardiansyah.SE;18/08/2026;07:04:00;17:23:00;;;;;;;;;10:19:00
28;28;;Adi Ardiansyah.SE;19/08/2026;07:05:00;17:09:00;;;;;;;;;10:04:00
28;28;;Adi Ardiansyah.SE;20/08/2026;07:11:00;17:01:00;;;;;;;;;09:50:00
28;28;;Adi Ardiansyah.SE;21/08/2026;07:11:00;17:32:00;;;;;;;;;10:21:00
28;28;;Adi Ardiansyah.SE;24/08/2026;;;;;;;;;;;
28;28;;Adi Ardiansyah.SE;26/08/2026;07:16:00;16:39:00;;;;;;;;;09:23:00
28;28;;Adi Ardiansyah.SE;27/08/2026;07:08:00;;;;;;;;;;
30;30;;Candra Andika Jaya.ST;03/08/2026;08:14:00;;;;;;;;;;
30;30;;Candra Andika Jaya.ST;04/08/2026;08:13:00;16:37:00;;;;;;;;;08:24:00
30;30;;Candra Andika Jaya.ST;05/08/2026;08:14:00;16:47:00;;;;;;;;;08:33:00
30;30;;Candra Andika Jaya.ST;06/08/2026;11:52:00;16:35:00;;;;;;;;;04:43:00
30;30;;Candra Andika Jaya.ST;07/08/2026;08:37:00;17:02:00;;;;;;;;;08:25:00
30;30;;Candra Andika Jaya.ST;10/08/2026;08:12:00;16:35:00;;;;;;;;;08:23:00
30;30;;Candra Andika Jaya.ST;11/08/2026;08:12:00;16:36:00;;;;;;;;;08:24:00
30;30;;Candra Andika Jaya.ST;12/08/2026;07:58:00;16:36:00;;;;;;;;;08:38:00
30;30;;Candra Andika Jaya.ST;13/08/2026;08:18:00;;;;;;;;;;
30;30;;Candra Andika Jaya.ST;18/08/2026;09:30:00;16:58:00;;;;;;;;;07:28:00
30;30;;Candra Andika Jaya.ST;19/08/2026;08:01:00;16:33:00;;;;;;;;;08:32:00
30;30;;Candra Andika Jaya.ST;20/08/2026;08:14:00;17:17:00;;;;;;;;;09:03:00
30;30;;Candra Andika Jaya.ST;21/08/2026;08:11:00;19:35:00;;;;;;;;;11:24:00
30;30;;Candra Andika Jaya.ST;24/08/2026;08:21:00;;;;;;;;;;
30;30;;Candra Andika Jaya.ST;26/08/2026;08:30:00;16:31:00;;;;;;;;;08:01:00
30;30;;Candra Andika Jaya.ST;27/08/2026;08:06:00;;;;;;;;;;
34;34;;Een;10/08/2026;11:30:00;17:08:00;;;;;;;;;05:38:00
34;34;;Een;11/08/2026;07:53:00;17:57:00;;;;;;;;;10:04:00
34;34;;Een;12/08/2026;;;;;;;;;;;
34;34;;Een;13/08/2026;10:49:00;17:06:00;;;;;;;;;06:17:00
34;34;;Een;14/08/2026;07:58:00;;;;;;;;;;
34;34;;Een;18/08/2026;08:31:00;16:48:00;;;;;;;;;08:17:00
34;34;;Een;19/08/2026;09:26:00;17:20:00;;;;;;;;;07:54:00
34;34;;Een;20/08/2026;08:20:00;17:38:00;;;;;;;;;09:18:00
34;34;;Een;21/08/2026;;;;;;;;;;;
34;34;;Een;24/08/2026;06:44:00;17:20:00;;;;;;;;;10:36:00
34;34;;Een;26/08/2026;08:08:00;16:31:00;;;;;;;;;08:23:00
34;34;;Een;27/08/2026;09:49:00;;;;;;;;;;
37;37;;Irma;11/08/2026;;;;;;;;;;;
37;37;;Irma;12/08/2026;;;;;;;;;;;
37;37;;Irma;13/08/2026;;;;;;;;;;;
37;37;;Irma;19/08/2026;;;;;;;;;;;
37;37;;Irma;21/08/2026;07:15:00;;;;;;;;;;
38;38;;Triutamidewi;03/08/2026;08:22:00;17:15:00;;;;;;;;;08:53:00
38;38;;Triutamidewi;04/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;05/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;06/08/2026;08:36:00;17:16:00;;;;;;;;;08:40:00
38;38;;Triutamidewi;10/08/2026;08:05:00;17:00:00;;;;;;;;;08:55:00
38;38;;Triutamidewi;11/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;12/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;13/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;14/08/2026;08:26:00;17:14:00;;;;;;;;;08:48:00
38;38;;Triutamidewi;18/08/2026;08:37:00;17:58:00;;;;;;;;;09:21:00
38;38;;Triutamidewi;19/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;20/08/2026;;;;;;;;;;;
38;38;;Triutamidewi;21/08/2026;06:59:00;16:59:00;;;;;;;;;10:00:00
38;38;;Triutamidewi;24/08/2026;08:27:00;16:55:00;;;;;;;;;08:28:00
38;38;;Triutamidewi;26/08/2026;08:15:00;17:07:00;;;;;;;;;08:52:00
40;40;;Indah;03/08/2026;;;;;;;;;;;
40;40;;Indah;06/08/2026;;;;;;;;;;;
40;40;;Indah;12/08/2026;;;;;;;;;;;
40;40;;Indah;18/08/2026;;;;;;;;;;;
40;40;;Indah;19/08/2026;;;;;;;;;;;
40;40;;Indah;26/08/2026;;;;;;;;;;;
43;43;;Wikemanda;11/08/2026;;;;;;;;;;;
43;43;;Wikemanda;12/08/2026;;;;;;;;;;;
43;43;;Wikemanda;13/08/2026;;;;;;;;;;;
43;43;;Wikemanda;14/08/2026;07:52:00;17:27:00;;;;;;;;;09:35:00
43;43;;Wikemanda;18/08/2026;08:12:00;17:22:00;;;;;;;;;09:10:00
43;43;;Wikemanda;19/08/2026;;;;;;;;;;;
43;43;;Wikemanda;20/08/2026;;;;;;;;;;;
43;43;;Wikemanda;21/08/2026;;;;;;;;;;;
43;43;;Wikemanda;24/08/2026;;;;;;;;;;;
43;43;;Wikemanda;26/08/2026;07:57:00;16:31:00;;;;;;;;;08:34:00
44;44;;Elsa;11/08/2026;08:12:00;;;;;;;;;;
44;44;;Elsa;14/08/2026;08:13:00;17:27:00;;;;;;;;;09:14:00
44;44;;Elsa;18/08/2026;06:30:00;17:25:00;;;;;;;;;10:55:00
44;44;;Elsa;19/08/2026;07:18:00;20:51:00;;;;;;;;;13:33:00
44;44;;Elsa;20/08/2026;06:42:00;17:52:00;;;;;;;;;11:10:00
44;44;;Elsa;21/08/2026;07:50:00;17:07:00;;;;;;;;;09:17:00
44;44;;Elsa;24/08/2026;06:53:00;;;;;;;;;;
44;44;;Elsa;26/08/2026;07:46:00;16:31:00;;;;;;;;;08:45:00
45;45;;Ade;13/08/2026;07:58:00;16:51:00;;;;;;;;;08:53:00
45;45;;Ade;14/08/2026;08:02:00;17:28:00;;;;;;;;;09:26:00
45;45;;Ade;18/08/2026;;;;;;;;;;;
45;45;;Ade;19/08/2026;10:32:00;17:06:00;;;;;;;;;06:34:00
45;45;;Ade;20/08/2026;09:52:00;;;;;;;;;;
45;45;;Ade;21/08/2026;;;;;;;;;;;
45;45;;Ade;24/08/2026;07:50:00;16:39:00;;;;;;;;;08:49:00
46;46;;Yudhia;11/08/2026;;;;;;;;;;;
46;46;;Yudhia;12/08/2026;08:50:00;17:08:00;;;;;;;;;08:18:00
46;46;;Yudhia;13/08/2026;;;;;;;;;;;
46;46;;Yudhia;14/08/2026;;;;;;;;;;;
46;46;;Yudhia;26/08/2026;;;;;;;;;;;
46;46;;Yudhia;27/08/2026;10:11:00;;;;;;;;;;
47;47;;Adi;03/08/2026;;;;;;;;;;;
47;47;;Adi;04/08/2026;;;;;;;;;;;
47;47;;Adi;05/08/2026;;;;;;;;;;;
47;47;;Adi;06/08/2026;;;;;;;;;;;
47;47;;Adi;07/08/2026;09:14:00;17:03:00;;;;;;;;;07:49:00
47;47;;Adi;10/08/2026;;;;;;;;;;;
47;47;;Adi;11/08/2026;;;;;;;;;;;
47;47;;Adi;12/08/2026;;;;;;;;;;;
47;47;;Adi;13/08/2026;;;;;;;;;;;
47;47;;Adi;14/08/2026;08:59:00;17:13:00;;;;;;;;;08:14:00
47;47;;Adi;18/08/2026;;;;;;;;;;;
47;47;;Adi;19/08/2026;;;;;;;;;;;
47;47;;Adi;20/08/2026;;;;;;;;;;;
47;47;;Adi;21/08/2026;;;;;;;;;;;
48;48;;Misra;10/08/2026;08:15:00;16:54:00;;;;;;;;;08:39:00
48;48;;Misra;11/08/2026;08:15:00;16:53:00;;;;;;;;;08:38:00
48;48;;Misra;12/08/2026;;;;;;;;;;;
48;48;;Misra;13/08/2026;;;;;;;;;;;
48;48;;Misra;14/08/2026;08:07:00;17:12:00;;;;;;;;;09:05:00
48;48;;Misra;18/08/2026;08:17:00;16:58:00;;;;;;;;;08:41:00
48;48;;Misra;19/08/2026;08:07:00;16:55:00;;;;;;;;;08:48:00
48;48;;Misra;20/08/2026;08:03:00;17:44:00;;;;;;;;;09:41:00
48;48;;Misra;21/08/2026;;;;;;;;;;;
48;48;;Misra;24/08/2026;08:08:00;16:37:00;;;;;;;;;08:29:00
48;48;;Misra;27/08/2026;08:06:00;;;;;;;;;;
49;49;;Yeiyeko;01/08/2026;10:45:00;18:17:00;;;;;;;;;07:32:00
49;49;;Yeiyeko;02/08/2026;13:40:00;17:34:00;;;;;;;;;03:54:00
49;49;;Yeiyeko;03/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;04/08/2026;07:41:00;17:00:00;;;;;;;;;09:19:00
49;49;;Yeiyeko;05/08/2026;07:46:00;16:48:00;;;;;;;;;09:02:00
49;49;;Yeiyeko;06/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;07/08/2026;07:23:00;17:01:00;;;;;;;;;09:38:00
49;49;;Yeiyeko;08/08/2026;12:13:00;;;;;;;;;;
49;49;;Yeiyeko;09/08/2026;09:47:00;20:39:00;;;;;;;;;10:52:00
49;49;;Yeiyeko;10/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;11/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;12/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;13/08/2026;08:05:00;18:07:00;;;;;;;;;10:02:00
49;49;;Yeiyeko;14/08/2026;07:46:00;17:01:00;;;;;;;;;09:15:00
49;49;;Yeiyeko;15/08/2026;11:25:00;18:58:00;;;;;;;;;07:33:00
49;49;;Yeiyeko;17/08/2026;07:28:00;19:29:00;;;;;;;;;12:01:00
49;49;;Yeiyeko;18/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;19/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;20/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;21/08/2026;07:25:00;;;;;;;;;;
49;49;;Yeiyeko;24/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;26/08/2026;;;;;;;;;;;
49;49;;Yeiyeko;27/08/2026;08:15:00;;;;;;;;;;`;

const STORAGE_KEY_MACHINE_ATTENDANCE = 'attendance_app_machine_data_v1';

/**
 * Parses date string DD/MM/YYYY or YYYY-MM-DD into ISO string YYYY-MM-DD
 */
export function normalizeDateToIso(dateStr: string): string {
  if (!dateStr) return '';
  const trimmed = dateStr.trim();
  if (trimmed.includes('/')) {
    const parts = trimmed.split('/');
    if (parts.length === 3) {
      const day = parts[0].padStart(2, '0');
      const month = parts[1].padStart(2, '0');
      const year = parts[2].length === 2 ? `20${parts[2]}` : parts[2];
      return `${year}-${month}-${day}`;
    }
  }
  if (trimmed.includes('-')) {
    const parts = trimmed.split('-');
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
      } else {
        const day = parts[0].padStart(2, '0');
        const month = parts[1].padStart(2, '0');
        const year = parts[2].length === 2 ? `20${parts[2]}` : parts[2];
        return `${year}-${month}-${day}`;
      }
    }
  }
  return trimmed;
}

/**
 * Parses minutes from HH:MM:SS or HH:MM
 */
export function timeToMinutes(timeStr: string | null): number | null {
  if (!timeStr) return null;
  const parts = timeStr.trim().split(':');
  if (parts.length < 2) return null;
  const hours = parseInt(parts[0], 10);
  const minutes = parseInt(parts[1], 10);
  if (isNaN(hours) || isNaN(minutes)) return null;
  return hours * 60 + minutes;
}

/**
 * Check if a date is Sunday (0) or Saturday (6)
 */
export function isDateWeekend(isoDate: string): boolean {
  if (!isoDate) return false;
  const d = new Date(isoDate + 'T00:00:00');
  const day = d.getDay();
  return day === 0 || day === 6; // Sun = 0, Sat = 6
}

/**
 * Check national holidays (e.g. 17 August Indonesian Independence Day)
 */
export function isNationalHoliday(isoDate: string): boolean {
  if (!isoDate) return false;
  // Check 17 August
  if (isoDate.endsWith('-08-17')) return true;
  // Known public holidays in 2026
  const holidays = [
    '2026-01-01',
    '2026-02-17',
    '2026-03-20',
    '2026-03-21',
    '2026-04-03',
    '2026-05-01',
    '2026-05-14',
    '2026-05-25',
    '2026-06-01',
    '2026-08-17',
    '2026-12-25',
  ];
  return holidays.includes(isoDate);
}

export function getIndonesianDayName(isoDate: string): string {
  if (!isoDate) return '';
  const d = new Date(isoDate + 'T00:00:00');
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return days[d.getDay()] || '';
}

/**
 * Parses raw attendance machine export in the user's specific format
 */
export function parseMachineAttendanceCsv(rawText: string) {
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return {
      rawRows: [],
      employees: [],
      dailyRecords: [],
      rawPunches: [],
      monthlySummaries: [],
    };
  }

  // Detect delimiter: semicolon or comma or tab
  const headerLine = lines[0];
  let delimiter = ';';
  if (headerLine.includes(';') && (headerLine.split(';').length >= headerLine.split(',').length)) {
    delimiter = ';';
  } else if (headerLine.includes('\t')) {
    delimiter = '\t';
  } else if (headerLine.includes(',')) {
    delimiter = ',';
  }

  const rawRows: MachineRowRaw[] = [];
  const employeeMap = new Map<string, { id: number; name: string; nik: string; noId: string }>();

  // Determine header column index
  const headerCols = headerLine.split(delimiter).map((c) => c.trim().toLowerCase());
  const idxEmpNum = headerCols.findIndex((c) => c.includes('emp num') || c.includes('emp_num') || c.includes('nomor'));
  const idxNoId = headerCols.findIndex((c) => c.includes('no. id') || c.includes('no_id') || c.includes('pin') || c.includes('id'));
  const idxNik = headerCols.findIndex((c) => c === 'nik');
  const idxNama = headerCols.findIndex((c) => c.includes('nama') || c.includes('name'));
  const idxTanggal = headerCols.findIndex((c) => c.includes('tanggal') || c.includes('date'));
  const idxMasuk1 = headerCols.findIndex((c) => c.includes('masuk 1') || c.includes('in 1') || c.includes('masuk'));
  const idxPulang1 = headerCols.findIndex((c) => c.includes('pulang 1') || c.includes('out 1') || c.includes('pulang'));
  const idxTotalJam = headerCols.findIndex((c) => c.includes('total jam') || c.includes('work hour') || c.includes('total'));

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(delimiter).map((c) => c.trim().replace(/^["']|["']$/g, ''));
    if (cols.length < 4) continue;

    const empNum = (idxEmpNum >= 0 ? cols[idxEmpNum] : cols[0]) || '';
    const noId = (idxNoId >= 0 ? cols[idxNoId] : cols[1]) || empNum;
    const nik = (idxNik >= 0 ? cols[idxNik] : cols[2]) || '';
    const name = (idxNama >= 0 ? cols[idxNama] : cols[3]) || `Pegawai ${empNum}`;
    const dateStr = (idxTanggal >= 0 ? cols[idxTanggal] : cols[4]) || '';

    if (!name && !empNum) continue;

    const isoDate = normalizeDateToIso(dateStr);

    const scanIn1 = (idxMasuk1 >= 0 ? cols[idxMasuk1] : cols[5]) || null;
    const scanOut1 = (idxPulang1 >= 0 ? cols[idxPulang1] : cols[6]) || null;
    const scanIn2 = cols[7] || null;
    const scanOut2 = cols[8] || null;
    const scanIn3 = cols[9] || null;
    const scanOut3 = cols[10] || null;
    const scanIn4 = cols[11] || null;
    const scanOut4 = cols[12] || null;
    const scanIn5 = cols[13] || null;
    const scanOut5 = cols[14] || null;
    const totalWorkHours = (idxTotalJam >= 0 ? cols[idxTotalJam] : cols[15]) || null;

    rawRows.push({
      empNum,
      noId,
      nik,
      name,
      dateStr,
      isoDate,
      scanIn1: scanIn1 ? scanIn1.trim() : null,
      scanOut1: scanOut1 ? scanOut1.trim() : null,
      scanIn2: scanIn2 ? scanIn2.trim() : null,
      scanOut2: scanOut2 ? scanOut2.trim() : null,
      scanIn3: scanIn3 ? scanIn3.trim() : null,
      scanOut3: scanOut3 ? scanOut3.trim() : null,
      scanIn4: scanIn4 ? scanIn4.trim() : null,
      scanOut4: scanOut4 ? scanOut4.trim() : null,
      scanIn5: scanIn5 ? scanIn5.trim() : null,
      scanOut5: scanOut5 ? scanOut5.trim() : null,
      totalWorkHours,
    });

    const empKey = empNum || name;
    if (!employeeMap.has(empKey)) {
      const numId = parseInt(empNum, 10) || employeeMap.size + 1;
      employeeMap.set(empKey, {
        id: numId,
        name,
        nik,
        noId,
      });
    }
  }

  // Create clean EmployeeRecord array from parsed participants
  const employees: EmployeeRecord[] = Array.from(employeeMap.values()).map((emp) => {
    // Generate code e.g. EMP-001, EMP-004
    const code = `EMP-${String(emp.id).padStart(3, '0')}`;
    return {
      id: emp.id,
      employee_code: code,
      nip: emp.nik || `19850101${String(emp.id).padStart(6, '0')}`,
      name: emp.name,
      department: inferDepartmentFromName(emp.name),
      position: inferPositionFromName(emp.name),
      employment_status: emp.name.includes('M.Si') || emp.name.includes('S.Pi') || emp.name.includes('Ir') ? 'PNS' : 'PPPK',
      is_active: true,
      created_at: new Date().toISOString(),
    };
  });

  // Calculate daily attendance records according to standard rules:
  // Workday: Expected In <= 08:15 (Tepat waktu)
  // Workday: Expected Out >= 16:30 (Tepat waktu)
  // Late <= 60 min: Rp 7.500
  // Late > 60 min: Rp 10.000
  // Early departure: Rp 10.000
  // Missing In scan: Rp 10.000
  // Missing Out scan: Rp 10.000
  // Absent / Alpha: Rp 20.000
  // Holiday: Rp 0
  const dailyRecords: CalculatedDailyAttendance[] = [];
  const rawPunches: RawPunchEvent[] = [];
  let punchIdCounter = 1;

  for (const row of rawRows) {
    const empInfo = employeeMap.get(row.empNum || row.name);
    const empId = empInfo ? empInfo.id : parseInt(row.empNum, 10) || 1;
    const empCode = `EMP-${String(empId).padStart(3, '0')}`;
    const department = inferDepartmentFromName(row.name);

    // Collect all punches for this day
    const dayPunches: Array<{ time: string; type: 'IN' | 'OUT'; label: string }> = [];

    const checkAndAdd = (val: string | null, type: 'IN' | 'OUT', label: string) => {
      if (val && val.trim() && val !== '-' && val !== '00:00:00') {
        const timeClean = val.trim();
        dayPunches.push({ time: timeClean, type, label });

        // Add to raw punch event list
        rawPunches.push({
          id: punchIdCounter++,
          employee_id: empId,
          employee_code: empCode,
          employee_name: row.name,
          department,
          attendance_date: row.isoDate,
          attendance_time: timeClean,
          attendance_type: type,
          machine_id: 'ZKT-LOBBY-01',
          is_duplicate: false,
          import_batch_id: 104,
          raw_payload: {
            raw_string: `${row.empNum};${row.name};${row.isoDate};${timeClean};${type}`,
          },
        });
      }
    };

    checkAndAdd(row.scanIn1, 'IN', 'Scan Masuk 1');
    checkAndAdd(row.scanOut1, 'OUT', 'Scan Pulang 1');
    checkAndAdd(row.scanIn2, 'IN', 'Scan Masuk 2');
    checkAndAdd(row.scanOut2, 'OUT', 'Scan Pulang 2');
    checkAndAdd(row.scanIn3, 'IN', 'Scan Masuk 3');
    checkAndAdd(row.scanOut3, 'OUT', 'Scan Pulang 3');
    checkAndAdd(row.scanIn4, 'IN', 'Scan Masuk 4');
    checkAndAdd(row.scanOut4, 'OUT', 'Scan Pulang 4');
    checkAndAdd(row.scanIn5, 'IN', 'Scan Masuk 5');
    checkAndAdd(row.scanOut5, 'OUT', 'Scan Pulang 5');

    // Sort punches by time
    dayPunches.sort((a, b) => (timeToMinutes(a.time) || 0) - (timeToMinutes(b.time) || 0));

    // Determine First In & Last Out
    // First in is earliest IN scan (or earliest scan if none marked IN)
    const inPunches = dayPunches.filter((p) => p.type === 'IN');
    const outPunches = dayPunches.filter((p) => p.type === 'OUT');

    const firstIn = inPunches.length > 0 ? inPunches[0].time : null;
    const lastOut = outPunches.length > 0 ? outPunches[outPunches.length - 1].time : null;

    const isHoliday = isNationalHoliday(row.isoDate);
    const isWeekend = isDateWeekend(row.isoDate);
    const dayName = getIndonesianDayName(row.isoDate);

    let status = 'HADIR TEPAT WAKTU';
    let statusType: CalculatedDailyAttendance['statusType'] = 'ontime';
    let lateMinutes = 0;
    let earlyMinutes = 0;
    let penalty = 0;
    const penaltyBreakdown: string[] = [];

    if (isHoliday || isWeekend) {
      status = isHoliday ? 'LIBUR NASIONAL' : 'AKHIR PEKAN';
      statusType = 'holiday';
      penalty = 0;
      penaltyBreakdown.push(isHoliday ? 'Hari Libur Nasional: Potongan Rp 0' : 'Akhir Pekan: Potongan Rp 0');
    } else {
      // Workday evaluation
      const hasAnyScan = dayPunches.length > 0;

      if (!hasAnyScan) {
        // Alpha / Tidak hadir tanpa keterangan
        status = 'TIDAK HADIR (ALPHA)';
        statusType = 'absent';
        penalty = 20000;
        penaltyBreakdown.push('Tidak hadir tanpa keterangan (Denda Rp 20.000)');
      } else if (!firstIn && lastOut) {
        // Missing IN scan
        status = 'TIDAK SCAN MASUK';
        statusType = 'missing';
        penalty = 10000;
        penaltyBreakdown.push('Tidak scan masuk pagi (Denda Rp 10.000)');

        // Also check if lastOut is early
        const outMin = timeToMinutes(lastOut);
        if (outMin !== null && outMin < 16 * 60 + 30) {
          earlyMinutes = 16 * 60 + 30 - outMin;
          penalty += 10000;
          penaltyBreakdown.push(`Pulang cepat ${earlyMinutes} menit sebelum 16:30 (Denda Rp 10.000)`);
          status = 'TIDAK SCAN MASUK + PULANG CEPAT';
        }
      } else if (firstIn && !lastOut) {
        // Missing OUT scan
        status = 'TIDAK SCAN PULANG';
        statusType = 'missing';
        penalty = 10000;
        penaltyBreakdown.push('Tidak scan pulang sore (Denda Rp 10.000)');

        // Also check if firstIn was late
        const inMin = timeToMinutes(firstIn);
        if (inMin !== null && inMin > 8 * 60 + 15) {
          lateMinutes = inMin - (8 * 60 + 15);
          const latePenalty = lateMinutes <= 60 ? 7500 : 10000;
          penalty += latePenalty;
          penaltyBreakdown.push(
            lateMinutes <= 60
              ? `Terlambat ${lateMinutes} menit (<= 60 mnt: Denda Rp 7.500)`
              : `Terlambat ${lateMinutes} menit (> 60 mnt: Denda Rp 10.000)`
          );
          status = 'TERLAMBAT + TIDAK SCAN PULANG';
          statusType = 'late';
        }
      } else if (firstIn && lastOut) {
        // Both scans present
        const inMin = timeToMinutes(firstIn);
        const outMin = timeToMinutes(lastOut);

        const isLate = inMin !== null && inMin > 8 * 60 + 15;
        const isEarly = outMin !== null && outMin < 16 * 60 + 30;

        if (isLate) {
          lateMinutes = (inMin || 0) - (8 * 60 + 15);
          const latePenalty = lateMinutes <= 60 ? 7500 : 10000;
          penalty += latePenalty;
          penaltyBreakdown.push(
            lateMinutes <= 60
              ? `Terlambat ${lateMinutes} menit (<= 60 mnt: Denda Rp 7.500)`
              : `Terlambat ${lateMinutes} menit (> 60 mnt: Denda Rp 10.000)`
          );
        }

        if (isEarly) {
          earlyMinutes = 16 * 60 + 30 - (outMin || 0);
          penalty += 10000;
          penaltyBreakdown.push(`Pulang cepat ${earlyMinutes} menit sebelum 16:30 (Denda Rp 10.000)`);
        }

        if (isLate && isEarly) {
          status = 'TERLAMBAT + PULANG CEPAT';
          statusType = 'late';
        } else if (isLate) {
          status = lateMinutes <= 60 ? 'TERLAMBAT <= 1 JAM' : 'TERLAMBAT > 1 JAM';
          statusType = 'late';
        } else if (isEarly) {
          status = 'PULANG LEBIH AWAL';
          statusType = 'early';
        } else {
          status = 'HADIR TEPAT WAKTU';
          statusType = 'ontime';
          penaltyBreakdown.push('Tepat waktu (Denda Rp 0)');
        }
      }
    }

    dailyRecords.push({
      id: `${empCode}-${row.isoDate}`,
      empNum: row.empNum,
      noId: row.noId,
      name: row.name,
      nip: empInfo?.nik || `19850101${String(empId).padStart(6, '0')}`,
      department,
      date: row.isoDate,
      dayName,
      firstIn,
      lastOut,
      allScans: dayPunches,
      status,
      statusType,
      lateMinutes,
      earlyMinutes,
      penalty,
      penaltyBreakdown,
      isHoliday,
      isWeekend,
      totalWorkHours: row.totalWorkHours,
    });
  }

  // Monthly aggregations for each employee
  const monthlyMap = new Map<number, EmployeeMonthlyAggregation>();

  for (const emp of employees) {
    monthlyMap.set(emp.id, {
      id: emp.id,
      code: emp.employee_code,
      nip: emp.nip || '-',
      name: emp.name,
      department: emp.department,
      position: emp.position,
      employeeType: emp.employment_status,
      totalWorkdays: 0,
      presentDays: 0,
      lateDays: 0,
      earlyDays: 0,
      missingScanDays: 0,
      alphaDays: 0,
      accumulatedLateMinutes: 0,
      accumulatedEarlyMinutes: 0,
      totalPenalty: 0,
      violations: [],
    });
  }

  for (const rec of dailyRecords) {
    const empId = parseInt(rec.empNum, 10) || 1;
    let summary = monthlyMap.get(empId);
    if (!summary) {
      summary = {
        id: empId,
        code: `EMP-${String(empId).padStart(3, '0')}`,
        nip: rec.nip,
        name: rec.name,
        department: rec.department,
        position: 'Pegawai',
        employeeType: 'PNS',
        totalWorkdays: 0,
        presentDays: 0,
        lateDays: 0,
        earlyDays: 0,
        missingScanDays: 0,
        alphaDays: 0,
        accumulatedLateMinutes: 0,
        accumulatedEarlyMinutes: 0,
        totalPenalty: 0,
        violations: [],
      };
      monthlyMap.set(empId, summary);
    }

    if (!rec.isWeekend && !rec.isHoliday) {
      summary.totalWorkdays += 1;

      if (rec.statusType === 'absent') {
        summary.alphaDays += 1;
      } else {
        summary.presentDays += 1;
      }

      if (rec.lateMinutes > 0) {
        summary.lateDays += 1;
        summary.accumulatedLateMinutes += rec.lateMinutes;
      }

      if (rec.earlyMinutes > 0) {
        summary.earlyDays += 1;
        summary.accumulatedEarlyMinutes += rec.earlyMinutes;
      }

      if (rec.statusType === 'missing') {
        summary.missingScanDays += 1;
      }

      summary.totalPenalty += rec.penalty;

      if (rec.penalty > 0) {
        summary.violations.push({
          date: rec.date.split('-').reverse().join('/'),
          dayName: rec.dayName,
          firstIn: rec.firstIn,
          lastOut: rec.lastOut,
          violationType: rec.status,
          durationMinutes: rec.lateMinutes || rec.earlyMinutes || 0,
          amount: rec.penalty,
        });
      }
    }
  }

  const monthlySummaries = Array.from(monthlyMap.values());

  return {
    rawRows,
    employees,
    dailyRecords,
    rawPunches,
    monthlySummaries,
  };
}

function inferDepartmentFromName(name: string): string {
  if (name.includes('S.Pi') || name.includes('M.Pi')) return 'Dinas Kelautan & Perikanan';
  if (name.includes('S.T') || name.includes('M.T') || name.includes('ST.MT')) return 'Dinas Pekerjaan Umum & Tata Ruang';
  if (name.includes('M.Kom')) return 'Dinas Komunikasi & Informatika';
  if (name.includes('SP.M.Sc')) return 'Dinas Pertanian & Ketahanan Pangan';
  if (name.includes('SE') || name.includes('S.E')) return 'Badan Pengelolaan Keuangan & Aset';
  if (name.includes('Ir')) return 'Badan Perencanaan Pembangunan Daerah';
  return 'Sekretariat Daerah';
}

function inferPositionFromName(name: string): string {
  if (name.includes('Ir Firman') || name.includes('Suharun')) return 'Kepala Bidang / Ahli Madya';
  if (name.includes('M.Kom') || name.includes('ST.MT')) return 'Pranata Komputer / Analis Sistem';
  if (name.includes('SE')) return 'Bendahara Pengeluaran / Analis Keuangan';
  if (name.includes('S.Pi') || name.includes('SP.M.Sc')) return 'Pengawas Mutu & Pembina Teknis';
  return 'Pelaksana Administrasi';
}

/**
 * Get active machine attendance data from LocalStorage or initialize with the user's provided CSV!
 */
export function getActiveMachineAttendanceData() {
  if (typeof window === 'undefined') {
    return parseMachineAttendanceCsv(USER_INITIAL_CSV);
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEY_MACHINE_ATTENDANCE);
    const csvContent = stored || USER_INITIAL_CSV;
    const parsed = parseMachineAttendanceCsv(csvContent);

    // If participants store is currently empty, automatically populate with the parsed employees!
    const existingEmployees = getStoredEmployees();
    if (existingEmployees.length === 0 && parsed.employees.length > 0) {
      saveStoredEmployees(parsed.employees);
    }

    return parsed;
  } catch (e) {
    console.error('Error reading machine attendance data:', e);
    return parseMachineAttendanceCsv(USER_INITIAL_CSV);
  }
}

/**
 * Save new machine attendance CSV data and notify all modules
 */
export function saveActiveMachineAttendanceCsv(csvText: string) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_MACHINE_ATTENDANCE, csvText);
    const parsed = parseMachineAttendanceCsv(csvText);

    // Also sync employees to participant store
    if (parsed.employees.length > 0) {
      saveStoredEmployees(parsed.employees);
    }

    window.dispatchEvent(
      new CustomEvent('attendance_data_updated', {
        detail: parsed,
      })
    );
  } catch (e) {
    console.error('Error saving machine attendance CSV:', e);
  }
}

/**
 * Reset to user's initial provided dataset
 */
export function resetToUserInitialAttendanceData() {
  saveActiveMachineAttendanceCsv(USER_INITIAL_CSV);
}

/**
 * Generates an Excel template matching the user's exact machine format
 */
export function downloadMachineFormatExcelTemplate() {
  const sampleData = [
    {
      'Emp Num.': '1',
      'No. ID.': '1',
      'NIK': '198501012010011001',
      'Nama': 'Suharun Mar.S.Pi.M.Si',
      'Tanggal': '03/08/2026',
      'Scan Masuk 1': '07:54:00',
      'Scan Pulang 1': '15:17:00',
      'Scan Masuk 2': '',
      'Scan Pulang 2': '',
      'Scan Masuk 3': '',
      'Scan Pulang 3': '',
      'Scan Masuk 4': '',
      'Scan Pulang 4': '',
      'Scan Masuk 5': '',
      'Scan Pulang 5': '',
      'Total Jam Kerja': '07:23:00',
    },
    {
      'Emp Num.': '4',
      'No. ID.': '4',
      'NIK': '198203152008011002',
      'Nama': 'Ir Firman M.Si',
      'Tanggal': '03/08/2026',
      'Scan Masuk 1': '07:17:00',
      'Scan Pulang 1': '17:08:00',
      'Scan Masuk 2': '',
      'Scan Pulang 2': '',
      'Scan Masuk 3': '',
      'Scan Pulang 3': '',
      'Scan Masuk 4': '',
      'Scan Pulang 4': '',
      'Scan Masuk 5': '',
      'Scan Pulang 5': '',
      'Total Jam Kerja': '09:51:00',
    },
    {
      'Emp Num.': '6',
      'No. ID.': '6',
      'NIK': '199005122015021003',
      'Nama': 'DedI P .S.Pi.M.Pi',
      'Tanggal': '03/08/2026',
      'Scan Masuk 1': '07:59:00',
      'Scan Pulang 1': '16:31:00',
      'Scan Masuk 2': '',
      'Scan Pulang 2': '',
      'Scan Masuk 3': '',
      'Scan Pulang 3': '',
      'Scan Masuk 4': '',
      'Scan Pulang 4': '',
      'Scan Masuk 5': '',
      'Scan Pulang 5': '',
      'Total Jam Kerja': '08:32:00',
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Absensi Mesin');

  XLSX.writeFile(workbook, 'Format_Data_Absensi_Mesin.xlsx');
}

/**
 * Downloads a sample CSV matching user's exact format
 */
export function downloadMachineFormatCsvSample() {
  const blob = new Blob([USER_INITIAL_CSV], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'Format_Data_Absensi_Mesin.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Transforms machine attendance records into raw punch logs (IN / OUT)
 * for Raw Attendance Management and device auditing
 */
export function getMachineRawAttendanceLogs(): Array<{
  id: number;
  employee_id: number | null;
  employee_code: string;
  employee_name: string | null;
  department: string | null;
  attendance_date: string;
  attendance_time: string;
  attendance_type: 'IN' | 'OUT';
  machine_id: string;
  is_duplicate: boolean;
  import_batch_id: number;
  raw_payload: {
    device_ip?: string;
    verify_mode?: number;
    work_code?: number;
    raw_string?: string;
    checksum?: string;
  };
}> {
  const data = getActiveMachineAttendanceData();
  const rawLogs: any[] = [];
  let logId = 5000;

  data.dailyRecords.forEach((rec) => {
    if (rec.firstIn) {
      logId++;
      rawLogs.push({
        id: logId,
        employee_id: rec.id,
        employee_code: rec.employee_code,
        employee_name: rec.name,
        department: rec.department,
        attendance_date: rec.date,
        attendance_time: rec.firstIn,
        attendance_type: 'IN',
        machine_id: 'MESIN-FINGER-01',
        is_duplicate: false,
        import_batch_id: 201,
        raw_payload: {
          device_ip: '192.168.1.201',
          verify_mode: 1,
          work_code: 0,
          raw_string: `${rec.employee_code};${rec.name};${rec.rawDate};${rec.firstIn}`,
          checksum: `chk_${rec.employee_code}_${rec.date}_in`
        }
      });
    }

    if (rec.lastOut) {
      logId++;
      rawLogs.push({
        id: logId,
        employee_id: rec.id,
        employee_code: rec.employee_code,
        employee_name: rec.name,
        department: rec.department,
        attendance_date: rec.date,
        attendance_time: rec.lastOut,
        attendance_type: 'OUT',
        machine_id: 'MESIN-FINGER-01',
        is_duplicate: false,
        import_batch_id: 201,
        raw_payload: {
          device_ip: '192.168.1.201',
          verify_mode: 1,
          work_code: 0,
          raw_string: `${rec.employee_code};${rec.name};${rec.rawDate};${rec.lastOut}`,
          checksum: `chk_${rec.employee_code}_${rec.date}_out`
        }
      });
    }
  });

  return rawLogs;
}
