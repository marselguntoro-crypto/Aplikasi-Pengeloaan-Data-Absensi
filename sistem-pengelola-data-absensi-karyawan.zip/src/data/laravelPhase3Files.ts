import { CodeFile } from './laravelCodeSnippets';

export const LARAVEL_PHASE3_FILES: CodeFile[] = [
  {
    title: 'AttendanceImportService (Core Import Engine & Parser)',
    category: 'Controller',
    path: 'app/Services/AttendanceImportService.php',
    description: 'Service utama pengolah file absensi mentah (.dat, .csv, .xlsx): chunking 500 baris, pencegahan duplikasi idempotent, transactional rollback, dan auto-remap pegawai.',
    code: `<?php

namespace App\Services;

use App\Models\AttendanceImport;
use App\Models\AttendanceRaw;
use App\Models\Employee;
use App\Models\AuditLog;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\\Carbon;

class AttendanceImportService
{
    /**
     * Parse and import raw attendance logs from uploaded file.
     */
    public function processImport(UploadedFile $file, array $options = [], ?int $userId = null): AttendanceImport
    {
        $originalFilename = $file->getClientOriginalName();
        $extension = strtolower($file->getClientOriginalExtension());
        $storedPath = $file->store('imports/attendance');

        // 1. Buat record attendance_imports status processing
        $importBatch = AttendanceImport::create([
            'filename' => basename($storedPath),
            'original_filename' => $originalFilename,
            'file_path' => $storedPath,
            'uploaded_by' => $userId,
            'status' => 'processing',
            'notes' => $options['notes'] ?? 'Batch upload log mesin absensi',
        ]);

        try {
            $parsedRows = $this->parseFile($file->getRealPath(), $extension, $options);
            $totalRows = count($parsedRows);

            if ($totalRows === 0) {
                throw new \\Exception('File kosong atau format baris tidak dikenali.');
            }

            // Cache master pegawai untuk lookup cepat [employee_code => id]
            $employeeMap = Employee::pluck('id', 'employee_code')->toArray();

            $successCount = 0;
            $duplicateCount = 0;
            $failedCount = 0;
            $errorDetails = [];

            // 2. Proses baris dengan chunking & database transaction
            $chunks = array_chunk($parsedRows, 500);

            foreach ($chunks as $chunk) {
                DB::transaction(function () use ($chunk, $importBatch, &$employeeMap, &$successCount, &$duplicateCount, &$failedCount, &$errorDetails) {
                    $insertData = [];

                    foreach ($chunk as $row) {
                        try {
                            $code = trim($row['employee_code'] ?? '');
                            $date = trim($row['attendance_date'] ?? '');
                            $time = trim($row['attendance_time'] ?? '');
                            $machine = trim($row['machine_id'] ?? 'DEVICE-01');
                            $type = strtoupper(trim($row['attendance_type'] ?? ''));

                            if (empty($code) || empty($date) || empty($time)) {
                                $failedCount++;
                                $errorDetails[] = [
                                    'row' => $row,
                                    'error' => 'Data tidak lengkap (Kode, Tanggal, atau Jam kosong)',
                                ];
                                continue;
                            }

                            // Format waktu standar HH:mm:ss
                            $formattedTime = Carbon::parse($time)->format('H:i:s');
                            $formattedDate = Carbon::parse($date)->format('Y-m-d');

                            // Cek duplikasi idempotent
                            $isDuplicate = AttendanceRaw::where('employee_code', $code)
                                ->where('attendance_date', $formattedDate)
                                ->where('attendance_time', $formattedTime)
                                ->where('machine_id', $machine)
                                ->exists();

                            if ($isDuplicate) {
                                $duplicateCount++;
                                continue;
                            }

                            // Resolve employee_id jika pegawai sudah terdaftar
                            $employeeId = $employeeMap[$code] ?? null;

                            // Infer tipe punch jika kosong
                            if (empty($type) || !in_array($type, ['IN', 'OUT'])) {
                                $type = $this->inferPunchType($formattedTime);
                            }

                            $insertData[] = [
                                'employee_id' => $employeeId,
                                'employee_code' => $code,
                                'employee_name' => $row['employee_name'] ?? null,
                                'attendance_date' => $formattedDate,
                                'attendance_time' => $formattedTime,
                                'attendance_type' => $type,
                                'machine_id' => $machine,
                                'raw_data' => json_encode($row['raw_payload'] ?? $row),
                                'import_id' => $importBatch->id,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ];

                            $successCount++;
                        } catch (\\Exception $rowEx) {
                            $failedCount++;
                            $errorDetails[] = [
                                'row' => $row,
                                'error' => $rowEx->getMessage(),
                            ];
                        }
                    }

                    if (!empty($insertData)) {
                        AttendanceRaw::insert($insertData);
                    }
                });
            }

            // 3. Update status batch selesai
            $importBatch->update([
                'total_rows' => $totalRows,
                'success_rows' => $successCount,
                'duplicate_rows' => $duplicateCount,
                'failed_rows' => $failedCount,
                'status' => 'completed',
                'notes' => json_encode([
                    'processed_at' => now()->toDateTimeString(),
                    'unmapped_count' => AttendanceRaw::where('import_id', $importBatch->id)->whereNull('employee_id')->count(),
                    'error_samples' => array_slice($errorDetails, 0, 10),
                ]),
            ]);

            // Audit log
            AuditLog::create([
                'user_id' => $userId,
                'action' => 'IMPORT_RAW_ATTENDANCE',
                'model' => AttendanceImport::class,
                'model_id' => $importBatch->id,
                'payload_after' => [
                    'filename' => $originalFilename,
                    'total' => $totalRows,
                    'success' => $successCount,
                    'duplicates' => $duplicateCount,
                ],
                'ip_address' => request()->ip(),
            ]);

            return $importBatch;
        } catch (\\Throwable $e) {
            Log::error("Gagal memproses import batch #{$importBatch->id}: " . $e->getMessage());

            $importBatch->update([
                'status' => 'failed',
                'notes' => 'Fatal Error: ' . $e->getMessage(),
            ]);

            throw $e;
        }
    }

    /**
     * Parser multi-format: CSV, TSV, dan DAT (ZKTeco text format)
     */
    protected function parseFile(string $filePath, string $extension, array $options): array
    {
        $rows = [];

        if (in_array($extension, ['dat', 'txt'])) {
            // Parser Format Mesin ZKTeco/Solution: [PIN\\tDateTime\\tStatus\\tVerifyMode...]
            $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                $parts = preg_split('/\\s+|\\t/', trim($line));
                if (count($parts) >= 2) {
                    $code = $parts[0];
                    $datetime = $parts[1] . (isset($parts[2]) && preg_match('/^\\d{2}:\\d{2}/', $parts[2]) ? ' ' . $parts[2] : '');
                    
                    try {
                        $parsedDt = Carbon::parse($datetime);
                        $state = isset($parts[3]) ? (int)$parts[3] : (isset($parts[2]) && is_numeric($parts[2]) ? (int)$parts[2] : 0);
                        
                        $rows[] = [
                            'employee_code' => $code,
                            'attendance_date' => $parsedDt->format('Y-m-d'),
                            'attendance_time' => $parsedDt->format('H:i:s'),
                            'attendance_type' => $state === 1 ? 'OUT' : 'IN',
                            'machine_id' => $options['machine_id'] ?? 'ZKT-LOBBY-01',
                            'raw_payload' => ['raw_line' => $line],
                        ];
                    } catch (\\Exception $ex) {
                        continue;
                    }
                }
            }
        } else {
            // Parser CSV / TSV
            if (($handle = fopen($filePath, 'r')) !== false) {
                $delimiter = $options['delimiter'] ?? ',';
                $header = fgetcsv($handle, 2000, $delimiter);

                // Auto-detect header mapping
                while (($data = fgetcsv($handle, 2000, $delimiter)) !== false) {
                    if (empty($data) || count($data) < 2) continue;
                    
                    $rowAssoc = [];
                    foreach ($header as $i => $colName) {
                        $colClean = strtolower(trim(str_replace([' ', '_', '-'], '', $colName)));
                        $rowAssoc[$colClean] = $data[$i] ?? null;
                    }

                    $code = $rowAssoc['employeecode'] ?? $rowAssoc['badgenumber'] ?? $rowAssoc['nip'] ?? $rowAssoc['pin'] ?? $data[0] ?? '';
                    $dtString = $rowAssoc['timestamp'] ?? $rowAssoc['datetime'] ?? $rowAssoc['waktu'] ?? ($data[1] ?? '');
                    $type = $rowAssoc['type'] ?? $rowAssoc['punch'] ?? $rowAssoc['tipe'] ?? ($data[2] ?? '');
                    $machine = $rowAssoc['machine'] ?? $rowAssoc['device'] ?? $rowAssoc['mesin'] ?? ($options['machine_id'] ?? 'IMPORT-CSV');

                    try {
                        $dt = Carbon::parse($dtString);
                        $rows[] = [
                            'employee_code' => $code,
                            'attendance_date' => $dt->format('Y-m-d'),
                            'attendance_time' => $dt->format('H:i:s'),
                            'attendance_type' => strtoupper($type),
                            'machine_id' => $machine,
                            'raw_payload' => $rowAssoc,
                        ];
                    } catch (\\Exception $e) {
                        continue;
                    }
                }
                fclose($handle);
            }
        }

        return $rows;
    }

    /**
     * Heuristic Punch Inference: Pagi (< 12:00) = IN, Sore (>= 12:00) = OUT
     */
    protected function inferPunchType(string $time): string
    {
        $hour = (int) substr($time, 0, 2);
        return $hour < 12 ? 'IN' : 'OUT';
    }
}
`
  },
  {
    title: 'RawAttendanceService (Query, Remap Orphan, Punch Correction)',
    category: 'Controller',
    path: 'app/Services/RawAttendanceService.php',
    description: 'Layanan manajemen data mentah: filter stream transaksi, deteksi log tanpa relasi pegawai (orphan), bulk re-map pasca pendaftaran pegawai, dan koreksi audit trail.',
    code: `<?php

namespace App\Services;

use App\Models\AttendanceRaw;
use App\Models\Employee;
use App\Models\AuditLog;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class RawAttendanceService
{
    /**
     * Query data mentah dengan filter multi-parameter.
     */
    public function getFilteredLogs(array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        $query = AttendanceRaw::with('employee', 'importBatch')
            ->orderBy('attendance_date', 'desc')
            ->orderBy('attendance_time', 'desc');

        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->where('employee_code', 'like', "%{$search}%")
                  ->orWhere('employee_name', 'like', "%{$search}%")
                  ->orWhere('machine_id', 'like', "%{$search}%")
                  ->orWhereHas('employee', function ($eq) use ($search) {
                      $eq->where('name', 'like', "%{$search}%")
                        ->orWhere('nip', 'like', "%{$search}%");
                  });
            });
        }

        if (!empty($filters['date'])) {
            $query->where('attendance_date', $filters['date']);
        }

        if (!empty($filters['machine_id'])) {
            $query->where('machine_id', $filters['machine_id']);
        }

        if (!empty($filters['attendance_type'])) {
            $query->where('attendance_type', $filters['attendance_type']);
        }

        if (isset($filters['is_mapped'])) {
            if ($filters['is_mapped'] === '0' || $filters['is_mapped'] === false) {
                $query->whereNull('employee_id');
            } elseif ($filters['is_mapped'] === '1' || $filters['is_mapped'] === true) {
                $query->whereNotNull('employee_id');
            }
        }

        return $query->paginate($perPage);
    }

    /**
     * Resolusi otomatis: Hubungkan log mentah yang unmapped ke pegawai yang baru terdaftar.
     */
    public function remapOrphanLogs(?string $employeeCode = null): int
    {
        $query = AttendanceRaw::whereNull('employee_id');

        if ($employeeCode) {
            $query->where('employee_code', $employeeCode);
        }

        $unmappedCodes = $query->distinct()->pluck('employee_code');
        $affectedTotal = 0;

        foreach ($unmappedCodes as $code) {
            $employee = Employee::where('employee_code', $code)->first();
            if ($employee) {
                $count = AttendanceRaw::where('employee_code', $code)
                    ->whereNull('employee_id')
                    ->update([
                        'employee_id' => $employee->id,
                        'employee_name' => $employee->name,
                    ]);
                $affectedTotal += $count;
            }
        }

        return $affectedTotal;
    }

    /**
     * Koreksi tipe punch (IN/OUT) dengan catatan audit log tanpa merusak string asli raw_data.
     */
    public function correctPunchType(int $rawId, string $newType, string $reason, int $userId): AttendanceRaw
    {
        $raw = AttendanceRaw::findOrFail($rawId);
        $oldType = $raw->attendance_type;

        $raw->update([
            'attendance_type' => strtoupper($newType),
        ]);

        AuditLog::create([
            'user_id' => $userId,
            'action' => 'CORRECT_RAW_PUNCH_TYPE',
            'model' => AttendanceRaw::class,
            'model_id' => $raw->id,
            'payload_before' => ['attendance_type' => $oldType],
            'payload_after' => ['attendance_type' => $newType, 'reason' => $reason],
            'ip_address' => request()->ip(),
        ]);

        return $raw;
    }
}
`
  },
  {
    title: 'AttendanceImportController (Batch Upload & Review)',
    category: 'Controller',
    path: 'app/Http/Controllers/AttendanceImportController.php',
    description: 'Controller untuk halaman upload log absensi, tracking progress batch, preview parsing file, dan download template mesin.',
    code: `<?php

namespace App\Http\Controllers;

use App\Http\Requests\ImportAttendanceRequest;
use App\Models\AttendanceImport;
use App\Models\AttendanceRaw;
use App\Services\AttendanceImportService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class AttendanceImportController extends Controller
{
    protected AttendanceImportService $importService;

    public function __construct(AttendanceImportService $importService)
    {
        $this->importService = $importService;
    }

    /**
     * Tampilkan riwayat batch import file absensi.
     */
    public function index(Request $request)
    {
        $imports = AttendanceImport::with('uploader')
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        $stats = [
            'total_batches' => AttendanceImport::count(),
            'total_rows_imported' => AttendanceImport::sum('success_rows'),
            'total_duplicates_ignored' => AttendanceImport::sum('duplicate_rows'),
            'unmapped_logs' => AttendanceRaw::whereNull('employee_id')->count(),
        ];

        return view('attendance.imports.index', compact('imports', 'stats'));
    }

    /**
     * Form upload file log absensi (.dat, .csv, .xlsx).
     */
    public function create()
    {
        return view('attendance.imports.create');
    }

    /**
     * Eksekusi proses import file.
     */
    public function store(ImportAttendanceRequest $request)
    {
        $file = $request->file('attendance_file');
        $options = [
            'notes' => $request->input('notes'),
            'machine_id' => $request->input('machine_id', 'AUTO-DETECT'),
            'delimiter' => $request->input('delimiter', ','),
        ];

        $batch = $this->importService->processImport($file, $options, auth()->id());

        return redirect()->route('attendance.imports.show', $batch->id)
            ->with('success', "Batch #{$batch->id} berhasil diproses: {$batch->success_rows} data sukses, {$batch->duplicate_rows} duplikat diabaikan.");
    }

    /**
     * Detail batch import dan rincian data baris.
     */
    public function show(int $id)
    {
        $batch = AttendanceImport::with('uploader')->findOrFail($id);
        $rawLogs = AttendanceRaw::where('import_id', $batch->id)->paginate(25);

        return view('attendance.imports.show', compact('batch', 'rawLogs'));
    }

    /**
     * Download template format import absensi (CSV & DAT).
     */
    public function downloadTemplate(string $format = 'csv')
    {
        if ($format === 'dat') {
            $sample = "101\\t2026-08-10 08:05:12\\t1\\t0\\n102\\t2026-08-10 08:12:45\\t1\\t0\\n101\\t2026-08-10 16:35:20\\t1\\t1\\n";
            return response($sample)
                ->header('Content-Type', 'text/plain')
                ->header('Content-Disposition', 'attachment; filename="zkteco_sample.dat"');
        }

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="template_absensi_mentah.csv"',
        ];

        $callback = function () {
            $file = fopen('php://output', 'w');
            fputcsv($file, ['employee_code', 'datetime', 'type', 'machine_id']);
            fputcsv($file, ['PEG001', '2026-08-10 08:10:00', 'IN', 'FINGER-LOBBY-01']);
            fputcsv($file, ['PEG001', '2026-08-10 16:35:00', 'OUT', 'FINGER-LOBBY-01']);
            fputcsv($file, ['PEG002', '2026-08-10 08:25:00', 'IN', 'FACE-DOOR-02']);
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
`
  },
  {
    title: 'RawAttendanceController (Stream Log & Audit View)',
    category: 'Controller',
    path: 'app/Http/Controllers/RawAttendanceController.php',
    description: 'Controller untuk monitoring data absensi mentah: filter real-time, inspect JSON payload mesin, trigger re-map orphan, dan koreksi tipe punch.',
    code: `<?php

namespace App\Http\Controllers;

use App\Models\AttendanceRaw;
use App\Models\Employee;
use App\Services\RawAttendanceService;
use Illuminate\Http\Request;

class RawAttendanceController extends Controller
{
    protected RawAttendanceService $rawService;

    public function __construct(RawAttendanceService $rawService)
    {
        $this->rawService = $rawService;
    }

    /**
     * Stream log absensi mentah dengan filter lengkap.
     */
    public function index(Request $request)
    {
        $filters = [
            'search' => $request->input('search'),
            'date' => $request->input('date'),
            'machine_id' => $request->input('machine_id'),
            'attendance_type' => $request->input('type'),
            'is_mapped' => $request->input('is_mapped'),
        ];

        $logs = $this->rawService->getFilteredLogs($filters);
        
        $machineList = AttendanceRaw::distinct()->pluck('machine_id')->filter()->values();
        $unmappedCount = AttendanceRaw::whereNull('employee_id')->count();

        return view('attendance.raw.index', compact('logs', 'filters', 'machineList', 'unmappedCount'));
    }

    /**
     * Tampilkan JSON detail transaksi mentah dari mesin.
     */
    public function showPayload(int $id)
    {
        $log = AttendanceRaw::with('employee', 'importBatch')->findOrFail($id);

        return response()->json([
            'id' => $log->id,
            'employee_code' => $log->employee_code,
            'employee' => $log->employee,
            'attendance_date' => $log->attendance_date->toDateString(),
            'attendance_time' => $log->attendance_time,
            'attendance_type' => $log->attendance_type,
            'machine_id' => $log->machine_id,
            'raw_data' => json_decode($log->raw_data, true),
            'import_batch' => $log->importBatch,
            'created_at' => $log->created_at->toDateTimeString(),
        ]);
    }

    /**
     * Trigger bulk re-mapping data log unmapped ke tabel pegawai.
     */
    public function remap(Request $request)
    {
        $code = $request->input('employee_code');
        $affected = $this->rawService->remapOrphanLogs($code);

        return redirect()->back()->with('success', "Proses Re-Map Selesai: {$affected} log mentah berhasil dihubungkan ke data pegawai.");
    }

    /**
     * Koreksi manual tipe punch (IN/OUT) dengan alasan audit.
     */
    public function updatePunchType(Request $request, int $id)
    {
        $request->validate([
            'type' => 'required|in:IN,OUT',
            'reason' => 'required|string|min:5|max:255',
        ]);

        $this->rawService->correctPunchType($id, $request->type, $request->reason, auth()->id());

        return redirect()->back()->with('success', 'Tipe punch absensi berhasil diperbarui dan tercatat di audit log.');
    }
}
`
  },
  {
    title: 'AttendanceRaw (Model Eloquent & Scopes)',
    category: 'Model',
    path: 'app/Models/AttendanceRaw.php',
    description: 'Model Eloquent untuk tabel attendance_raw: query scopes unmapped, relasi employee, relasi import batch, dan proteksi immutability payload mesin.',
    code: `<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AttendanceRaw extends Model
{
    use HasFactory;

    protected $table = 'attendance_raw';

    protected $fillable = [
        'employee_id',
        'employee_code',
        'employee_name',
        'attendance_date',
        'attendance_time',
        'attendance_type',
        'machine_id',
        'raw_data',
        'import_id',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'raw_data' => 'array',
    ];

    /**
     * Relasi ke master pegawai.
     */
    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    /**
     * Relasi ke batch import pengunggah.
     */
    public function importBatch(): BelongsTo
    {
        return $this->belongsTo(AttendanceImport::class, 'import_id');
    }

    /**
     * Scope query untuk log yang belum terhubung ke master pegawai (Orphan).
     */
    public function scopeUnmapped($query)
    {
        return $query->whereNull('employee_id');
    }

    /**
     * Scope query untuk log yang sudah terhubung ke pegawai.
     */
    public function scopeMapped($query)
    {
        return $query->whereNotNull('employee_id');
    }

    /**
     * Scope filter berdasarkan tanggal tertentu.
     */
    public function scopeForDate($query, $date)
    {
        return $query->where('attendance_date', $date);
    }
}
`
  },
  {
    title: 'AttendanceImport (Model Eloquent Batch)',
    category: 'Model',
    path: 'app/Models/AttendanceImport.php',
    description: 'Model Eloquent untuk tabel attendance_imports: mencatat metrik total baris, baris sukses, duplikat yang diabaikan, dan status pemrosesan.',
    code: `<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AttendanceImport extends Model
{
    use HasFactory;

    protected $table = 'attendance_imports';

    protected $fillable = [
        'filename',
        'original_filename',
        'file_path',
        'uploaded_by',
        'total_rows',
        'success_rows',
        'duplicate_rows',
        'failed_rows',
        'status',
        'notes',
    ];

    /**
     * Relasi ke user yang mengunggah file.
     */
    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    /**
     * Relasi ke seluruh data mentah yang dihasilkan dari batch ini.
     */
    public function rawLogs(): HasMany
    {
        return $this->hasMany(AttendanceRaw::class, 'import_id');
    }

    /**
     * Hitung persentase keberhasilan import.
     */
    public function getSuccessRateAttribute(): float
    {
        if ($this->total_rows === 0) return 0.0;
        return round(($this->success_rows / $this->total_rows) * 100, 1);
    }
}
`
  },
  {
    title: 'ImportAttendanceRequest (Validation Rules)',
    category: 'Controller',
    path: 'app/Http/Requests/ImportAttendanceRequest.php',
    description: 'Validasi form upload absensi mentah: batas ukuran 20MB, ekstensi file csv, xlsx, dat, txt, serta validasi opsi delimitasi.',
    code: `<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ImportAttendanceRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Hanya user dengan permission import-attendance atau role admin/operator
        return true;
    }

    public function rules(): array
    {
        return [
            'attendance_file' => [
                'required',
                'file',
                'max:20480', // Maksimal 20 MB
                'mimes:csv,txt,dat,xlsx,xls',
            ],
            'machine_id' => ['nullable', 'string', 'max:50'],
            'delimiter' => ['nullable', 'string', 'in:,,;,\\t'],
            'notes' => ['nullable', 'string', 'max:255'],
            'auto_calculate_daily' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'attendance_file.required' => 'Wajib melampirkan berkas log absensi.',
            'attendance_file.mimes' => 'Format berkas harus berupa .CSV, .DAT (ZKTeco text), .TXT, atau .XLSX.',
            'attendance_file.max' => 'Ukuran berkas tidak boleh melebihi 20 MB.',
        ];
    }
}
`
  },
  {
    title: 'Artisan: ImportAttendanceMachineCommand',
    category: 'Artisan & CLI',
    path: 'app/Console/Commands/ImportAttendanceMachineCommand.php',
    description: 'Command line artisan: php artisan attendance:import-raw {file} --machine=M01 --auto-process untuk integrasi cron job terjadwal.',
    code: `<?php

namespace App\Console\Commands;

use App\Services\AttendanceImportService;
use Illuminate\Console\Command;
use Illuminate\Http\UploadedFile;

class ImportAttendanceMachineCommand extends Command
{
    protected $signature = 'attendance:import-raw 
                            {file : Path relatif atau absolut ke berkas log (.dat, .csv)} 
                            {--machine=AUTO : ID mesin absensi}
                            {--auto-process : Jalankan kalkulasi harian setelah import}';

    protected $description = 'Mengimpor berkas log transaksi absensi mentah ke database secara otomatis';

    public function handle(AttendanceImportService $service): int
    {
        $filePath = $this->argument('file');

        if (!file_exists($filePath)) {
            $this->error("Berkas [{$filePath}] tidak ditemukan.");
            return Command::FAILURE;
        }

        $this->info("Memulai impor berkas: {$filePath}...");

        $uploadedFile = new UploadedFile(
            $filePath,
            basename($filePath),
            mime_content_type($filePath) ?: 'text/plain',
            null,
            true
        );

        $options = [
            'machine_id' => $this->option('machine'),
            'notes' => 'CLI Automated Import by cron',
        ];

        try {
            $batch = $service->processImport($uploadedFile, $options, null);

            $this->table(
                ['Batch ID', 'Total Baris', 'Sukses', 'Duplikat', 'Gagal', 'Status'],
                [[$batch->id, $batch->total_rows, $batch->success_rows, $batch->duplicate_rows, $batch->failed_rows, $batch->status]]
            );

            if ($this->option('auto-process')) {
                $this->info("Memicu kalkulasi absensi harian...");
                $this->call('attendance:calculate-daily', ['--date' => now()->toDateString()]);
            }

            $this->info("Impor log absensi selesai dengan sukses.");
            return Command::SUCCESS;
        } catch (\\Exception $e) {
            $this->error("Gagal melakukan impor: " . $e->getMessage());
            return Command::FAILURE;
        }
    }
}
`
  },
  {
    title: 'Blade: attendance/raw/index.blade.php',
    category: 'View',
    path: 'resources/views/attendance/raw/index.blade.php',
    description: 'Tampilan antarmuka Blade untuk monitoring data absensi mentah: filter real-time, badge status mapping, modal inspeksi JSON payload.',
    code: `@extends('layouts.app')

@section('title', 'Data Absensi Mentah (Raw Logs)')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Log Absensi Mentah (attendance_raw)</h1>
            <p class="text-sm text-slate-500 mt-1">Data rekaman asli dari mesin sidik jari dan face recognition tanpa alterasi.</p>
        </div>
        <div class="flex items-center gap-2">
            @if($unmappedCount > 0)
                <form action="{{ route('attendance.raw.remap') }}" method="POST">
                    @csrf
                    <button type="submit" class="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">
                        Re-Map {{ $unmappedCount }} Log Pegawai
                    </button>
                </form>
            @endif
            <a href="{{ route('attendance.imports.create') }}" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors">
                + Upload File Absensi
            </a>
        </div>
    </div>

    {{-- Filter Card --}}
    <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <form method="GET" action="{{ route('attendance.raw.index') }}" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari kode/nama pegawai..." class="px-3 py-2 text-xs border border-slate-200 rounded-xl">
            <input type="date" name="date" value="{{ request('date') }}" class="px-3 py-2 text-xs border border-slate-200 rounded-xl">
            <select name="type" class="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white">
                <option value="">Semua Tipe Punch</option>
                <option value="IN" {{ request('type') == 'IN' ? 'selected' : '' }}>Masuk (IN)</option>
                <option value="OUT" {{ request('type') == 'OUT' ? 'selected' : '' }}>Pulang (OUT)</option>
            </select>
            <select name="is_mapped" class="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white">
                <option value="">Semua Status Relasi</option>
                <option value="1" {{ request('is_mapped') == '1' ? 'selected' : '' }}>Terpetakan</option>
                <option value="0" {{ request('is_mapped') == '0' ? 'selected' : '' }}>Belum Terpetakan</option>
            </select>
            <button type="submit" class="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-xl">Terapkan Filter</button>
        </form>
    </div>

    {{-- Tabel Log Mentah --}}
    <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                    <th class="p-3.5">Waktu Transaksi</th>
                    <th class="p-3.5">Kode Pegawai</th>
                    <th class="p-3.5">Nama Pegawai Terpetakan</th>
                    <th class="p-3.5">Mesin ID</th>
                    <th class="p-3.5 text-center">Tipe Punch</th>
                    <th class="p-3.5 text-center">Status Pemetaan</th>
                    <th class="p-3.5 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse($logs as $log)
                    <tr class="hover:bg-slate-50/80">
                        <td class="p-3.5 font-mono">
                            <span class="font-bold text-slate-900">{{ $log->attendance_time }}</span>
                            <span class="text-slate-400 block text-[11px]">{{ $log->attendance_date->format('d/m/Y') }}</span>
                        </td>
                        <td class="p-3.5 font-mono font-bold text-slate-800">{{ $log->employee_code }}</td>
                        <td class="p-3.5">
                            @if($log->employee)
                                <span class="font-semibold text-slate-900">{{ $log->employee->name }}</span>
                                <span class="text-slate-400 block text-[11px]">{{ $log->employee->department }}</span>
                            @else
                                <span class="text-amber-600 italic">Belum terdaftar di master pegawai</span>
                            @endif
                        </td>
                        <td class="p-3.5 font-mono text-slate-600">{{ $log->machine_id }}</td>
                        <td class="p-3.5 text-center">
                            <span class="px-2 py-0.5 rounded text-[11px] font-bold {{ $log->attendance_type == 'IN' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800' }}">
                                {{ $log->attendance_type }}
                            </span>
                        </td>
                        <td class="p-3.5 text-center">
                            @if($log->employee_id)
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Mapped</span>
                            @else
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">Orphan</span>
                            @endif
                        </td>
                        <td class="p-3.5 text-center">
                            <button onclick="inspectPayload({{ $log->id }})" class="text-slate-500 hover:text-slate-900 font-mono text-[11px] underline">
                                Inspect JSON
                            </button>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="p-8 text-center text-slate-400">Tidak ada log absensi yang cocok.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        <div class="p-4 border-t border-slate-100">
            {{ $logs->links() }}
        </div>
    </div>
</div>
@endsection
`
  },
  {
    title: 'Blade: attendance/imports/index.blade.php',
    category: 'View',
    path: 'resources/views/attendance/imports/index.blade.php',
    description: 'Tampilan antarmuka Blade untuk monitoring batch riwayat import absensi, persentase keberhasilan, dan ringkasan duplikasi.',
    code: `@extends('layouts.app')

@section('title', 'Riwayat Batch Import Absensi')

@section('content')
<div class="space-y-6">
    <div class="flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Riwayat Batch Import Absensi</h1>
            <p class="text-sm text-slate-500 mt-1">Lacak berkas log mesin yang diimpor ke sistem beserta metrik deduplikasi.</p>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('attendance.imports.download-template', 'csv') }}" class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 font-medium text-xs rounded-xl hover:bg-slate-50">
                Unduh Template CSV
            </a>
            <a href="{{ route('attendance.imports.download-template', 'dat') }}" class="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 font-medium text-xs rounded-xl hover:bg-slate-50">
                Unduh Sample DAT
            </a>
            <a href="{{ route('attendance.imports.create') }}" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl">
                + Upload Berkas Baru
            </a>
        </div>
    </div>

    {{-- Stats Cards --}}
    <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div class="p-4 bg-white rounded-xl border border-slate-200">
            <span class="text-xs text-slate-400 uppercase font-bold">Total Batch</span>
            <p class="text-2xl font-bold text-slate-900 mt-1">{{ $stats['total_batches'] }}</p>
        </div>
        <div class="p-4 bg-white rounded-xl border border-slate-200">
            <span class="text-xs text-emerald-600 uppercase font-bold">Total Baris Sukses</span>
            <p class="text-2xl font-bold text-emerald-700 mt-1">{{ number_format($stats['total_rows_imported']) }}</p>
        </div>
        <div class="p-4 bg-white rounded-xl border border-slate-200">
            <span class="text-xs text-amber-600 uppercase font-bold">Duplikat Diabaikan</span>
            <p class="text-2xl font-bold text-amber-700 mt-1">{{ number_format($stats['total_duplicates_ignored']) }}</p>
        </div>
        <div class="p-4 bg-white rounded-xl border border-slate-200">
            <span class="text-xs text-rose-600 uppercase font-bold">Log Tanpa Pegawai</span>
            <p class="text-2xl font-bold text-rose-700 mt-1">{{ number_format($stats['unmapped_logs']) }}</p>
        </div>
    </div>

    {{-- Tabel Batch --}}
    <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <table class="w-full text-left text-xs">
            <thead class="bg-slate-50 text-slate-500 font-bold uppercase border-b border-slate-200">
                <tr>
                    <th class="p-3.5">ID Batch</th>
                    <th class="p-3.5">Nama Berkas Asli</th>
                    <th class="p-3.5">Waktu Unggah</th>
                    <th class="p-3.5">Pengunggah</th>
                    <th class="p-3.5 text-center">Total Baris</th>
                    <th class="p-3.5 text-center">Sukses</th>
                    <th class="p-3.5 text-center">Duplikat</th>
                    <th class="p-3.5 text-center">Status</th>
                    <th class="p-3.5 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                @forelse($imports as $batch)
                    <tr class="hover:bg-slate-50">
                        <td class="p-3.5 font-mono font-bold text-slate-800">#{{ $batch->id }}</td>
                        <td class="p-3.5 font-medium text-slate-900">{{ $batch->original_filename }}</td>
                        <td class="p-3.5 text-slate-500 font-mono">{{ $batch->created_at->format('d M Y H:i') }}</td>
                        <td class="p-3.5 text-slate-600">{{ $batch->uploader->name ?? 'System / CLI' }}</td>
                        <td class="p-3.5 text-center font-mono">{{ $batch->total_rows }}</td>
                        <td class="p-3.5 text-center font-mono text-emerald-600 font-bold">{{ $batch->success_rows }}</td>
                        <td class="p-3.5 text-center font-mono text-amber-600">{{ $batch->duplicate_rows }}</td>
                        <td class="p-3.5 text-center">
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold {{ $batch->status == 'completed' ? 'bg-emerald-100 text-emerald-800' : ($batch->status == 'processing' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800') }}">
                                {{ strtoupper($batch->status) }}
                            </span>
                        </td>
                        <td class="p-3.5 text-center">
                            <a href="{{ route('attendance.imports.show', $batch->id) }}" class="text-indigo-600 hover:text-indigo-800 font-semibold">
                                Rincian &rarr;
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="p-8 text-center text-slate-400">Belum ada riwayat batch import.</td></tr>
                @endforelse
            </tbody>
        </table>
        <div class="p-4 border-t border-slate-100">
            {{ $imports->links() }}
        </div>
    </div>
</div>
@endsection
`
  },
  {
    title: 'Pest Feature Test: AttendanceImportTest',
    category: 'Controller',
    path: 'tests/Feature/AttendanceImportTest.php',
    description: 'Unit & Feature Test menggunakan Pest PHP: menguji deduplikasi, idempotensi import berkas yang sama dua kali, dan auto-remap kode pegawai.',
    code: `<?php

use App\Models\AttendanceImport;
use App\Models\AttendanceRaw;
use App\Models\Employee;
use App\Models\User;
use App\Services\AttendanceImportService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

beforeEach(function () {
    Storage::fake('imports/attendance');
    $this->user = User::factory()->create(['role' => 'admin']);
    $this->employee = Employee::factory()->create([
        'employee_code' => 'PEG001',
        'name' => 'Budi Santoso',
    ]);
});

test('dapat mengimpor file absensi csv dan menghubungkan ke employee_id', function () {
    $content = "employee_code,datetime,type,machine_id\\nPEG001,2026-08-10 08:10:00,IN,FINGER-01\\n";
    $file = UploadedFile::fake()->createWithContent('absensi.csv', $content);

    $service = app(AttendanceImportService::class);
    $batch = $service->processImport($file, [], $this->user->id);

    expect($batch->status)->toBe('completed')
        ->and($batch->success_rows)->toBe(1)
        ->and($batch->duplicate_rows)->toBe(0);

    $raw = AttendanceRaw::first();
    expect($raw->employee_id)->toBe($this->employee->id)
        ->and($raw->employee_code)->toBe('PEG001')
        ->and($raw->attendance_type)->toBe('IN');
});

test('mengabaikan duplikasi secara idempotent saat file diupload ulang', function () {
    $content = "employee_code,datetime,type,machine_id\\nPEG001,2026-08-10 08:10:00,IN,FINGER-01\\n";
    $file1 = UploadedFile::fake()->createWithContent('absensi_1.csv', $content);
    $file2 = UploadedFile::fake()->createWithContent('absensi_2.csv', $content);

    $service = app(AttendanceImportService::class);
    
    // Import pertama
    $batch1 = $service->processImport($file1, [], $this->user->id);
    expect($batch1->success_rows)->toBe(1);

    // Import kedua dengan data yang persis sama
    $batch2 = $service->processImport($file2, [], $this->user->id);
    expect($batch2->success_rows)->toBe(0)
        ->and($batch2->duplicate_rows)->toBe(1);

    expect(AttendanceRaw::count())->toBe(1);
});
`
  }
];
