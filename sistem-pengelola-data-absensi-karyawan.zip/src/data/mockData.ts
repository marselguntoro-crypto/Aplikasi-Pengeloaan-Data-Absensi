export interface RawAttendanceLog {
  id: number;
  time: string;
  code: string;
  name: string;
  department: string;
  type: string;
  machine: string;
  statusColor: string;
}

export interface EmployeeDailyRecord {
  id: number;
  code: string;
  nip: string;
  name: string;
  department: string;
  firstIn: string | null;
  lastOut: string | null;
  status: string;
  lateMinutes: number;
  earlyMinutes: number;
  penalty: number;
  statusType: 'ontime' | 'late' | 'early' | 'missing' | 'absent' | 'holiday';
}

// Dummy participants removed as requested by user to allow clean upload of real participants
export const SAMPLE_EMPLOYEES: EmployeeDailyRecord[] = [];

export const SAMPLE_RAW_LOGS: RawAttendanceLog[] = [
  { id: 101, time: '16:40:12', code: 'EMP-003', name: 'Ahmad Fauzi, M.T', department: 'Perencanaan', type: 'OUT', machine: 'FINGER-LOBBY-01', statusColor: 'slate' },
  { id: 102, time: '16:35:45', code: 'EMP-001', name: 'Budi Santoso, S.Kom', department: 'TIK', type: 'OUT', machine: 'FACE-DOOR-02', statusColor: 'emerald' },
  { id: 103, time: '16:30:19', code: 'EMP-002', name: 'Siti Rahmawati, S.E', department: 'Keuangan', type: 'OUT', machine: 'FINGER-LOBBY-01', statusColor: 'emerald' },
  { id: 104, time: '16:30:05', code: 'EMP-006', name: 'Rudi Hartono, A.Md', department: 'Sarpras', type: 'OUT', machine: 'FINGER-LOBBY-02', statusColor: 'emerald' },
  { id: 105, time: '16:05:30', code: 'EMP-005', name: 'Hendro Wijaya, S.Pd', department: 'Tata Usaha', type: 'OUT', machine: 'FINGER-LOBBY-01', statusColor: 'amber' },
  { id: 106, time: '16:00:15', code: 'EMP-004', name: 'Dewi Lestari, S.Psi', department: 'Kepegawaian', type: 'OUT', machine: 'FACE-DOOR-01', statusColor: 'amber' },
  { id: 107, time: '09:30:22', code: 'EMP-003', name: 'Ahmad Fauzi, M.T', department: 'Perencanaan', type: 'IN', machine: 'FINGER-LOBBY-01', statusColor: 'rose' },
  { id: 108, time: '08:45:10', code: 'EMP-002', name: 'Siti Rahmawati, S.E', department: 'Keuangan', type: 'IN', machine: 'FACE-DOOR-02', statusColor: 'amber' },
  { id: 109, time: '08:40:48', code: 'EMP-005', name: 'Hendro Wijaya, S.Pd', department: 'Tata Usaha', type: 'IN', machine: 'FINGER-LOBBY-01', statusColor: 'amber' },
  { id: 110, time: '08:14:02', code: 'EMP-007', name: 'Nurlaila Zahra, S.Sos', department: 'Pelayanan', type: 'IN', machine: 'FACE-DOOR-01', statusColor: 'emerald' },
  { id: 111, time: '08:12:30', code: 'EMP-004', name: 'Dewi Lestari, S.Psi', department: 'Kepegawaian', type: 'IN', machine: 'FINGER-LOBBY-02', statusColor: 'emerald' },
  { id: 112, time: '08:10:05', code: 'EMP-001', name: 'Budi Santoso, S.Kom', department: 'TIK', type: 'IN', machine: 'FACE-DOOR-02', statusColor: 'emerald' }
];
