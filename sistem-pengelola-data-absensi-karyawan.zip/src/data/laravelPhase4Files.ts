import { CodeFile } from './laravelCodeSnippets';

export const LARAVEL_PHASE4_FILES: CodeFile[] = [
  {
    title: 'Migration: Tabel Kalender Kerja & Hari Libur',
    category: 'Migration',
    path: 'database/migrations/2026_01_01_000005_create_work_calendars_and_holidays_tables.php',
    description: 'Menyediakan tabel holidays, work_schedules, work_calendar_overrides, dan shift_assignments untuk konfigurasi jam kerja fleksibel & denda Rp 0 pada libur nasional.',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Tabel Master Hari Libur Nasional & Cuti Bersama (SKB 3 Menteri)
        Schema::create('holidays', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->date('holiday_date')->unique();
            $table->enum('type', ['national', 'joint_leave', 'local', 'special'])
                  ->default('national')
                  ->comment('national=Libur Nasional, joint_leave=Cuti Bersama, local=Libur Daerah, special=Khusus/Pilkada');
            $table->text('description')->nullable();
            $table->boolean('is_penalty_exempt')->default(true)->comment('Jika true, denda alpha/terlambat otomatis Rp 0');
            $table->boolean('is_active')->default(true);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['holiday_date', 'type']);
        });

        // 2. Tabel Pola Jadwal Jam Kerja Reguler (Hari 1=Senin s/d 7=Minggu)
        Schema::create('work_schedules', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100); // e.g., 'ASN Reguler 5 Hari', 'Shift Satpam'
            $table->string('code', 50)->unique();
            $table->unsignedTinyInteger('day_of_week')->comment('1=Senin, 2=Selasa, ..., 5=Jumat, 6=Sabtu, 7=Minggu');
            $table->boolean('is_workday')->default(true);
            
            // Jam Kerja
            $table->time('in_time')->default('08:15:00');
            $table->time('out_time')->default('16:30:00');
            $table->unsignedSmallInteger('grace_period_minutes')->default(0)->comment('Toleransi menit keterlambatan');
            
            // Jendela Waktu Scan Mesin Absensi
            $table->time('scan_in_start')->default('06:00:00');
            $table->time('scan_in_end')->default('11:00:00');
            $table->time('scan_out_start')->default('15:00:00');
            $table->time('scan_out_end')->default('20:00:00');

            // Istirahat
            $table->time('break_start')->nullable()->default('12:00:00');
            $table->time('break_end')->nullable()->default('13:00:00');

            $table->boolean('is_ramadhan_schedule')->default(false);
            $table->timestamps();

            $table->unique(['code', 'day_of_week', 'is_ramadhan_schedule'], 'unique_schedule_day_variant');
        });

        // 3. Tabel Override Tanggal Spesifik (Jam Kerja Khusus Hari Tertentu / Pilkada / Acara Khusus)
        Schema::create('work_calendar_overrides', function (Blueprint $table) {
            $table->id();
            $table->date('override_date')->unique();
            $table->string('title', 150);
            $table->boolean('is_workday')->default(false);
            $table->time('custom_in_time')->nullable();
            $table->time('custom_out_time')->nullable();
            $table->unsignedSmallInteger('custom_grace_period')->default(0);
            $table->text('reason')->nullable();
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        // 4. Tabel Penugasan Jadwal Pegawai (Assignment per Departemen atau Perorangan)
        Schema::create('employee_schedule_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained('employees')->cascadeOnDelete();
            $table->string('schedule_code', 50);
            $table->date('effective_from');
            $table->date('effective_to')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['employee_id', 'effective_from', 'effective_to']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('employee_schedule_assignments');
        Schema::dropIfExists('work_calendar_overrides');
        Schema::dropIfExists('work_schedules');
        Schema::dropIfExists('holidays');
    }
};`
  },
  {
    title: 'Model: Holiday (Hari Libur & Cuti Bersama)',
    category: 'Model',
    path: 'app/Models/Holiday.php',
    description: 'Model Eloquent untuk hari libur dengan scope pencarian tanggal, filter SKB 3 Menteri, dan method evaluator denda absensi.',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\SoftDeletes;
use Carbon\\Carbon;

class Holiday extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'holidays';

    protected $fillable = [
        'name',
        'holiday_date',
        'type',
        'description',
        'is_penalty_exempt',
        'is_active',
        'created_by',
    ];

    protected $casts = [
        'holiday_date' => 'date:Y-m-d',
        'is_penalty_exempt' => 'boolean',
        'is_active' => 'boolean',
    ];

    /**
     * Scope untuk mencari libur pada rentang tahun tertentu
     */
    public function scopeForYear($query, int $year)
    {
        return $query->whereYear('holiday_date', $year);
    }

    /**
     * Scope libur aktif
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope berdasarkan kategori libur
     */
    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Cek apakah sebuah tanggal merupakan hari libur
     */
    public static function isHoliday(string|Carbon $date): bool
    {
        $dateStr = $date instanceof Carbon ? $date->toDateString() : Carbon::parse($date)->toDateString();
        
        return static::active()
            ->where('holiday_date', $dateStr)
            ->exists();
    }

    /**
     * Ambil record libur pada tanggal tertentu (jika ada)
     */
    public static function getHolidayByDate(string|Carbon $date): ?self
    {
        $dateStr = $date instanceof Carbon ? $date->toDateString() : Carbon::parse($date)->toDateString();

        return static::active()
            ->where('holiday_date', $dateStr)
            ->first();
    }

    /**
     * Relasi ke User pembuat
     */
    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}`
  },
  {
    title: 'Model: WorkSchedule (Pola Jam Kerja Harian)',
    category: 'Model',
    path: 'app/Models/WorkSchedule.php',
    description: 'Model jam kerja kantor: mendukung pemisahan hari Senin-Kamis vs Jumat (17:00), toleransi keterlambatan, dan mode khusus Ramadhan.',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Carbon\\Carbon;

class WorkSchedule extends Model
{
    use HasFactory;

    protected $table = 'work_schedules';

    protected $fillable = [
        'name',
        'code',
        'day_of_week',
        'is_workday',
        'in_time',
        'out_time',
        'grace_period_minutes',
        'scan_in_start',
        'scan_in_end',
        'scan_out_start',
        'scan_out_end',
        'break_start',
        'break_end',
        'is_ramadhan_schedule',
    ];

    protected $casts = [
        'day_of_week' => 'integer',
        'is_workday' => 'boolean',
        'grace_period_minutes' => 'integer',
        'is_ramadhan_schedule' => 'boolean',
    ];

    /**
     * Nama hari dalam Bahasa Indonesia (1=Senin ... 7=Minggu)
     */
    public function getDayNameAttribute(): string
    {
        $days = [
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
            7 => 'Minggu',
        ];

        return $days[$this->day_of_week] ?? 'Tidak Diketahui';
    }

    /**
     * Hitung total jam kerja standar dalam sehari
     */
    public function getExpectedWorkDurationHoursAttribute(): float
    {
        if (!$this->is_workday) {
            return 0.0;
        }

        $in = Carbon::parse($this->in_time);
        $out = Carbon::parse($this->out_time);

        return round($out->diffInMinutes($in) / 60, 2);
    }
}`
  },
  {
    title: 'HolidayCalendarService (Engine Penentu Status Hari Kerja & Denda)',
    category: 'Controller',
    path: 'app/Services/HolidayCalendarService.php',
    description: 'Service sentral yang mengevaluasi apakah suatu tanggal adalah Hari Kerja Reguler, Weekend, Libur Nasional, Cuti Bersama, atau Override, serta jadwal jam masuk/pulang yang berlaku.',
    code: `<?php

namespace App\\Services;

use App\\Models\\Holiday;
use App\\Models\\WorkSchedule;
use App\\Models\\WorkCalendarOverride;
use App\\Models\\Setting;
use Carbon\\Carbon;
use Illuminate\\Support\\Facades\\Cache;

class HolidayCalendarService
{
    /**
     * Evaluasi menyeluruh status suatu tanggal
     */
    public function evaluateDate(string|Carbon $date): array
    {
        $carbon = $date instanceof Carbon ? $date->copy() : Carbon::parse($date);
        $dateStr = $carbon->toDateString();
        $dayOfWeek = $carbon->dayOfWeekIso; // 1 (Mon) to 7 (Sun)

        // 1. Cek Override Spesifik Tanggal (Prioritas Tertinggi)
        $override = WorkCalendarOverride::where('override_date', $dateStr)->first();
        if ($override) {
            return [
                'date' => $dateStr,
                'day_name' => $this->getDayNameId($dayOfWeek),
                'is_workday' => $override->is_workday,
                'status_type' => $override->is_workday ? 'workday_special' : 'holiday_override',
                'title' => $override->title,
                'is_penalty_exempt' => !$override->is_workday,
                'in_time' => $override->custom_in_time ?? '08:15:00',
                'out_time' => $override->custom_out_time ?? '16:30:00',
                'grace_period' => $override->custom_grace_period ?? 0,
                'description' => $override->reason ?? 'Penetapan Khusus Instansi',
            ];
        }

        // 2. Cek Libur Nasional atau Cuti Bersama
        $holiday = Holiday::active()->where('holiday_date', $dateStr)->first();
        if ($holiday) {
            return [
                'date' => $dateStr,
                'day_name' => $this->getDayNameId($dayOfWeek),
                'is_workday' => false,
                'status_type' => $holiday->type === 'joint_leave' ? 'joint_leave' : 'national_holiday',
                'title' => $holiday->name,
                'is_penalty_exempt' => $holiday->is_penalty_exempt,
                'in_time' => null,
                'out_time' => null,
                'grace_period' => 0,
                'description' => $holiday->description ?? ($holiday->type === 'joint_leave' ? 'Cuti Bersama SKB 3 Menteri' : 'Hari Libur Nasional Resmi'),
            ];
        }

        // 3. Cek Akhir Pekan (Sabtu = 6, Minggu = 7)
        if ($dayOfWeek >= 6) {
            return [
                'date' => $dateStr,
                'day_name' => $this->getDayNameId($dayOfWeek),
                'is_workday' => false,
                'status_type' => 'weekend',
                'title' => 'Akhir Pekan (' . ($dayOfWeek === 6 ? 'Sabtu' : 'Minggu') . ')',
                'is_penalty_exempt' => true,
                'in_time' => null,
                'out_time' => null,
                'grace_period' => 0,
                'description' => 'Libur Reguler Akhir Pekan Kantor',
            ];
        }

        // 4. Cek Jadwal Reguler / Ramadhan
        $isRamadhan = $this->isDateInRamadhan($dateStr);
        $schedule = WorkSchedule::where('day_of_week', $dayOfWeek)
            ->where('is_ramadhan_schedule', $isRamadhan)
            ->first();

        // Fallback default jika record schedule belum di-seed
        $defaultIn = $isRamadhan ? '08:00:00' : '08:15:00';
        $defaultOut = $dayOfWeek === 5 
            ? ($isRamadhan ? '15:30:00' : '17:00:00') 
            : ($isRamadhan ? '15:00:00' : '16:30:00');

        return [
            'date' => $dateStr,
            'day_name' => $this->getDayNameId($dayOfWeek),
            'is_workday' => $schedule ? $schedule->is_workday : true,
            'status_type' => $isRamadhan ? 'workday_ramadhan' : 'workday_regular',
            'title' => $isRamadhan ? 'Hari Kerja (Jam Khusus Ramadhan)' : 'Hari Kerja Reguler',
            'is_penalty_exempt' => false,
            'in_time' => $schedule ? $schedule->in_time : $defaultIn,
            'out_time' => $schedule ? $schedule->out_time : $defaultOut,
            'grace_period' => $schedule ? $schedule->grace_period_minutes : 0,
            'description' => $dayOfWeek === 5 
                ? 'Jumat: Pulang pukul 17:00 WIB (Ibadah Sholat Jumat)' 
                : 'Senin - Kamis: Pulang pukul 16:30 WIB',
        ];
    }

    /**
     * Hitung ringkasan hari kerja efektif dalam 1 bulan
     */
    public function getMonthlyCalendarSummary(int $year, int $month): array
    {
        $start = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $end = $start->copy()->endOfMonth();

        $totalDays = $end->day;
        $workdaysCount = 0;
        $holidaysCount = 0;
        $weekendsCount = 0;
        $daysList = [];

        for ($d = $start->copy(); $d->lte($end); $d->addDay()) {
            $eval = $this->evaluateDate($d);
            $daysList[] = $eval;

            if ($eval['is_workday']) {
                $workdaysCount++;
            } elseif ($eval['status_type'] === 'weekend') {
                $weekendsCount++;
            } else {
                $holidaysCount++;
            }
        }

        return [
            'year' => $year,
            'month' => $month,
            'month_name' => $start->locale('id')->isoFormat('MMMM YYYY'),
            'total_calendar_days' => $totalDays,
            'effective_workdays' => $workdaysCount,
            'national_holidays_and_leave' => $holidaysCount,
            'weekend_days' => $weekendsCount,
            'days' => $daysList,
        ];
    }

    private function isDateInRamadhan(string $date): bool
    {
        // Dapat dibaca dari settings tabel 'ramadhan_2026_start' & 'ramadhan_2026_end'
        $start = Setting::get('ramadhan_start', '2026-02-18');
        $end = Setting::get('ramadhan_end', '2026-03-20');

        return $date >= $start && $date <= $end;
    }

    private function getDayNameId(int $isoDay): string
    {
        $names = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];
        return $names[$isoDay] ?? '';
    }
}`
  },
  {
    title: 'WorkCalendarController (Manajemen Kalender & Hari Libur)',
    category: 'Controller',
    path: 'app/Http/Controllers/WorkCalendarController.php',
    description: 'Controller pengelola REST API kalender kerja, sinkronisasi SKB 3 Menteri resmi, simulasi tanggal absensi, serta penyesuaian jam kerja instansi.',
    code: `<?php

namespace App\\Http\\Controllers;

use App\\Models\\Holiday;
use App\\Models\\WorkSchedule;
use App\\Models\\WorkCalendarOverride;
use App\\Models\\AuditLog;
use App\\Services\\HolidayCalendarService;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\DB;
use Carbon\\Carbon;

class WorkCalendarController extends Controller
{
    protected HolidayCalendarService $calendarService;

    public function __construct(HolidayCalendarService $calendarService)
    {
        $this->calendarService = $calendarService;
    }

    /**
     * Tampilkan Halaman Kalender Kerja & Daftar Hari Libur
     */
    public function index(Request $request)
    {
        $year = (int) $request->input('year', date('Y'));
        $month = (int) $request->input('month', date('n'));

        $holidays = Holiday::forYear($year)
            ->orderBy('holiday_date', 'asc')
            ->get();

        $monthlySummary = $this->calendarService->getMonthlyCalendarSummary($year, $month);
        $schedules = WorkSchedule::orderBy('day_of_week')->get();

        if ($request->wantsJson()) {
            return response()->json([
                'status' => 'success',
                'summary' => $monthlySummary,
                'holidays' => $holidays,
                'schedules' => $schedules,
            ]);
        }

        return view('calendar.index', compact('year', 'month', 'holidays', 'monthlySummary', 'schedules'));
    }

    /**
     * Tambah Hari Libur Baru / Penetapan Libur Khusus
     */
    public function storeHoliday(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'holiday_date' => ['required', 'date', 'unique:holidays,holiday_date'],
            'type' => ['required', 'in:national,joint_leave,local,special'],
            'description' => ['nullable', 'string'],
            'is_penalty_exempt' => ['boolean'],
        ]);

        $holiday = DB::transaction(function () use ($validated, $request) {
            $record = Holiday::create([
                ...$validated,
                'is_penalty_exempt' => $request->boolean('is_penalty_exempt', true),
                'created_by' => auth()->id(),
            ]);

            AuditLog::create([
                'user_id' => auth()->id(),
                'action' => 'CREATE_HOLIDAY',
                'module' => 'CALENDAR',
                'record_id' => (string) $record->id,
                'new_values' => $record->toArray(),
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            return $record;
        });

        return redirect()->back()->with('success', "Hari libur '{$holiday->name}' ({$holiday->holiday_date->format('d/m/Y')}) berhasil ditambahkan.");
    }

    /**
     * Hapus Hari Libur
     */
    public function destroyHoliday(Holiday $holiday, Request $request)
    {
        DB::transaction(function () use ($holiday, $request) {
            AuditLog::create([
                'user_id' => auth()->id(),
                'action' => 'DELETE_HOLIDAY',
                'module' => 'CALENDAR',
                'record_id' => (string) $holiday->id,
                'old_values' => $holiday->toArray(),
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            $holiday->delete();
        });

        return redirect()->back()->with('success', "Hari libur '{$holiday->name}' berhasil dihapus.");
    }

    /**
     * Sinkronisasi Otomatis SKB 3 Menteri Tahun 2026
     */
    public function syncNationalHolidays(Request $request)
    {
        $year = (int) $request->input('year', 2026);

        // Panggil seeder / service sinkronisasi
        \\Artisan::call('attendance:sync-holidays', ['year' => $year]);

        return redirect()->back()->with('success', "Seluruh Hari Libur Nasional & Cuti Bersama SKB 3 Menteri Tahun {$year} berhasil disinkronkan.");
    }

    /**
     * Simulator / Evaluator Status Suatu Tanggal
     */
    public function inspectDate(Request $request)
    {
        $request->validate(['date' => ['required', 'date']]);
        $date = $request->input('date');

        $result = $this->calendarService->evaluateDate($date);

        return response()->json([
            'status' => 'success',
            'data' => $result,
        ]);
    }
}`
  },
  {
    title: 'Seeder: NationalHoliday2026Seeder (SKB 3 Menteri Resmi)',
    category: 'Seeder',
    path: 'database/seeders/NationalHoliday2026Seeder.php',
    description: 'Seeder 25 Hari Libur Resmi tahun 2026 (17 Libur Nasional + 8 Cuti Bersama) sesuai Surat Keputusan Bersama MenPAN-RB, Menag, dan Menaker.',
    code: `<?php

namespace Database\\Seeders;

use App\\Models\\Holiday;
use Illuminate\\Database\\Seeder;

class NationalHoliday2026Seeder extends Seeder
{
    public function run(): void
    {
        $holidays = [
            // 17 Hari Libur Nasional 2026
            ['date' => '2026-01-01', 'name' => 'Tahun Baru 2026 Masehi', 'type' => 'national'],
            ['date' => '2026-01-16', 'name' => 'Isra Mikraj Nabi Muhammad SAW', 'type' => 'national'],
            ['date' => '2026-02-17', 'name' => 'Tahun Baru Imlek 2577 Kongzili', 'type' => 'national'],
            ['date' => '2026-03-19', 'name' => 'Hari Suci Nyepi (Tahun Baru Saka 1948)', 'type' => 'national'],
            ['date' => '2026-03-21', 'name' => 'Hari Raya Idulfitri 1447 Hijriah (Hari 1)', 'type' => 'national'],
            ['date' => '2026-03-22', 'name' => 'Hari Raya Idulfitri 1447 Hijriah (Hari 2)', 'type' => 'national'],
            ['date' => '2026-04-03', 'name' => 'Wafat Yesus Kristus (Jumat Agung)', 'type' => 'national'],
            ['date' => '2026-04-05', 'name' => 'Kebangkitan Yesus Kristus (Paskah)', 'type' => 'national'],
            ['date' => '2026-05-01', 'name' => 'Hari Buruh Internasional', 'type' => 'national'],
            ['date' => '2026-05-14', 'name' => 'Kenaikan Yesus Kristus', 'type' => 'national'],
            ['date' => '2026-05-27', 'name' => 'Hari Raya Iduladha 1447 Hijriah', 'type' => 'national'],
            ['date' => '2026-05-31', 'name' => 'Hari Raya Waisak 2570 BE', 'type' => 'national'],
            ['date' => '2026-06-01', 'name' => 'Hari Lahir Pancasila', 'type' => 'national'],
            ['date' => '2026-06-16', 'name' => 'Tahun Baru Islam 1448 Hijriah (1 Muharam)', 'type' => 'national'],
            ['date' => '2026-08-17', 'name' => 'Proklamasi Kemerdekaan Republik Indonesia ke-81', 'type' => 'national'],
            ['date' => '2026-08-25', 'name' => 'Maulid Nabi Muhammad SAW', 'type' => 'national'],
            ['date' => '2026-12-25', 'name' => 'Kelahiran Yesus Kristus (Hari Natal)', 'type' => 'national'],

            // 8 Hari Cuti Bersama 2026
            ['date' => '2026-02-16', 'name' => 'Cuti Bersama Tahun Baru Imlek 2577 Kongzili', 'type' => 'joint_leave'],
            ['date' => '2026-03-18', 'name' => 'Cuti Bersama Hari Suci Nyepi', 'type' => 'joint_leave'],
            ['date' => '2026-03-20', 'name' => 'Cuti Bersama Hari Raya Idulfitri 1447 Hijriah', 'type' => 'joint_leave'],
            ['date' => '2026-03-23', 'name' => 'Cuti Bersama Hari Raya Idulfitri 1447 Hijriah', 'type' => 'joint_leave'],
            ['date' => '2026-03-24', 'name' => 'Cuti Bersama Hari Raya Idulfitri 1447 Hijriah', 'type' => 'joint_leave'],
            ['date' => '2026-05-15', 'name' => 'Cuti Bersama Kenaikan Yesus Kristus', 'type' => 'joint_leave'],
            ['date' => '2026-05-28', 'name' => 'Cuti Bersama Hari Raya Iduladha 1447 Hijriah', 'type' => 'joint_leave'],
            ['date' => '2026-12-24', 'name' => 'Cuti Bersama Kelahiran Yesus Kristus (Hari Natal)', 'type' => 'joint_leave'],
        ];

        foreach ($holidays as $item) {
            Holiday::updateOrCreate(
                ['holiday_date' => $item['date']],
                [
                    'name' => $item['name'],
                    'type' => $item['type'],
                    'description' => 'Surat Keputusan Bersama (SKB) MenPAN-RB, Menag, Menaker Tahun 2026',
                    'is_penalty_exempt' => true,
                    'is_active' => true,
                ]
            );
        }
    }
}`
  },
  {
    title: 'Artisan Command: SyncNationalHolidaysCommand',
    category: 'Artisan & CLI',
    path: 'app/Console/Commands/SyncNationalHolidaysCommand.php',
    description: 'CLI tool untuk memperbarui daftar hari libur nasional dan cuti bersama secara otomatis via scheduler atau CI/CD pipeline.',
    code: `<?php

namespace App\\Console\\Commands;

use Illuminate\\Console\\Command;
use Database\\Seeders\\NationalHoliday2026Seeder;

class SyncNationalHolidaysCommand extends Command
{
    protected $signature = 'attendance:sync-holidays {year=2026 : Tahun kalender yang akan disinkronkan}';
    protected $description = 'Sinkronisasi daftar Hari Libur Nasional & Cuti Bersama SKB 3 Menteri';

    public function handle(): int
    {
        $year = (int) $this->argument('year');
        $this->info("Menjalankan sinkronisasi hari libur SKB 3 Menteri untuk tahun {$year}...");

        if ($year === 2026) {
            $seeder = new NationalHoliday2026Seeder();
            $seeder->run();
            $this->info("Berhasil! 25 hari libur nasional & cuti bersama tahun 2026 telah diperbarui ke database.");
            return Command::SUCCESS;
        }

        $this->warn("Data kalender untuk tahun {$year} belum tersedia di seeder lokal. Silakan gunakan API eksternal.");
        return Command::FAILURE;
    }
}`
  }
];
