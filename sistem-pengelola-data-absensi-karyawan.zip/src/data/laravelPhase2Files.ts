import { CodeFile } from './laravelCodeSnippets';

export const LARAVEL_PHASE2_FILES: CodeFile[] = [
  {
    title: 'EmployeeController (CRUD, Import, Export, Toggle)',
    category: 'Controller',
    path: 'app/Http/Controllers/EmployeeController.php',
    description: 'Controller lengkap untuk master pegawai: index dengan filter & paginasi, store, update, soft delete, toggle is_active, import excel, dan audit trail.',
    code: `<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\AuditLog;
use App\Http\Requests\StoreEmployeeRequest;
use App\Http\Requests\UpdateEmployeeRequest;
use App\Imports\EmployeesImport;
use App\Exports\EmployeesExport;
use Illuminate\Http\Request;
use Maatwebsite\\Excel\\Facades\\Excel;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $department = $request->input('department');
        $status = $request->input('status');

        $query = Employee::query();

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('employee_code', 'like', "%{$search}%")
                  ->orWhere('nip', 'like', "%{$search}%")
                  ->orWhere('position', 'like', "%{$search}%");
            });
        }

        if ($department) {
            $query->where('department', $department);
        }

        if ($status !== null && $status !== '') {
            $query->where('is_active', (bool)$status);
        }

        $employees = $query->orderBy('department')
            ->orderBy('name')
            ->paginate(15)
            ->withQueryString();

        $stats = [
            'total' => Employee::count(),
            'active' => Employee::where('is_active', true)->count(),
            'inactive' => Employee::where('is_active', false)->count(),
            'departments' => Employee::distinct('department')->count('department'),
        ];

        $departmentList = Employee::distinct()->pluck('department')->filter()->values();

        return view('employees.index', compact('employees', 'stats', 'departmentList', 'search', 'department', 'status'));
    }

    public function create()
    {
        $departments = ['Sekretariat', 'Bagian Keuangan & Aset', 'Bagian Kepegawaian & SDM', 'Teknologi Informasi & Sistem', 'Perencanaan & Evaluasi', 'Hukum & Humas', 'Operasional Lapangan'];
        $statuses = ['PNS', 'PPPK', 'Tetap', 'Kontrak', 'Magang'];
        return view('employees.create', compact('departments', 'statuses'));
    }

    public function store(StoreEmployeeRequest $request)
    {
        $validated = $request->validated();
        $validated['is_active'] = $request->boolean('is_active', true);

        $employee = Employee::create($validated);

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'CREATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'new_values' => $employee->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Pegawai '{$employee->name}' ({$employee->employee_code}) berhasil ditambahkan.");
    }

    public function show(Employee $employee)
    {
        $employee->load(['attendanceDaily' => fn($q) => $q->latest('attendance_date')->limit(15)]);

        $attendanceStats = [
            'total_recorded' => $employee->attendanceDaily()->count(),
            'on_time' => $employee->attendanceDaily()->where('attendance_status', 'HADIR TEPAT WAKTU')->count(),
            'late' => $employee->attendanceDaily()->where('late_minutes', '>', 0)->count(),
            'missing_in_out' => $employee->attendanceDaily()->where(fn($q) => $q->whereNull('first_in')->orWhereNull('last_out'))->count(),
            'total_penalties' => $employee->attendanceDaily()->sum('total_penalty'),
        ];

        return view('employees.show', compact('employee', 'attendanceStats'));
    }

    public function edit(Employee $employee)
    {
        $departments = ['Sekretariat', 'Bagian Keuangan & Aset', 'Bagian Kepegawaian & SDM', 'Teknologi Informasi & Sistem', 'Perencanaan & Evaluasi', 'Hukum & Humas', 'Operasional Lapangan'];
        $statuses = ['PNS', 'PPPK', 'Tetap', 'Kontrak', 'Magang'];
        return view('employees.edit', compact('employee', 'departments', 'statuses'));
    }

    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {
        $oldValues = $employee->toArray();
        $validated = $request->validated();
        $validated['is_active'] = $request->boolean('is_active');

        $employee->update($validated);

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'UPDATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => $oldValues,
            'new_values' => $employee->toArray(),
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Data pegawai '{$employee->name}' berhasil diperbarui.");
    }

    public function destroy(Request $request, Employee $employee)
    {
        $oldValues = $employee->toArray();
        $name = $employee->name;
        $employee->delete(); // Soft delete

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => 'DELETE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => $oldValues,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return redirect()->route('employees.index')
            ->with('success', "Pegawai '{$name}' berhasil dinonaktifkan / dihapus (Soft Delete).");
    }

    public function toggleStatus(Request $request, Employee $employee)
    {
        $oldStatus = $employee->is_active;
        $employee->is_active = !$oldStatus;
        $employee->save();

        AuditLog::create([
            'user_id' => auth()->id(),
            'action' => $employee->is_active ? 'ACTIVATE_EMPLOYEE' : 'DEACTIVATE_EMPLOYEE',
            'module' => 'EMPLOYEES',
            'record_id' => (string)$employee->id,
            'old_values' => ['is_active' => $oldStatus],
            'new_values' => ['is_active' => $employee->is_active],
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        $statusText = $employee->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return redirect()->back()->with('success', "Status pegawai '{$employee->name}' berhasil {$statusText}.");
    }

    /**
     * Hapus Massal (Bulk Soft Delete) dengan Transaksi Database & Audit Trail
     */
    public function bulkDestroy(Request $request)
    {
        $request->validate([
            'ids' => ['required', 'array', 'min:1'],
            'ids.*' => ['integer', 'exists:employees,id'],
        ]);

        $ids = $request->input('ids');

        DB::transaction(function () use ($ids, $request) {
            $employees = Employee::whereIn('id', $ids)->get();

            foreach ($employees as $emp) {
                AuditLog::create([
                    'user_id' => auth()->id(),
                    'action' => 'BULK_DELETE_EMPLOYEE',
                    'module' => 'EMPLOYEES',
                    'record_id' => (string)$emp->id,
                    'old_values' => $emp->toArray(),
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                ]);
            }

            Employee::whereIn('id', $ids)->delete(); // Soft delete all selected
        });

        return redirect()->route('employees.index')
            ->with('success', count($ids) . " pegawai terpilih berhasil dihapus (Soft Delete tercatat di Audit Log).");
    }

    public function import(Request $request)
    {
        $request->validate(['file' => ['required', 'file', 'mimes:xlsx,xls,csv', 'max:10240']]);
        $import = new EmployeesImport();
        Excel::import($import, $request->file('file'));

        return redirect()->route('employees.index')
            ->with('success', "Import selesai: {$import->getImportedCount()} ditambah, {$import->getUpdatedCount()} diperbarui.");
    }
}`
  },
  {
    title: 'StoreEmployeeRequest (Form Validation)',
    category: 'Controller',
    path: 'app/Http/Requests/StoreEmployeeRequest.php',
    description: 'Validasi ketat penambahan pegawai baru: keunikan employee_code & NIP dengan pengecualian soft delete, enumerasi status kepegawaian, dan sanitasi teks.',
    code: `<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->isOperator();
    }

    public function rules(): array
    {
        return [
            'employee_code' => [
                'required',
                'string',
                'max:50',
                Rule::unique('employees', 'employee_code')->withoutTrashed(),
            ],
            'nip' => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('employees', 'nip')->withoutTrashed(),
            ],
            'name' => ['required', 'string', 'max:255'],
            'department' => ['required', 'string', 'max:100'],
            'position' => ['required', 'string', 'max:100'],
            'employment_status' => ['required', 'string', 'max:100'], // Fleksibel: PNS, PPPK, PPNPN, Honorer, Tetap, Kontrak, Tenaga Ahli, Outsourcing, atau kustom
            'is_active' => ['boolean'],
        ];
    }
}`
  },
  {
    title: 'UpdateEmployeeRequest (Form Validation)',
    category: 'Controller',
    path: 'app/Http/Requests/UpdateEmployeeRequest.php',
    description: 'Validasi edit pegawai fleksibel: ignore ID pegawai saat ini pada rule unique employee_code dan NIP, dukungan unit/jabatan/status kepegawaian terbuka.',
    code: `<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->isOperator();
    }

    public function rules(): array
    {
        $employeeId = $this->route('employee')?->id ?? $this->route('employee');

        return [
            'employee_code' => [
                'required',
                'string',
                'max:50',
                Rule::unique('employees', 'employee_code')->ignore($employeeId)->withoutTrashed(),
            ],
            'nip' => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('employees', 'nip')->ignore($employeeId)->withoutTrashed(),
            ],
            'name' => ['required', 'string', 'max:255'],
            'department' => ['required', 'string', 'max:100'],
            'position' => ['required', 'string', 'max:100'],
            'employment_status' => ['required', 'string', 'max:100'], // Fleksibel: mendukung segala jenis status kepegawaian
            'is_active' => ['boolean'],
        ];
    }
}`
  },
  {
    title: 'EmployeesImport (Chunking & Batch Upsert)',
    category: 'Model',
    path: 'app/Imports/EmployeesImport.php',
    description: 'Class import Excel/CSV dengan chunk reading (500 baris), batch insert (250 baris), pemulihan soft-delete otomatis, dan deteksi kode pegawai ganda.',
    code: `<?php

namespace App\Imports;

use App\Models\Employee;
use Maatwebsite\\Excel\\Concerns\\ToModel;
use Maatwebsite\\Excel\\Concerns\\WithHeadingRow;
use Maatwebsite\\Excel\\Concerns\\WithValidation;
use Maatwebsite\\Excel\\Concerns\\WithBatchInserts;
use Maatwebsite\\Excel\\Concerns\\WithChunkReading;
use Maatwebsite\\Excel\\Concerns\\SkipsOnFailure;
use Maatwebsite\\Excel\\Concerns\\SkipsFailures;

class EmployeesImport implements ToModel, WithHeadingRow, WithValidation, WithBatchInserts, WithChunkReading, SkipsOnFailure
{
    use SkipsFailures;

    private int $importedCount = 0;
    private int $updatedCount = 0;

    public function model(array $row)
    {
        $code = trim((string)($row['kode_pegawai'] ?? $row['kode'] ?? ''));
        if (empty($code)) return null;

        $employee = Employee::withTrashed()->where('employee_code', $code)->first();

        if ($employee) {
            if ($employee->trashed()) $employee->restore();
            $employee->update([
                'name' => trim((string)($row['nama_lengkap'] ?? $row['name'] ?? '')),
                'department' => trim((string)($row['departemen'] ?? 'Umum')),
                'position' => trim((string)($row['jabatan'] ?? 'Staff')),
                'employment_status' => trim((string)($row['status_kepegawaian'] ?? 'Tetap')),
            ]);
            $this->updatedCount++;
            return null;
        }

        $this->importedCount++;
        return new Employee([
            'employee_code' => $code,
            'nip' => !empty($row['nip']) ? trim((string)$row['nip']) : null,
            'name' => trim((string)($row['nama_lengkap'] ?? $row['name'] ?? '')),
            'department' => trim((string)($row['departemen'] ?? 'Umum')),
            'position' => trim((string)($row['jabatan'] ?? 'Staff')),
            'employment_status' => trim((string)($row['status_kepegawaian'] ?? 'Tetap')),
            'is_active' => true,
        ]);
    }

    public function batchSize(): int { return 250; }
    public function chunkSize(): int { return 500; }
}`
  },
  {
    title: 'EmployeesExport (Styled Excel Export)',
    category: 'Model',
    path: 'app/Exports/EmployeesExport.php',
    description: 'Export data master pegawai ke Excel dengan auto-sizing lebar kolom, heading styling Slate-800, pemetaan data terformat, dan filter terintegrasi.',
    code: `<?php

namespace App\Exports;

use App\Models\Employee;
use Maatwebsite\\Excel\\Concerns\\FromQuery;
use Maatwebsite\\Excel\\Concerns\\WithHeadings;
use Maatwebsite\\Excel\\Concerns\\WithMapping;
use Maatwebsite\\Excel\\Concerns\\ShouldAutoSize;
use Maatwebsite\\Excel\\Concerns\\WithStyles;
use PhpOffice\\PhpSpreadsheet\\Worksheet\\Worksheet;

class EmployeesExport implements FromQuery, WithHeadings, WithMapping, ShouldAutoSize, WithStyles
{
    public function headings(): array
    {
        return ['ID', 'Kode Pegawai', 'NIP', 'Nama Lengkap', 'Unit / Departemen', 'Jabatan', 'Status Kepegawaian', 'Status Aktif', 'Tanggal Dibuat'];
    }

    public function map($employee): array
    {
        return [
            $employee->id,
            $employee->employee_code,
            $employee->nip ?? '-',
            $employee->name,
            $employee->department,
            $employee->position,
            $employee->employment_status,
            $employee->is_active ? 'Aktif' : 'Nonaktif',
            $employee->created_at?->format('d/m/Y H:i'),
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF']],
                'fill' => ['fillType' => 'solid', 'startColor' => ['argb' => 'FF1E293B']]
            ],
        ];
    }
}`
  },
  {
    title: 'View: employees/index.blade.php',
    category: 'View',
    path: 'resources/views/employees/index.blade.php',
    description: 'Halaman master pegawai dengan 4 metrik agregat, pencarian multi-kolom, dropdown filter departemen & status aktif, badge status, dan pagination.',
    code: `@extends('layouts.app')

@section('title', 'Data Pegawai & Karyawan')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
                <i data-lucide="users" class="w-7 h-7 text-emerald-600"></i>
                Master Data Pegawai
            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Kelola data pegawai, sinkronisasi NIP, status kepegawaian, dan integrasi kode mesin absensi.
            </p>
        </div>
        <div class="flex items-center gap-2">
            <a href="{{ route('employees.export', request()->query()) }}" class="btn-outline">Export Excel</a>
            @if(auth()->user()->isOperator())
                <a href="{{ route('employees.import.view') }}" class="btn-secondary">Import Excel/CSV</a>
                <a href="{{ route('employees.create') }}" class="btn-primary">Tambah Pegawai</a>
            @endif
        </div>
    </div>

    <!-- 4 Stats Cards & Table List -->
    {{-- Lengkap di resources/views/employees/index.blade.php --}}
</div>
@endsection`
  },
  {
    title: 'View: employees/show.blade.php',
    category: 'View',
    path: 'resources/views/employees/show.blade.php',
    description: 'Halaman profil detail pegawai, kartu ringkasan absensi (Hadir, Terlambat, Missing In/Out, Total Denda), dan tabel 15 riwayat absensi harian terakhir.',
    code: `@extends('layouts.app')

@section('title', 'Detail Pegawai: ' . $employee->name)

@section('content')
<div class="space-y-6">
    <!-- Header & Action -->
    <!-- 5 KPI Absensi Pegawai -->
    <!-- Informasi Kepegawaian & Riwayat 15 Hari Terakhir -->
</div>
@endsection`
  },
  {
    title: 'Seeder: EmployeeSeeder.php',
    category: 'Seeder',
    path: 'database/seeders/EmployeeSeeder.php',
    description: 'Seeder 10 pegawai realistis (PNS, PPPK, Tetap, Kontrak) di berbagai departemen untuk pengujian fungsional absensi dan denda keterlambatan.',
    code: `<?php

namespace Database\Seeders;

use App\Models\Employee;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    public function run(): void
    {
        $employees = [
            ['employee_code' => 'PEG001', 'nip' => '198205122008011005', 'name' => 'Ahmad Fauzi, S.Kom., M.T.I.', 'department' => 'Teknologi Informasi & Sistem', 'position' => 'Kepala Bagian IT & Infrastruktur', 'employment_status' => 'PNS', 'is_active' => true],
            ['employee_code' => 'PEG002', 'nip' => '198711032011012008', 'name' => 'Siti Nurhaliza, S.E., M.Ak.', 'department' => 'Bagian Keuangan & Aset', 'position' => 'Bendahara Pengeluaran Pembantu', 'employment_status' => 'PNS', 'is_active' => true],
            ['employee_code' => 'PEG003', 'nip' => '199008242015031002', 'name' => 'Bambang Trianto, S.Sos.', 'department' => 'Bagian Kepegawaian & SDM', 'position' => 'Analis SDM Aparatur Ahli Muda', 'employment_status' => 'PNS', 'is_active' => true],
        ];

        foreach ($employees as $data) {
            Employee::updateOrCreate(['employee_code' => $data['employee_code']], $data);
        }
    }
}`
  }
];
