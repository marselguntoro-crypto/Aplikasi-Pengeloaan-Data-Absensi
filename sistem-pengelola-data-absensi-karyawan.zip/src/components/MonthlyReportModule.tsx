import React, { useState, useMemo, useEffect } from 'react';
import * as XLSX from 'xlsx';
import {
  FileSpreadsheet,
  Receipt,
  Download,
  Printer,
  Search,
  Filter,
  Calendar,
  Building2,
  CheckCircle2,
  AlertTriangle,
  FileText,
  UserCheck,
  QrCode,
  DollarSign,
  TrendingDown,
  Clock,
  ChevronRight,
  X,
  ExternalLink,
  ShieldCheck,
  Users
} from 'lucide-react';
import { getStoredEmployees } from '../data/participantStore';
import { getActiveMachineAttendanceData } from '../data/machineAttendanceStore';

interface MonthlyEmployeeRecord {
  id: number;
  code: string;
  nip: string;
  name: string;
  department: string;
  position: string;
  employeeType: 'PNS' | 'PPPK' | 'HONORER';
  totalWorkdays: number;
  presentDays: number;
  lateDays: number;
  earlyDays: number;
  missingScanDays: number;
  alphaDays: number;
  accumulatedLateMinutes: number;
  accumulatedEarlyMinutes: number;
  totalPenalty: number;
  violations: {
    date: string;
    dayName: string;
    firstIn: string | null;
    lastOut: string | null;
    violationType: string;
    durationMinutes: number;
    amount: number;
  }[];
}

// Dummy monthly records removed as requested by user
const MONTHLY_SAMPLE_DATA: MonthlyEmployeeRecord[] = [];

function angkaTerbilang(nilai: number): string {
  if (nilai === 0) return 'Nol Rupiah';
  const satuan = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];
  
  function bagi(n: number): string {
    if (n < 12) return satuan[n];
    if (n < 20) return bagi(n - 10) + ' Belas';
    if (n < 100) return bagi(Math.floor(n / 10)) + ' Puluh ' + bagi(n % 10);
    if (n < 200) return 'Seratus ' + bagi(n - 100);
    if (n < 1000) return bagi(Math.floor(n / 100)) + ' Ratus ' + bagi(n % 100);
    if (n < 2000) return 'Seribu ' + bagi(n - 1000);
    if (n < 1000000) return bagi(Math.floor(n / 1000)) + ' Ribu ' + bagi(n % 1000);
    if (n < 1000000000) return bagi(Math.floor(n / 1000000)) + ' Juta ' + bagi(n % 1000000);
    return n.toString();
  }

  return (bagi(nilai).trim() + ' Rupiah').replace(/\s+/g, ' ');
}

export const MonthlyReportModule: React.FC = () => {
  // Period State
  const [selectedMonth, setSelectedMonth] = useState<number>(8); // August
  const [selectedYear, setSelectedYear] = useState<number>(2026);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  const [employeeTypeFilter, setEmployeeTypeFilter] = useState('ALL');

  // Slip Modal Target
  const [activeSlipEmployee, setActiveSlipEmployee] = useState<MonthlyEmployeeRecord | null>(null);

  // Dynamic participant and machine attendance store
  const [storedEmployees, setStoredEmployees] = useState(() => getStoredEmployees());
  const [machineData, setMachineData] = useState(() => getActiveMachineAttendanceData());

  useEffect(() => {
    const handleUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setStoredEmployees(e.detail);
      }
      setMachineData(getActiveMachineAttendanceData());
    };
    const handleMachineUpdate = () => {
      setMachineData(getActiveMachineAttendanceData());
      setStoredEmployees(getStoredEmployees());
    };
    window.addEventListener('participants_updated', handleUpdated);
    window.addEventListener('attendance_data_updated', handleMachineUpdate);
    return () => {
      window.removeEventListener('participants_updated', handleUpdated);
      window.removeEventListener('attendance_data_updated', handleMachineUpdate);
    };
  }, []);

  const monthlyList = useMemo<MonthlyEmployeeRecord[]>(() => {
    if (machineData && machineData.monthlySummaries && machineData.monthlySummaries.length > 0) {
      return machineData.monthlySummaries.map((m) => ({
        id: m.id,
        code: m.code,
        nip: m.nip || '-',
        name: m.name,
        department: m.department,
        position: m.position,
        employeeType: (m.employeeType as any) || 'PNS',
        totalWorkdays: m.totalWorkdays,
        presentDays: m.presentDays,
        lateDays: m.lateDays,
        earlyDays: m.earlyDays,
        missingScanDays: m.missingScanDays,
        alphaDays: m.alphaDays,
        accumulatedLateMinutes: m.accumulatedLateMinutes,
        accumulatedEarlyMinutes: m.accumulatedEarlyMinutes,
        totalPenalty: m.totalPenalty,
        violations: m.violations
      }));
    }

    if (!storedEmployees || storedEmployees.length === 0) return [];
    return storedEmployees.map((emp) => ({
      id: emp.id,
      code: emp.employee_code,
      nip: emp.nip || '-',
      name: emp.name,
      department: emp.department,
      position: emp.position,
      employeeType: emp.employment_status as any,
      totalWorkdays: 21,
      presentDays: 21,
      lateDays: 0,
      earlyDays: 0,
      missingScanDays: 0,
      alphaDays: 0,
      accumulatedLateMinutes: 0,
      accumulatedEarlyMinutes: 0,
      totalPenalty: 0,
      violations: []
    }));
  }, [machineData, storedEmployees]);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Month Name
  const currentMonthName = useMemo(() => {
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    return months[selectedMonth - 1] || 'Agustus';
  }, [selectedMonth]);

  // Filtered Records
  const filteredRecords = useMemo(() => {
    return monthlyList.filter(item => {
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.nip.includes(searchQuery) ||
        item.code.toLowerCase().includes(searchQuery.toLowerCase());

      const matchDept = departmentFilter === 'ALL' || item.department === departmentFilter;
      const matchType = employeeTypeFilter === 'ALL' || item.employeeType === employeeTypeFilter;

      return matchSearch && matchDept && matchType;
    });
  }, [monthlyList, searchQuery, departmentFilter, employeeTypeFilter]);

  // Aggregate Metrics
  const metrics = useMemo(() => {
    let grandTotalDeductions = 0;
    let totalLateMinutes = 0;
    let cleanEmployeesCount = 0;

    filteredRecords.forEach(emp => {
      grandTotalDeductions += emp.totalPenalty;
      totalLateMinutes += emp.accumulatedLateMinutes;
      if (emp.totalPenalty === 0) cleanEmployeesCount++;
    });

    return {
      totalEmployees: filteredRecords.length,
      grandTotalDeductions,
      totalLateMinutes,
      cleanEmployeesCount,
      complianceRate: filteredRecords.length > 0 ? Math.round((cleanEmployeesCount / filteredRecords.length) * 100) : 100
    };
  }, [filteredRecords]);

  // Departments List
  const departments = useMemo(() => {
    const set = new Set<string>();
    monthlyList.forEach(d => set.add(d.department));
    return Array.from(set);
  }, [monthlyList]);

  // Export Summary to CSV
  const handleExportCSV = () => {
    const headers = [
      'No',
      'Kode',
      'NIP',
      'Nama Pegawai',
      'Unit Kerja',
      'Jabatan',
      'Tipe Pegawai',
      'Hari Kerja',
      'Hadir',
      'Hari Telat',
      'Hari Pulang Cepat',
      'Missing Scan',
      'Alpha',
      'Akumulasi Telat (Menit)',
      'Total Potongan Denda (Rp)'
    ];

    const rows = filteredRecords.map((r, index) => [
      index + 1,
      r.code,
      `'${r.nip}`,
      `"${r.name}"`,
      `"${r.department}"`,
      `"${r.position}"`,
      r.employeeType,
      r.totalWorkdays,
      r.presentDays,
      r.lateDays,
      r.earlyDays,
      r.missingScanDays,
      r.alphaDays,
      r.accumulatedLateMinutes,
      r.totalPenalty
    ]);

    const csvContent = "\uFEFF" + [headers.join(','), ...rows.map(row => row.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Rekap_Kehadiran_Tukin_${selectedYear}_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showNotification(`Rekap bulanan (${filteredRecords.length} pegawai) berhasil diekspor.`);
  };

  // Export All Slips Itemized in Excel (CSV)
  const handleExportAllSlipsExcel = () => {
    const generatedDate = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const lines: string[] = [
      `"PEMERINTAH DAERAH PROVINSI / KOTA"`,
      `"BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA (BKPSDM)"`,
      `"LAPORAN RINCIAN SELURUH SLIP POTONGAN TUNJANGAN KINERJA (TUKIN) ABSENSI"`,
      `"Periode Evaluasi:","${currentMonthName} ${selectedYear}"`,
      `"Tanggal Ekspor:","${generatedDate}"`,
      `""`,
      `"No","NIP","Kode Pegawai","Nama Pegawai","Unit Kerja","Jabatan","Tipe Pegawai","Tanggal Pelanggaran","Hari","Scan Masuk","Scan Pulang","Jenis Pelanggaran","Durasi (Menit)","Nominal Denda (Rp)","Nomor Slip Resmi"`
    ];

    let counter = 1;
    filteredRecords.forEach(emp => {
      const slipNo = `SLIP-TUKIN/${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${emp.code}`;
      if (emp.violations.length === 0) {
        lines.push(
          `"${counter++}","'${emp.nip}","${emp.code}","${emp.name}","${emp.department}","${emp.position}","${emp.employeeType}","-","-","-","-","Tidak ada pelanggaran (Disiplin 100%)","0","0","${slipNo}"`
        );
      } else {
        emp.violations.forEach(v => {
          lines.push(
            `"${counter++}","'${emp.nip}","${emp.code}","${emp.name}","${emp.department}","${emp.position}","${emp.employeeType}","${v.date}","${v.dayName}","${v.firstIn || '-'}","${v.lastOut || '-'}","${v.violationType}","${v.durationMinutes}","${v.amount}","${slipNo}"`
          );
        });
      }
    });

    lines.push(`""`);
    lines.push(`"","","","","","","","","","","","TOTAL AKUMULASI POTONGAN SELURUH PEGAWAI:","","${metrics.grandTotalDeductions}",""`);

    const csvContent = "\uFEFF" + lines.join("\r\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Itemisasi_Semua_Slip_Tukin_${currentMonthName}_${selectedYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showNotification(`Laporan rincian seluruh slip pegawai (${filteredRecords.length} pegawai) berhasil diekspor.`);
  };

  // Download Individual Slip in Excel (.xlsx format with formatting)
  const handleDownloadSlipXLSX = (emp: MonthlyEmployeeRecord) => {
    const slipNo = `SLIP-TUKIN/${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${emp.code}`;
    const generatedDate = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const wb = XLSX.utils.book_new();

    const dataRows: any[][] = [
      ["PEMERINTAH DAERAH PROVINSI / KOTA"],
      ["BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA (BKPSDM)"],
      ["SLIP RESMI RINCIAN POTONGAN TUNJANGAN KINERJA (TUKIN) ABSENSI"],
      [],
      ["Nomor Dokumen:", slipNo],
      ["Tanggal Terbit:", generatedDate],
      ["Periode Evaluasi:", `${currentMonthName} ${selectedYear}`],
      [],
      ["DATA PEGAWAI:"],
      ["Nama Lengkap:", emp.name],
      ["NIP:", emp.nip],
      ["Kode Pegawai:", emp.code],
      ["Jabatan:", emp.position],
      ["Unit Kerja / SKPD:", emp.department],
      ["Status Kepegawaian:", emp.employeeType],
      [],
      ["REKAPITULASI KEHADIRAN BULANAN:"],
      ["Total Hari Kerja Efektif:", `${emp.totalWorkdays} Hari`],
      ["Hari Hadir:", `${emp.presentDays} Hari`],
      ["Frekuensi Terlambat:", `${emp.lateDays} Hari`],
      ["Frekuensi Pulang Cepat:", `${emp.earlyDays} Hari`],
      ["Missing Scan:", `${emp.missingScanDays} Hari`],
      ["Alpha (Tanpa Keterangan):", `${emp.alphaDays} Hari`],
      ["Akumulasi Waktu Terlambat:", `${emp.accumulatedLateMinutes} Menit`],
      [],
      ["RINCIAN PELANGGARAN & POTONGAN DENDA:"],
      ["No", "Tanggal", "Hari", "Scan Masuk", "Scan Pulang", "Jenis Pelanggaran", "Durasi (Menit)", "Nominal Denda (Rp)"]
    ];

    if (emp.violations.length === 0) {
      dataRows.push([1, "-", "-", "-", "-", "Tidak ada pelanggaran kehadiran (Disiplin 100%)", 0, 0]);
    } else {
      emp.violations.forEach((v, idx) => {
        dataRows.push([
          idx + 1,
          v.date,
          v.dayName,
          v.firstIn || "-",
          v.lastOut || "-",
          v.violationType,
          v.durationMinutes,
          v.amount
        ]);
      });
    }

    dataRows.push([]);
    dataRows.push(["", "", "", "", "", "TOTAL POTONGAN DENDA TUKIN:", "", emp.totalPenalty]);
    dataRows.push(["TERBILANG:", angkaTerbilang(emp.totalPenalty)]);
    dataRows.push([]);
    dataRows.push(["PENGESAHAN ELEKTRONIK:"]);
    dataRows.push(["Kode Validasi:", `VERIF-${emp.code}-${selectedYear}${String(selectedMonth).padStart(2, '0')}`]);
    dataRows.push(["Status:", "Dokumen Sah & Tervalidasi Sistem Absensi Elektronik"]);

    const ws = XLSX.utils.aoa_to_sheet(dataRows);
    ws['!cols'] = [
      { wch: 6 },
      { wch: 14 },
      { wch: 10 },
      { wch: 12 },
      { wch: 12 },
      { wch: 38 },
      { wch: 16 },
      { wch: 22 }
    ];

    XLSX.utils.book_append_sheet(wb, ws, "Slip Tukin Pegawai");
    const sanitizedName = emp.name.replace(/[^a-zA-Z0-9]/g, '_');
    XLSX.writeFile(wb, `Slip_Potongan_${emp.code}_${sanitizedName}_${currentMonthName}_${selectedYear}.xlsx`);
    showNotification(`Slip potongan Excel (.xlsx) untuk ${emp.name} berhasil diunduh.`);
  };

  // Export Summary Table as Real Excel (.xlsx)
  const handleExportSummaryXLSX = () => {
    const wb = XLSX.utils.book_new();

    const summaryHeaders = [
      "No", "Kode Pegawai", "NIP", "Nama Pegawai", "Unit Kerja", "Jabatan", "Status Kepegawaian",
      "Total Hari Kerja", "Hadir", "Hari Telat", "Hari Pulang Cepat", "Missing Scan", "Alpha",
      "Akumulasi Telat (Menit)", "Total Potongan Denda (Rp)"
    ];

    const summaryRows = filteredRecords.map((r, i) => [
      i + 1, r.code, r.nip, r.name, r.department, r.position, r.employeeType,
      r.totalWorkdays, r.presentDays, r.lateDays, r.earlyDays, r.missingScanDays, r.alphaDays,
      r.accumulatedLateMinutes, r.totalPenalty
    ]);

    const wsSummary = XLSX.utils.aoa_to_sheet([summaryHeaders, ...summaryRows]);
    wsSummary['!cols'] = [
      { wch: 6 }, { wch: 14 }, { wch: 20 }, { wch: 28 }, { wch: 24 }, { wch: 22 }, { wch: 14 },
      { wch: 12 }, { wch: 8 }, { wch: 10 }, { wch: 14 }, { wch: 12 }, { wch: 8 },
      { wch: 18 }, { wch: 22 }
    ];
    XLSX.utils.book_append_sheet(wb, wsSummary, "Rekap Bulanan");

    // Also add itemized violations sheet
    const violationHeaders = [
      "No", "Kode Pegawai", "NIP", "Nama Pegawai", "Unit Kerja", "Tanggal", "Hari",
      "Scan Masuk", "Scan Pulang", "Jenis Pelanggaran", "Durasi (Menit)", "Nominal Denda (Rp)"
    ];
    const violationRows: any[][] = [];
    let count = 1;
    filteredRecords.forEach(emp => {
      emp.violations.forEach(v => {
        violationRows.push([
          count++, emp.code, emp.nip, emp.name, emp.department, v.date, v.dayName,
          v.firstIn || "-", v.lastOut || "-", v.violationType, v.durationMinutes, v.amount
        ]);
      });
    });

    const wsViolations = XLSX.utils.aoa_to_sheet([violationHeaders, ...violationRows]);
    wsViolations['!cols'] = [
      { wch: 6 }, { wch: 14 }, { wch: 20 }, { wch: 28 }, { wch: 24 }, { wch: 14 }, { wch: 10 },
      { wch: 12 }, { wch: 12 }, { wch: 38 }, { wch: 16 }, { wch: 20 }
    ];
    XLSX.utils.book_append_sheet(wb, wsViolations, "Rincian Pelanggaran");

    XLSX.writeFile(wb, `Laporan_Rekap_Tukin_${currentMonthName}_${selectedYear}.xlsx`);
    showNotification(`Laporan Rekap Bulanan Excel (.xlsx) dengan 2 lembar kerja berhasil diunduh.`);
  };

  // Download Individual Slip in Excel (.csv with UTF-8 BOM)
  const handleDownloadSlipExcel = (emp: MonthlyEmployeeRecord) => {
    const slipNo = `SLIP-TUKIN/${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${emp.code}`;
    const generatedDate = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const lines: string[] = [
      `"PEMERINTAH DAERAH PROVINSI / KOTA"`,
      `"BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA (BKPSDM)"`,
      `"Gedung Graha Praja Lt. 2, Jl. Pahlawan No. 1, Email: bkd@pemda.go.id"`,
      `""`,
      `"SLIP RESMI RINCIAN POTONGAN TUNJANGAN KINERJA (TUKIN) ABSENSI"`,
      `"Nomor Dokumen:","${slipNo}"`,
      `"Tanggal Terbit:","${generatedDate}"`,
      `"Periode Evaluasi:","${currentMonthName} ${selectedYear}"`,
      `""`,
      `"DATA PEGAWAI:"`,
      `"Nama Lengkap:","${emp.name}"`,
      `"NIP:","'${emp.nip}"`,
      `"Kode Pegawai:","${emp.code}"`,
      `"Jabatan:","${emp.position}"`,
      `"Unit Kerja / SKPD:","${emp.department}"`,
      `"Status Kepegawaian:","${emp.employeeType}"`,
      `""`,
      `"REKAPITULASI KEHADIRAN BULANAN:"`,
      `"Total Hari Kerja Efektif:","${emp.totalWorkdays} Hari"`,
      `"Hari Hadir:","${emp.presentDays} Hari"`,
      `"Frekuensi Terlambat:","${emp.lateDays} Hari"`,
      `"Frekuensi Pulang Cepat:","${emp.earlyDays} Hari"`,
      `"Missing Scan (Masuk/Pulang):","${emp.missingScanDays} Hari"`,
      `"Alpha (Tanpa Keterangan):","${emp.alphaDays} Hari"`,
      `"Akumulasi Waktu Terlambat:","${emp.accumulatedLateMinutes} Menit"`,
      `""`,
      `"RINCIAN PELANGGARAN & POTONGAN DENDA:"`,
      `"No","Tanggal","Hari","Scan Masuk","Scan Pulang","Jenis Pelanggaran","Durasi Telat/Pulang Cepat","Nominal Denda (Rp)"`
    ];

    if (emp.violations.length === 0) {
      lines.push(`"1","-","-","-","-","Tidak ada pelanggaran kehadiran (Disiplin 100%)","0 Menit","Rp 0"`);
    } else {
      emp.violations.forEach((v, idx) => {
        lines.push(
          `"${idx + 1}","${v.date}","${v.dayName}","${v.firstIn || '-'}","${v.lastOut || '-'}","${v.violationType}","${v.durationMinutes} Menit","${v.amount}"`
        );
      });
    }

    lines.push(`""`);
    lines.push(`"","","","","","","TOTAL POTONGAN DENDA TUKIN:","Rp ${emp.totalPenalty.toLocaleString('id-ID')}"`);
    lines.push(`"TERBILANG:","${angkaTerbilang(emp.totalPenalty)}"`);
    lines.push(`""`);
    lines.push(`"PENGESAHAN ELEKTRONIK:"`);
    lines.push(`"Kode Verifikasi Keabsahan:","VERIF-${emp.code}-${selectedYear}${String(selectedMonth).padStart(2, '0')}"`);
    lines.push(`"Pejabat Pembuat Komitmen:","Dra. Hj. Wahyuni, M.Si (NIP. 197802142003122001)"`);
    lines.push(`"Status Dokumen:","DOKUMEN SAH & TERVALIDASI SISTEM ABSENSI ELEKTRONIK"`);

    const csvContent = "\uFEFF" + lines.join("\r\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    const sanitizedName = emp.name.replace(/[^a-zA-Z0-9]/g, '_');
    link.setAttribute('download', `Slip_Potongan_${emp.code}_${sanitizedName}_${currentMonthName}_${selectedYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showNotification(`Slip format Excel (.CSV) untuk ${emp.name} berhasil diunduh.`);
  };

  // Print or Save as PDF for Individual Employee
  const handlePrintOrDownloadPDF = (emp: MonthlyEmployeeRecord) => {
    setActiveSlipEmployee(emp);
    const oldTitle = document.title;
    const sanitizedName = emp.name.replace(/[^a-zA-Z0-9]/g, '_');
    document.title = `Slip_Potongan_Tukin_${emp.code}_${sanitizedName}_${currentMonthName}_${selectedYear}`;

    // Show prompt and trigger print
    showNotification(`Membuka jendela cetak / simpan PDF untuk ${emp.name}. Pilih "Simpan sebagai PDF".`);

    setTimeout(() => {
      window.print();
      setTimeout(() => {
        document.title = oldTitle;
      }, 1000);
    }, 350);
  };

  // Download Standalone Portable HTML/PDF Document
  const handleDownloadSlipDocument = (emp: MonthlyEmployeeRecord) => {
    const slipNo = `SLIP-TUKIN/${selectedYear}/${String(selectedMonth).padStart(2, '0')}/${emp.code}`;
    const generatedDate = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const violationRows = emp.violations.length === 0
      ? `<tr><td colspan="5" style="text-align:center; padding:18px; color:#059669; font-weight:bold;">Tidak ada pelanggaran kehadiran. Kehadiran 100% disiplin (Potongan Rp 0).</td></tr>`
      : emp.violations.map((v, i) => `
          <tr>
            <td style="padding:8px 10px; border:1px solid #cbd5e1;">${v.date} (${v.dayName})</td>
            <td style="padding:8px 10px; border:1px solid #cbd5e1; text-align:center; font-family:monospace;">${v.firstIn || '-'}</td>
            <td style="padding:8px 10px; border:1px solid #cbd5e1; text-align:center; font-family:monospace;">${v.lastOut || '-'}</td>
            <td style="padding:8px 10px; border:1px solid #cbd5e1;">${v.violationType}</td>
            <td style="padding:8px 10px; border:1px solid #cbd5e1; text-align:right; font-weight:bold; color:#dc2626;">Rp ${v.amount.toLocaleString('id-ID')}</td>
          </tr>
        `).join('');

    const htmlContent = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Slip Potongan Tukin - ${emp.code} - ${emp.name}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; margin: 30px; color: #1e293b; background:#fff; }
    .slip-container { max-width: 800px; margin: 0 auto; border: 1px solid #cbd5e1; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    .kop { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 16px; }
    .kop h3 { margin: 0; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #475569; }
    .kop h2 { margin: 4px 0; font-size: 16px; font-weight: 900; text-transform: uppercase; color: #0f172a; }
    .kop p { margin: 0; font-size: 10px; color: #64748b; }
    .title-box { text-align: center; margin-bottom: 18px; }
    .title-box h4 { margin: 0; font-size: 13px; font-weight: 900; text-transform: uppercase; text-decoration: underline; }
    .title-box .doc-no { font-family: monospace; font-size: 11px; color: #475569; margin-top: 4px; font-weight: 600; }
    .grid-info { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 18px; font-size: 11px; }
    .grid-info div strong { display: block; font-size: 9px; text-transform: uppercase; color: #64748b; margin-bottom: 2px; }
    .table-slip { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .table-slip th { background: #f1f5f9; padding: 8px 10px; border: 1px solid #cbd5e1; font-weight: bold; text-transform: uppercase; font-size: 10px; text-align: left; }
    .total-row td { background: #f8fafc; font-weight: 800; font-size: 12px; padding: 10px; border: 1px solid #cbd5e1; }
    .terbilang-box { background: #fffbeb; border: 1px solid #fde68a; padding: 10px 14px; border-radius: 8px; margin-bottom: 24px; font-size: 11px; }
    .terbilang-box strong { color: #92400e; font-size: 9px; text-transform: uppercase; display: block; margin-bottom: 2px; }
    .signatures { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; text-align: center; font-size: 11px; border-top: 1px solid #e2e8f0; padding-top: 16px; }
    .sig-space { height: 65px; }
    .qr-badge { border: 1px solid #cbd5e1; padding: 8px; display: inline-block; border-radius: 6px; background: #f8fafc; font-family: monospace; font-size: 10px; font-weight: bold; }
    .print-btn { display: inline-block; background: #0f172a; color: #fff; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: bold; margin-bottom: 15px; cursor: pointer; }
    @media print {
      body { margin: 0; }
      .slip-container { border: none; box-shadow: none; padding: 0; max-width: 100%; }
      .no-print { display: none; }
      @page { size: A4 portrait; margin: 15mm; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="text-align: center; margin-bottom: 15px;">
    <button onclick="window.print()" class="print-btn">🖨️ Cetak / Simpan sebagai PDF (A4)</button>
  </div>
  <div class="slip-container">
    <div class="kop">
      <h3>Pemerintah Daerah Provinsi / Kota</h3>
      <h2>Badan Kepegawaian dan Pengembangan Sumber Daya Manusia</h2>
      <p>Gedung Graha Praja Lt. 2, Jl. Pahlawan No. 1, Telp: (021) 555-0199, Email: bkd@pemda.go.id</p>
    </div>
    <div class="title-box">
      <h4>Slip Rincian Potongan Tunjangan Kinerja (Tukin) Absensi</h4>
      <div class="doc-no">Nomor: ${slipNo}</div>
    </div>
    <div class="grid-info">
      <div><strong>Nama Pegawai:</strong> ${emp.name}</div>
      <div><strong>NIP / Kode:</strong> ${emp.nip} (${emp.code})</div>
      <div><strong>Jabatan:</strong> ${emp.position}</div>
      <div><strong>Unit Kerja / SKPD:</strong> ${emp.department}</div>
      <div><strong>Status Kepegawaian:</strong> ${emp.employeeType}</div>
      <div><strong>Periode Evaluasi:</strong> ${currentMonthName} ${selectedYear}</div>
    </div>
    <table class="table-slip">
      <thead>
        <tr>
          <th>Tanggal</th>
          <th style="text-align:center;">Masuk</th>
          <th style="text-align:center;">Pulang</th>
          <th>Keterangan Pelanggaran</th>
          <th style="text-align:right;">Potongan</th>
        </tr>
      </thead>
      <tbody>
        ${violationRows}
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="4" style="text-align:right; text-transform:uppercase;">Total Potongan Denda Tukin:</td>
          <td style="text-align:right; color:#dc2626;">Rp ${emp.totalPenalty.toLocaleString('id-ID')}</td>
        </tr>
      </tfoot>
    </table>
    <div class="terbilang-box">
      <strong>Terbilang:</strong>
      <em>"${angkaTerbilang(emp.totalPenalty)}"</em>
    </div>
    <div class="signatures">
      <div>
        <div class="qr-badge">
          <div>[QR VALIDATED]</div>
          <div style="font-size:8px; color:#64748b; margin-top:2px;">VERIF-${emp.code}-${selectedYear}</div>
        </div>
        <div style="font-size:9px; color:#64748b; margin-top:4px;">Tervalidasi Sistem BKD</div>
      </div>
      <div>
        <span style="color:#64748b;">Pegawai Ybs,</span>
        <div class="sig-space"></div>
        <strong><u>${emp.name}</u></strong>
        <div style="font-size:10px; color:#64748b;">NIP. ${emp.nip}</div>
      </div>
      <div>
        <span style="color:#64748b;">Pejabat Pembuat Komitmen,</span>
        <div class="sig-space"></div>
        <strong><u>Dra. Hj. Wahyuni, M.Si</u></strong>
        <div style="font-size:10px; color:#64748b;">NIP. 197802142003122001</div>
      </div>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    const sanitizedName = emp.name.replace(/[^a-zA-Z0-9]/g, '_');
    link.setAttribute('download', `Dokumen_Slip_Tukin_${emp.code}_${sanitizedName}_${currentMonthName}_${selectedYear}.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showNotification(`Dokumen Slip mandiri untuk ${emp.name} berhasil diunduh.`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* HEADER BAR */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
              Phase 7 & 8 Aktif
            </span>
            <span className="text-xs font-semibold text-slate-500">
              Rekapitulasi Kehadiran & Laporan Potongan Tunjangan Kinerja (Tukin)
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Rekap Bulanan & Slip Potongan Denda Pegawai
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-3xl">
            Kompilasi kehadiran bulanan seluruh ASN & Pegawai, kalkulasi otomatis akumulasi pemotongan Tunjangan Kinerja, serta pencetakan slip denda resmi instansi ber-QR Code.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportSummaryXLSX}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Unduh rekapitulasi kehadiran dan denda seluruh pegawai dalam berkas Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Ekspor Rekap (.xlsx)</span>
          </button>

          <button
            onClick={handleExportAllSlipsExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Unduh rincian seluruh slip denda pegawai dalam satu file itemisasi"
          >
            <FileText className="w-4 h-4 text-indigo-600" />
            <span>Rincian Semua Slip (CSV)</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            title="Unduh ringkasan rekapitulasi bulanan format CSV sederhana"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>CSV</span>
          </button>
        </div>
      </div>

      {/* PERIOD SELECTOR & METRIC CARDS */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        
        {/* Period Selector Card */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-slate-700 font-bold text-xs">
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>Periode Pelaporan</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-bold text-slate-400 block mb-1">Bulan</label>
              <select
                value={selectedMonth}
                onChange={e => setSelectedMonth(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 text-xs font-semibold border border-slate-200 rounded-xl bg-white text-slate-800 focus:outline-hidden"
              >
                <option value={1}>Januari</option>
                <option value={2}>Februari</option>
                <option value={3}>Maret</option>
                <option value={4}>April</option>
                <option value={5}>Mei</option>
                <option value={6}>Juni</option>
                <option value={7}>Juli</option>
                <option value={8}>Agustus</option>
                <option value={9}>September</option>
                <option value={10}>Oktober</option>
                <option value={11}>November</option>
                <option value={12}>Desember</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-400 block mb-1">Tahun</label>
              <select
                value={selectedYear}
                onChange={e => setSelectedYear(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 text-xs font-semibold border border-slate-200 rounded-xl bg-white text-slate-800 focus:outline-hidden"
              >
                <option value={2026}>2026</option>
                <option value={2025}>2025</option>
              </select>
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-600">
            Total Hari Kerja Efektif: <span className="font-bold text-slate-900">21 Hari</span> (Libur Nasional: 1 Hari HUT RI)
          </div>
        </div>

        {/* Total Deductions Metric */}
        <div className="bg-linear-to-br from-rose-500 to-rose-700 text-white p-5 rounded-3xl shadow-sm space-y-1 relative overflow-hidden">
          <div className="flex items-center justify-between text-rose-100 text-xs font-bold">
            <span>Total Potongan Tukin</span>
            <Receipt className="w-5 h-5 text-rose-200" />
          </div>
          <div className="text-2xl sm:text-3xl font-black tracking-tight">
            Rp {metrics.grandTotalDeductions.toLocaleString('id-ID')}
          </div>
          <p className="text-[11px] text-rose-100/90 pt-1">
            Akumulasi denda keterlambatan & alpha instansi periode ini.
          </p>
        </div>

        {/* Total Late Hours */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Total Waktu Terlambat</span>
            <Clock className="w-5 h-5 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900">
            {metrics.totalLateMinutes} <span className="text-sm font-semibold text-slate-500">Menit</span>
          </div>
          <p className="text-[11px] text-slate-500 pt-1">
            Setara {(metrics.totalLateMinutes / 60).toFixed(1)} jam kerja ASN hilang.
          </p>
        </div>

        {/* Compliance Rate */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold">
            <span>Kepatuhan Kehadiran</span>
            <UserCheck className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600">
            {metrics.complianceRate}%
          </div>
          <p className="text-[11px] text-slate-500 pt-1">
            {metrics.cleanEmployeesCount} dari {metrics.totalEmployees} pegawai bebas denda (Rp 0).
          </p>
        </div>

      </div>

      {/* FILTER & TABLE SECTION */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
        
        {/* Filter Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 flex-wrap">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Daftar Rekapitulasi Tukin Bulanan ({selectedMonth === 8 ? 'Agustus' : selectedMonth} {selectedYear})
            </h2>
            <p className="text-xs text-slate-500">
              Menampilkan rincian hari kerja, frekuensi pelanggaran, dan nilai potongan denda per pegawai.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
            {/* Search */}
            <div className="relative flex-1 sm:w-56">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama atau NIP..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            {/* Department */}
            <select
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">Semua Unit Kerja</option>
              {departments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>

            {/* Type */}
            <select
              value={employeeTypeFilter}
              onChange={e => setEmployeeTypeFilter(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">Semua Tipe</option>
              <option value="PNS">PNS</option>
              <option value="PPPK">PPPK</option>
              <option value="HONORER">Honorer</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Pegawai</th>
                <th className="py-3 px-3">Unit Kerja</th>
                <th className="py-3 px-2 text-center">Hadir</th>
                <th className="py-3 px-2 text-center text-amber-700">Telat</th>
                <th className="py-3 px-2 text-center text-orange-700">P. Cepat</th>
                <th className="py-3 px-2 text-center text-rose-700">Alpha</th>
                <th className="py-3 px-3 text-center">Total Telat</th>
                <th className="py-3 px-4 text-right">Potongan Tukin</th>
                <th className="py-3 px-3 text-center">Slip Denda</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-14 text-center text-slate-400">
                    <div className="max-w-sm mx-auto space-y-2">
                      <Users className="w-10 h-10 mx-auto text-slate-300" />
                      <p className="font-semibold text-slate-700">
                        {storedEmployees.length === 0 ? 'Data Peserta Belum Ada' : 'Tidak ada data yang sesuai filter'}
                      </p>
                      <p className="text-xs text-slate-400">
                        {storedEmployees.length === 0
                          ? 'Peserta dummy telah dibersihkan. Silakan unggah peserta Anda di menu Manajemen Pegawai.'
                          : 'Coba sesuaikan kata kunci pencarian atau filter Anda.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                  
                  {/* Pegawai */}
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{emp.name}</div>
                    <div className="text-[11px] text-slate-500 font-mono">NIP: {emp.nip}</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-slate-100 text-slate-700">
                        {emp.employeeType}
                      </span>
                      <span className="text-[10px] text-slate-400 truncate max-w-[150px]">
                        {emp.position}
                      </span>
                    </div>
                  </td>

                  {/* Department */}
                  <td className="py-3 px-3 text-slate-600 text-xs">
                    {emp.department}
                  </td>

                  {/* Present */}
                  <td className="py-3 px-2 text-center font-semibold text-emerald-700">
                    {emp.presentDays} / {emp.totalWorkdays}
                  </td>

                  {/* Late */}
                  <td className="py-3 px-2 text-center font-bold text-amber-600">
                    {emp.lateDays > 0 ? emp.lateDays : '-'}
                  </td>

                  {/* Early */}
                  <td className="py-3 px-2 text-center font-bold text-orange-600">
                    {emp.earlyDays > 0 ? emp.earlyDays : '-'}
                  </td>

                  {/* Alpha */}
                  <td className="py-3 px-2 text-center font-bold text-rose-600">
                    {emp.alphaDays > 0 ? emp.alphaDays : '-'}
                  </td>

                  {/* Total Late minutes */}
                  <td className="py-3 px-3 text-center font-mono text-xs">
                    {emp.accumulatedLateMinutes > 0 ? (
                      <span className="font-bold text-amber-700">
                        {emp.accumulatedLateMinutes} mnt
                      </span>
                    ) : (
                      <span className="text-slate-400">0 mnt</span>
                    )}
                  </td>

                  {/* Total Penalty */}
                  <td className="py-3 px-4 text-right font-mono font-bold">
                    {emp.totalPenalty > 0 ? (
                      <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
                        Rp {emp.totalPenalty.toLocaleString('id-ID')}
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-semibold">
                        Rp 0
                      </span>
                    )}
                  </td>

                  {/* Slip Action & Downloads */}
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => setActiveSlipEmployee(emp)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-700 text-xs font-semibold transition-all cursor-pointer shadow-2xs"
                        title="Buka pratinjau slip lengkap"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>Lihat</span>
                      </button>

                      <button
                        onClick={() => handlePrintOrDownloadPDF(emp)}
                        className="inline-flex items-center gap-1 px-2 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white text-xs font-bold border border-rose-200/80 transition-all cursor-pointer shadow-2xs"
                        title="Unduh / Simpan Slip format PDF"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>PDF</span>
                      </button>

                      <button
                        onClick={() => handleDownloadSlipXLSX(emp)}
                        className="inline-flex items-center gap-1 px-2 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white text-xs font-bold border border-emerald-200/80 transition-all cursor-pointer shadow-2xs"
                        title="Unduh Slip format Excel (.XLSX)"
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                        <span>Excel</span>
                      </button>
                    </div>
                  </td>

                </tr>
              ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* OFFICIAL DEDUCTION SLIP MODAL */}
      {activeSlipEmployee && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 my-8 overflow-hidden">
            
            {/* Modal Top Bar */}
            <div className="bg-slate-900 text-white px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <div>
                  <span className="text-sm font-bold tracking-wide block">
                    Slip Resmi Potongan Tukin Absensi
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Nomor: SLIP-TUKIN/{selectedYear}/{String(selectedMonth).padStart(2, '0')}/{activeSlipEmployee.code}
                  </span>
                </div>
              </div>

              {/* Top Bar Download Actions */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => handlePrintOrDownloadPDF(activeSlipEmployee)}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Simpan atau cetak sebagai file PDF (A4)"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Cetak / PDF</span>
                </button>

                <button
                  onClick={() => handleDownloadSlipXLSX(activeSlipEmployee)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                  title="Unduh slip rincian dalam format Excel (.xlsx)"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Unduh Excel (.xlsx)</span>
                </button>

                <button
                  onClick={() => handleDownloadSlipExcel(activeSlipEmployee)}
                  className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Unduh versi CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>

                <button
                  onClick={() => handlePrintOrDownloadPDF(activeSlipEmployee)}
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Cetak langsung ke printer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak</span>
                </button>

                <button
                  onClick={() => setActiveSlipEmployee(null)}
                  className="p-1.5 rounded-xl hover:bg-white/20 text-slate-400 hover:text-white transition-colors cursor-pointer ml-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sub-bar Info Pegawai & Alternative Save */}
            <div className="bg-slate-100 px-6 py-2 border-b border-slate-200 flex items-center justify-between text-[11px] text-slate-600 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Dokumen verifikasi resmi siap dibagikan kepada <strong>{activeSlipEmployee.name}</strong></span>
              </div>
              <button
                onClick={() => handleDownloadSlipDocument(activeSlipEmployee)}
                className="text-indigo-600 hover:text-indigo-800 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                title="Unduh file dokumen mandiri yang dapat dibuka dan dicetak offline"
              >
                <Download className="w-3 h-3" />
                <span>Simpan File Dokumen Mandiri (.html)</span>
              </button>
            </div>

            {/* Printable Slip Paper */}
            <div className="p-6 sm:p-8 space-y-6 text-slate-800 bg-white" id="printable-slip">
              
              {/* Kop Surat Resmi */}
              <div className="text-center pb-4 border-b-2 border-slate-900 space-y-0.5">
                <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-600">
                  Pemerintah Daerah Provinsi / Kota
                </h3>
                <h2 className="text-base sm:text-lg font-black uppercase text-slate-900 tracking-tight">
                  Badan Kepegawaian dan Pengembangan Sumber Daya Manusia
                </h2>
                <p className="text-[10px] text-slate-500">
                  Gedung Graha Praja Lt. 2, Jl. Pahlawan No. 1, Telp: (021) 555-0199, Email: bkd@pemda.go.id
                </p>
              </div>

              {/* Title & Document Number */}
              <div className="text-center space-y-1">
                <h4 className="text-sm font-black uppercase underline tracking-wide text-slate-900">
                  Slip Rincian Potongan Tunjangan Kinerja (Tukin) Absensi
                </h4>
                <div className="font-mono text-xs text-slate-500 font-semibold">
                  Nomor: SLIP-TUKIN/{selectedYear}/{String(selectedMonth).padStart(2, '0')}/{activeSlipEmployee.code}
                </div>
              </div>

              {/* Pegawai Info Grid */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Nama Pegawai:</span>
                  <span className="font-extrabold text-slate-900">{activeSlipEmployee.name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">NIP / Kode:</span>
                  <span className="font-mono font-bold text-slate-800">{activeSlipEmployee.nip} ({activeSlipEmployee.code})</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Jabatan:</span>
                  <span className="text-slate-700">{activeSlipEmployee.position}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Unit Kerja:</span>
                  <span className="text-slate-700">{activeSlipEmployee.department}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Status Kepegawaian:</span>
                  <span className="font-bold text-indigo-700">{activeSlipEmployee.employeeType}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Periode Potongan:</span>
                  <span className="font-bold text-slate-900">{currentMonthName} {selectedYear}</span>
                </div>
              </div>

              {/* Violations Itemized Table */}
              <div>
                <h5 className="text-xs font-bold text-slate-900 mb-2 uppercase tracking-wide">
                  Rincian Pelanggaran Kehadiran:
                </h5>
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase">
                      <tr>
                        <th className="py-2 px-3">Tanggal</th>
                        <th className="py-2 px-2 text-center">Masuk</th>
                        <th className="py-2 px-2 text-center">Pulang</th>
                        <th className="py-2 px-3">Keterangan Pelanggaran</th>
                        <th className="py-2 px-3 text-right">Potongan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeSlipEmployee.violations.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-6 text-center text-emerald-600 font-bold text-xs bg-emerald-50/50">
                            Tidak Ada Pelanggaran Kehadiran. Kehadiran 100% Sempurna (Potongan Rp 0).
                          </td>
                        </tr>
                      ) : (
                        activeSlipEmployee.violations.map((v, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-medium">
                              {v.date} <span className="text-[10px] text-slate-400">({v.dayName})</span>
                            </td>
                            <td className="py-2.5 px-2 text-center font-mono">{v.firstIn || '-'}</td>
                            <td className="py-2.5 px-2 text-center font-mono">{v.lastOut || '-'}</td>
                            <td className="py-2.5 px-3 text-slate-700">{v.violationType}</td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-600">
                              Rp {v.amount.toLocaleString('id-ID')}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    <tfoot className="bg-slate-100 border-t border-slate-200 font-bold">
                      <tr>
                        <td colSpan={4} className="py-2.5 px-3 text-right uppercase text-[11px] text-slate-700">
                          Total Potongan Denda Tukin:
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-rose-700 text-sm">
                          Rp {activeSlipEmployee.totalPenalty.toLocaleString('id-ID')}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* Terbilang Box */}
              <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl text-xs space-y-0.5">
                <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">
                  Terbilang:
                </span>
                <span className="font-bold italic text-slate-900">
                  "{angkaTerbilang(activeSlipEmployee.totalPenalty)}"
                </span>
              </div>

              {/* Official Signatures & QR Code */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-200 text-center text-xs">
                
                {/* QR Code Verification */}
                <div className="flex flex-col items-center justify-center space-y-1">
                  <div className="w-16 h-16 bg-slate-100 border border-slate-300 rounded-lg flex items-center justify-center p-1">
                    <QrCode className="w-full h-full text-slate-800" />
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono">
                    ID: VERIF-{activeSlipEmployee.code}-2026
                  </span>
                </div>

                {/* Pegawai */}
                <div className="space-y-12">
                  <span className="text-[10px] text-slate-500 block">Pegawai yang Bersangkutan,</span>
                  <div>
                    <div className="font-bold underline text-slate-900">{activeSlipEmployee.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono">NIP. {activeSlipEmployee.nip}</div>
                  </div>
                </div>

                {/* Kasubag Kepegawaian */}
                <div className="space-y-12">
                  <span className="text-[10px] text-slate-500 block">Pejabat Pembuat Komitmen (PPK),</span>
                  <div>
                    <div className="font-bold underline text-slate-900">Dra. Hj. Wahyuni, M.Si</div>
                    <div className="text-[10px] text-slate-500 font-mono">NIP. 197802142003122001</div>
                  </div>
                </div>

              </div>

            </div>

            {/* Modal Bottom Footer Actions */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-wrap gap-3">
              <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Format siap verifikasi pegawai &bull; Dilengkapi nomor register dan terbilang rupiah</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadSlipExcel(activeSlipEmployee)}
                  className="px-3.5 py-1.5 rounded-xl border border-emerald-300 bg-white hover:bg-emerald-50 text-emerald-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Unduh Excel</span>
                </button>
                <button
                  onClick={() => handlePrintOrDownloadPDF(activeSlipEmployee)}
                  className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh PDF Resmi</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Embedded Clean Print Stylesheet for A4 Official Slip */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-slip, #printable-slip * {
            visibility: visible !important;
          }
          #printable-slip {
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 24px !important;
            background: white !important;
            border: none !important;
            box-shadow: none !important;
          }
          @page {
            size: A4 portrait;
            margin: 12mm 15mm;
          }
        }
      `}} />

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-3 text-xs max-w-md">
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
              ✓
            </div>
            <div className="font-medium text-slate-200">{toastMessage}</div>
            <button
              onClick={() => setToastMessage(null)}
              className="ml-auto text-slate-400 hover:text-white text-base leading-none cursor-pointer shrink-0"
            >
              ×
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
