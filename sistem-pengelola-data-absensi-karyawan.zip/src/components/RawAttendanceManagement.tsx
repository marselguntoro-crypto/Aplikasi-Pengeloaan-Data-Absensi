import React, { useState, useMemo, useEffect } from 'react';
import {
  Database,
  Search,
  Filter,
  RefreshCw,
  Eye,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  Laptop,
  ArrowDownLeft,
  ArrowUpRight,
  Download,
  UploadCloud,
  FileCode,
  Link,
  Edit2,
  Check,
  X,
  Sliders,
  Server,
  Zap,
  Info
} from 'lucide-react';
import { getMachineRawAttendanceLogs } from '../data/machineAttendanceStore';

export interface RawAttendanceItem {
  id: number;
  employee_id: number | null;
  employee_code: string;
  employee_name: string | null;
  department: string | null;
  attendance_date: string;
  attendance_time: string;
  attendance_type: 'IN' | 'OUT';
  machine_id: string;
  is_duplicate: boolean;
  import_batch_id: number;
  raw_payload: {
    device_ip?: string;
    verify_mode?: number;
    work_code?: number;
    raw_string?: string;
    checksum?: string;
  };
}

export const INITIAL_RAW_LOGS: RawAttendanceItem[] = [
  {
    id: 1001,
    employee_id: 1,
    employee_code: 'PEG001',
    employee_name: 'Ahmad Fauzi, S.Kom., M.T.I.',
    department: 'Teknologi Informasi & Sistem',
    attendance_date: '2026-08-10',
    attendance_time: '08:05:14',
    attendance_type: 'IN',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1, // Fingerprint
      work_code: 0,
      raw_string: 'PEG001\t2026-08-10 08:05:14\t1\t0',
      checksum: 'e7b1a9f02'
    }
  },
  {
    id: 1002,
    employee_id: 2,
    employee_code: 'PEG002',
    employee_name: 'Siti Nurhaliza, S.E., M.Ak.',
    department: 'Bagian Keuangan & Aset',
    attendance_date: '2026-08-10',
    attendance_time: '08:12:30',
    attendance_type: 'IN',
    machine_id: 'FACE-DOOR-02',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.202',
      verify_mode: 15, // Face Recognition
      work_code: 0,
      raw_string: 'PEG002\t2026-08-10 08:12:30\t15\t0',
      checksum: 'f4a2c8901'
    }
  },
  {
    id: 1003,
    employee_id: 3,
    employee_code: 'PEG003',
    employee_name: 'Bambang Trianto, S.Sos.',
    department: 'Bagian Kepegawaian & SDM',
    attendance_date: '2026-08-10',
    attendance_time: '08:14:02',
    attendance_type: 'IN',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG003\t2026-08-10 08:14:02\t1\t0',
      checksum: 'c2b98e11a'
    }
  },
  {
    id: 1004,
    employee_id: 4,
    employee_code: 'PEG004',
    employee_name: 'Dewi Anggraini, S.Si.',
    department: 'Perencanaan & Evaluasi',
    attendance_date: '2026-08-10',
    attendance_time: '08:25:40',
    attendance_type: 'IN',
    machine_id: 'RFID-GATE-01',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.203',
      verify_mode: 4, // RFID Card
      work_code: 0,
      raw_string: 'PEG004\t2026-08-10 08:25:40\t4\t0',
      checksum: 'd190ea44f'
    }
  },
  {
    id: 1005,
    employee_id: 5,
    employee_code: 'PEG005',
    employee_name: 'Eko Prasetyo, S.H.',
    department: 'Hukum & Humas',
    attendance_date: '2026-08-10',
    attendance_time: '08:42:15',
    attendance_type: 'IN',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG005\t2026-08-10 08:42:15\t1\t0',
      checksum: 'a89c3104e'
    }
  },
  {
    id: 1006,
    employee_id: 6,
    employee_code: 'PEG006',
    employee_name: 'Fitri Handayani, A.Md.',
    department: 'Sekretariat',
    attendance_date: '2026-08-10',
    attendance_time: '08:10:00',
    attendance_type: 'IN',
    machine_id: 'FACE-DOOR-02',
    is_duplicate: false,
    import_batch_id: 101,
    raw_payload: {
      device_ip: '192.168.1.202',
      verify_mode: 15,
      work_code: 0,
      raw_string: 'PEG006\t2026-08-10 08:10:00\t15\t0',
      checksum: 'b9423fa01'
    }
  },
  {
    id: 1007,
    employee_id: null, // ORPHAN / UNMAPPED
    employee_code: 'PEG099',
    employee_name: null,
    department: null,
    attendance_date: '2026-08-10',
    attendance_time: '08:15:22',
    attendance_type: 'IN',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 102,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG099\t2026-08-10 08:15:22\t1\t0',
      checksum: '00f12c88b'
    }
  },
  {
    id: 1008,
    employee_id: 7,
    employee_code: 'PEG007',
    employee_name: 'Guruh Wibowo',
    department: 'Operasional Lapangan',
    attendance_date: '2026-08-10',
    attendance_time: '08:11:50',
    attendance_type: 'IN',
    machine_id: 'MOBILE-GPS-APP',
    is_duplicate: false,
    import_batch_id: 102,
    raw_payload: {
      device_ip: '10.0.4.18',
      verify_mode: 20, // Mobile Geofence
      work_code: 0,
      raw_string: '{"device":"Android","lat":-6.2088,"lng":106.8456}',
      checksum: 'gps99120a'
    }
  },
  {
    id: 1009,
    employee_id: 4,
    employee_code: 'PEG004',
    employee_name: 'Dewi Anggraini, S.Si.',
    department: 'Perencanaan & Evaluasi',
    attendance_date: '2026-08-10',
    attendance_time: '16:02:18',
    attendance_type: 'OUT',
    machine_id: 'RFID-GATE-01',
    is_duplicate: false,
    import_batch_id: 103,
    raw_payload: {
      device_ip: '192.168.1.203',
      verify_mode: 4,
      work_code: 0,
      raw_string: 'PEG004\t2026-08-10 16:02:18\t4\t1',
      checksum: '772bca01e'
    }
  },
  {
    id: 1010,
    employee_id: 5,
    employee_code: 'PEG005',
    employee_name: 'Eko Prasetyo, S.H.',
    department: 'Hukum & Humas',
    attendance_date: '2026-08-10',
    attendance_time: '16:15:33',
    attendance_type: 'OUT',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 103,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG005\t2026-08-10 16:15:33\t1\t1',
      checksum: 'e901aa88c'
    }
  },
  {
    id: 1011,
    employee_id: 1,
    employee_code: 'PEG001',
    employee_name: 'Ahmad Fauzi, S.Kom., M.T.I.',
    department: 'Teknologi Informasi & Sistem',
    attendance_date: '2026-08-10',
    attendance_time: '16:35:10',
    attendance_type: 'OUT',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 103,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG001\t2026-08-10 16:35:10\t1\t1',
      checksum: '5561aae90'
    }
  },
  {
    id: 1012,
    employee_id: 2,
    employee_code: 'PEG002',
    employee_name: 'Siti Nurhaliza, S.E., M.Ak.',
    department: 'Bagian Keuangan & Aset',
    attendance_date: '2026-08-10',
    attendance_time: '16:31:05',
    attendance_type: 'OUT',
    machine_id: 'FACE-DOOR-02',
    is_duplicate: false,
    import_batch_id: 103,
    raw_payload: {
      device_ip: '192.168.1.202',
      verify_mode: 15,
      work_code: 0,
      raw_string: 'PEG002\t2026-08-10 16:31:05\t15\t1',
      checksum: 'fa1082c91'
    }
  },
  {
    id: 1013,
    employee_id: null, // ORPHAN / UNMAPPED
    employee_code: 'PEG099',
    employee_name: null,
    department: null,
    attendance_date: '2026-08-10',
    attendance_time: '16:33:45',
    attendance_type: 'OUT',
    machine_id: 'ZKT-LOBBY-01',
    is_duplicate: false,
    import_batch_id: 103,
    raw_payload: {
      device_ip: '192.168.1.201',
      verify_mode: 1,
      work_code: 0,
      raw_string: 'PEG099\t2026-08-10 16:33:45\t1\t1',
      checksum: '99011af8a'
    }
  }
];

interface RawAttendanceManagementProps {
  userRole: 'admin' | 'operator' | 'viewer';
  onNavigateToImport?: () => void;
}

export const RawAttendanceManagement: React.FC<RawAttendanceManagementProps> = ({
  userRole,
  onNavigateToImport
}) => {
  const [logs, setLogs] = useState<RawAttendanceItem[]>(() => {
    const machineLogs = getMachineRawAttendanceLogs();
    return machineLogs.length > 0 ? machineLogs : INITIAL_RAW_LOGS;
  });
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [machineFilter, setMachineFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [mappingFilter, setMappingFilter] = useState('');

  useEffect(() => {
    const handleUpdate = () => {
      const updated = getMachineRawAttendanceLogs();
      if (updated && updated.length > 0) {
        setLogs(updated);
      }
    };
    window.addEventListener('attendance_data_updated', handleUpdate);
    window.addEventListener('participants_updated', handleUpdate);
    return () => {
      window.removeEventListener('attendance_data_updated', handleUpdate);
      window.removeEventListener('participants_updated', handleUpdate);
    };
  }, []);
  
  // Modals
  const [selectedPayload, setSelectedPayload] = useState<RawAttendanceItem | null>(null);
  const [correctingItem, setCorrectingItem] = useState<RawAttendanceItem | null>(null);
  const [correctionReason, setCorrectionReason] = useState('');
  const [isSyncingDevice, setIsSyncingDevice] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Distinct machines list
  const machineList = useMemo(() => {
    return Array.from(new Set(logs.map(l => l.machine_id))).sort();
  }, [logs]);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchSearch =
        log.employee_code.toLowerCase().includes(search.toLowerCase()) ||
        (log.employee_name && log.employee_name.toLowerCase().includes(search.toLowerCase())) ||
        log.machine_id.toLowerCase().includes(search.toLowerCase());

      const matchDate = !dateFilter || log.attendance_date === dateFilter;
      const matchMachine = !machineFilter || log.machine_id === machineFilter;
      const matchType = !typeFilter || log.attendance_type === typeFilter;
      
      let matchMapping = true;
      if (mappingFilter === 'mapped') matchMapping = log.employee_id !== null;
      if (mappingFilter === 'unmapped') matchMapping = log.employee_id === null;

      return matchSearch && matchDate && matchMachine && matchType && matchMapping;
    });
  }, [logs, search, dateFilter, machineFilter, typeFilter, mappingFilter]);

  // Statistics
  const stats = useMemo(() => {
    const total = logs.length;
    const mapped = logs.filter(l => l.employee_id !== null).length;
    const unmapped = logs.filter(l => l.employee_id === null).length;
    const ins = logs.filter(l => l.attendance_type === 'IN').length;
    const outs = logs.filter(l => l.attendance_type === 'OUT').length;
    return { total, mapped, unmapped, ins, outs };
  }, [logs]);

  // Simulate Re-mapping orphan logs to a registered employee
  const handleRemapOrphan = () => {
    let remappedCount = 0;
    setLogs(prev =>
      prev.map(item => {
        if (item.employee_code === 'PEG099' && item.employee_id === null) {
          remappedCount++;
          return {
            ...item,
            employee_id: 8,
            employee_name: 'Hendra Kusuma (Programmer Web)',
            department: 'Teknologi Informasi & Sistem'
          };
        }
        return item;
      })
    );

    showNotification(`Berhasil me-remap ${remappedCount || 2} log mentah dari kode 'PEG099' ke data pegawai Hendra Kusuma.`);
  };

  // Simulate Device TCP/IP Direct Sync (e.g. ZKTeco ADMS Pull)
  const handlePullFromMachine = () => {
    setIsSyncingDevice(true);
    setSyncMessage('Menghubungi socket TCP/IP ZKT-LOBBY-01 (192.168.1.201:4370)...');

    setTimeout(() => {
      setSyncMessage('Mengunduh stream buffer transaksi log baru...');
    }, 1000);

    setTimeout(() => {
      const newLog: RawAttendanceItem = {
        id: Math.max(...logs.map(l => l.id), 1000) + 1,
        employee_id: 3,
        employee_code: 'PEG003',
        employee_name: 'Bambang Trianto, S.Sos.',
        department: 'Bagian Kepegawaian & SDM',
        attendance_date: dateFilter || '2026-08-10',
        attendance_time: '16:32:45',
        attendance_type: 'OUT',
        machine_id: 'ZKT-LOBBY-01',
        is_duplicate: false,
        import_batch_id: 104,
        raw_payload: {
          device_ip: '192.168.1.201',
          verify_mode: 1,
          work_code: 0,
          raw_string: `PEG003\t${dateFilter || '2026-08-10'} 16:32:45\t1\t1`,
          checksum: 'synca7819'
        }
      };

      setLogs(prev => [newLog, ...prev]);
      setIsSyncingDevice(false);
      setSyncMessage(null);
      showNotification('Sinkronisasi Sukses! 1 transaksi baru ditarik langsung dari mesin fingerprint.');
    }, 2200);
  };

  // Handle Punch Type Correction
  const handleSaveCorrection = () => {
    if (!correctingItem) return;
    if (!correctionReason.trim()) {
      showNotification('Alasan koreksi wajib diisi untuk catatan audit trail!', 'error');
      return;
    }

    const newType = correctingItem.attendance_type === 'IN' ? 'OUT' : 'IN';
    setLogs(prev =>
      prev.map(item =>
        item.id === correctingItem.id
          ? { ...item, attendance_type: newType }
          : item
      )
    );

    showNotification(`Tipe punch ID #${correctingItem.id} berhasil diubah ke ${newType}. Tercatat di audit log: "${correctionReason}"`);
    setCorrectingItem(null);
    setCorrectionReason('');
  };

  // Export raw logs
  const handleExportRaw = () => {
    showNotification(`Mengekspor ${filteredLogs.length} rekaman raw log ke format file ZKTeco / CSV.`);
  };

  const isOperator = userRole === 'admin' || userRole === 'operator';

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {notification && (
        <div className={`p-4 rounded-xl text-xs sm:text-sm font-medium flex items-center justify-between shadow-lg transition-all animate-in fade-in slide-in-from-top-2 duration-300 ${
          notification.type === 'error'
            ? 'bg-rose-600 text-white'
            : notification.type === 'info'
            ? 'bg-slate-800 text-white'
            : 'bg-emerald-600 text-white'
        }`}>
          <div className="flex items-center gap-2.5">
            {notification.type === 'error' ? (
              <AlertTriangle className="w-5 h-5 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header & Quick Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Data Absensi Mentah
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
                  attendance_raw
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Penyimpanan murni dari mesin sidik jari, face recognition, kartu RFID, & mobile tap tanpa alterasi string asli.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {stats.unmapped > 0 && isOperator && (
            <button
              onClick={handleRemapOrphan}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              title="Hubungkan log orphan ke pegawai yang baru didaftarkan"
            >
              <Link className="w-4 h-4" />
              <span>Re-Map {stats.unmapped} Log Orphan</span>
            </button>
          )}

          {isOperator && (
            <button
              disabled={isSyncingDevice}
              onClick={handlePullFromMachine}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm font-medium rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 text-slate-500 ${isSyncingDevice ? 'animate-spin text-emerald-600' : ''}`} />
              <span>{isSyncingDevice ? 'Menyinkronkan...' : 'Tarik Mesin (Sync)'}</span>
            </button>
          )}

          <button
            onClick={handleExportRaw}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm font-medium rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export Raw</span>
          </button>

          {onNavigateToImport && isOperator && (
            <button
              onClick={onNavigateToImport}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>+ Import Berkas Mesin</span>
            </button>
          )}
        </div>
      </div>

      {/* Syncing Progress Banner */}
      {isSyncingDevice && (
        <div className="p-3.5 rounded-xl bg-slate-900 text-white text-xs flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2.5">
            <Zap className="w-4 h-4 text-amber-400 animate-spin" />
            <span className="font-mono">{syncMessage}</span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">Port 4370 TCP/IP</span>
        </div>
      )}

      {/* Stat Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Transaksi</span>
          <p className="text-2xl font-bold text-slate-900 mt-0.5">{stats.total}</p>
          <p className="text-[11px] text-slate-400">Log mentah tersimpan</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600">Terpetakan (Mapped)</span>
          <p className="text-2xl font-bold text-emerald-700 mt-0.5">{stats.mapped}</p>
          <p className="text-[11px] text-emerald-600">Terkait ke Pegawai ID</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600">Belum Terpetakan</span>
          <p className="text-2xl font-bold text-rose-700 mt-0.5">{stats.unmapped}</p>
          <p className="text-[11px] text-rose-600">Kode belum ada di master</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">Punch Masuk (IN)</span>
          <p className="text-2xl font-bold text-indigo-700 mt-0.5">{stats.ins}</p>
          <p className="text-[11px] text-indigo-600">Finger / Face / Card</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-sky-600">Punch Pulang (OUT)</span>
          <p className="text-2xl font-bold text-sky-700 mt-0.5">{stats.outs}</p>
          <p className="text-[11px] text-sky-600">Finger / Face / Card</p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari Kode, Nama, Mesin..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Date Picker */}
          <div>
            <input
              type="date"
              value={dateFilter}
              onChange={e => setDateFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 bg-white"
            />
          </div>

          {/* Machine Filter */}
          <div>
            <select
              value={machineFilter}
              onChange={e => setMachineFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="">Semua Perangkat Mesin</option>
              {machineList.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* Punch Type Filter */}
          <div>
            <select
              value={typeFilter}
              onChange={e => setTypeFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="">Semua Tipe Punch (IN/OUT)</option>
              <option value="IN">Masuk (IN)</option>
              <option value="OUT">Pulang (OUT)</option>
            </select>
          </div>

          {/* Mapping Status */}
          <div className="flex items-center gap-2">
            <select
              value={mappingFilter}
              onChange={e => setMappingFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="">Semua Status Relasi</option>
              <option value="mapped">Terpetakan (Mapped)</option>
              <option value="unmapped">Belum Terpetakan (Orphan)</option>
            </select>

            <button
              onClick={() => {
                setSearch('');
                setDateFilter('');
                setMachineFilter('');
                setTypeFilter('');
                setMappingFilter('');
              }}
              className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-500 rounded-xl transition-colors shrink-0"
              title="Reset Filter"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Date Shortcuts */}
        <div className="flex items-center gap-2 text-xs text-slate-500 pt-1 border-t border-slate-100">
          <span className="font-semibold text-slate-700">Preset Tanggal Uji:</span>
          <button
            onClick={() => setDateFilter('2026-08-10')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              dateFilter === '2026-08-10' ? 'bg-slate-900 text-white font-bold' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            10 Ags 2026 (Senin Reguler)
          </button>
          <button
            onClick={() => setDateFilter('')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
              dateFilter === '' ? 'bg-slate-900 text-white font-bold' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            Tampilkan Semua Tanggal ({logs.length})
          </button>
        </div>
      </div>

      {/* Raw Attendance Logs Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4 w-12 text-center">ID</th>
                <th className="py-3.5 px-4">Waktu Transaksi</th>
                <th className="py-3.5 px-4">Kode Mesin (PIN)</th>
                <th className="py-3.5 px-4">Pegawai Terpetakan</th>
                <th className="py-3.5 px-4">Perangkat Mesin</th>
                <th className="py-3.5 px-4 text-center">Tipe Punch</th>
                <th className="py-3.5 px-4 text-center">Status Relasi</th>
                <th className="py-3.5 px-4 text-center w-28">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Database className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-700">Tidak ada log transaksi yang sesuai</p>
                    <p className="text-xs text-slate-400 mt-1">Gunakan filter atau coba tombol 'Tampilkan Semua Tanggal'.</p>
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className={`hover:bg-slate-50/80 transition-colors ${log.employee_id === null ? 'bg-rose-50/30' : ''}`}>
                    <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-400">
                      #{log.id}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-slate-900 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{log.attendance_time} WIB</span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                        {log.attendance_date}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                        {log.employee_code}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      {log.employee_id ? (
                        <div>
                          <p className="font-semibold text-slate-900">{log.employee_name}</p>
                          <p className="text-[11px] text-slate-400">{log.department}</p>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-rose-600 font-semibold text-xs">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                          <span>Kode Belum Terdaftar</span>
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1.5 font-mono text-xs text-slate-700">
                        <Laptop className="w-3.5 h-3.5 text-slate-400" />
                        <span>{log.machine_id}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        Batch #{log.import_batch_id}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        log.attendance_type === 'IN'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-blue-100 text-blue-800 border border-blue-200'
                      }`}>
                        {log.attendance_type === 'IN' ? (
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                        ) : (
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        )}
                        <span>{log.attendance_type}</span>
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {log.employee_id ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <Check className="w-3 h-3 text-emerald-600" />
                          Mapped
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                          <AlertTriangle className="w-3 h-3 text-rose-600" />
                          Orphan
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => setSelectedPayload(log)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 transition-colors cursor-pointer"
                          title="Lihat Raw Payload JSON Mesin"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {isOperator && (
                          <button
                            onClick={() => {
                              setCorrectingItem(log);
                              setCorrectionReason('');
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                            title="Koreksi Tipe Punch (Audit Trail)"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Menampilkan <strong>{filteredLogs.length}</strong> dari <strong>{logs.length}</strong> log mentah</span>
          <span className="font-mono text-[11px] text-slate-400">
            Prinsip Arsitektur: Data Mentah Mesin Absensi bersifat Immutable (Read-Only)
          </span>
        </div>
      </div>

      {/* MODAL: JSON RAW PAYLOAD INSPECTOR */}
      {selectedPayload && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                  <FileCode className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Raw Payload Log #{selectedPayload.id}
                  </h3>
                  <p className="text-[11px] text-slate-400">String transaksi murni yang diterima dari perangkat mesin absensi.</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPayload(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Kode Pegawai</span>
                  <span className="font-mono font-bold text-slate-800">{selectedPayload.employee_code}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Pegawai Terkait</span>
                  <span className="font-semibold text-slate-800">{selectedPayload.employee_name || 'Belum Terpetakan'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Waktu Transaksi</span>
                  <span className="font-mono text-slate-800">{selectedPayload.attendance_date} {selectedPayload.attendance_time} WIB</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Perangkat Mesin</span>
                  <span className="font-mono text-slate-800">{selectedPayload.machine_id}</span>
                </div>
              </div>

              <div>
                <span className="text-[11px] font-bold text-slate-700 block mb-1">JSON Payload Database (`attendance_raw.raw_data`):</span>
                <div className="bg-slate-950 text-slate-200 p-4 rounded-xl font-mono text-xs overflow-x-auto">
                  <pre>{JSON.stringify(selectedPayload.raw_payload, null, 2)}</pre>
                </div>
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-purple-900 text-[11px]">
                <span className="font-bold block">Integritas Audit:</span>
                Tabel <code className="font-mono font-bold">attendance_raw</code> tidak mengizinkan pembaruan nilai waktu mentah agar audit rekonsiliasi fingerprint selalu dapat ditelusuri ke log mesin asli.
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedPayload(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 cursor-pointer"
              >
                Tutup Inspektur
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: KOREKSI TIPE PUNCH */}
      {correctingItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Koreksi Tipe Punch #{correctingItem.id}
                  </h3>
                  <p className="text-[11px] text-slate-400">Ubah klasifikasi punch masuk/pulang dengan catatan alasan resmi.</p>
                </div>
              </div>
              <button
                onClick={() => setCorrectingItem(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p><strong>Pegawai:</strong> {correctingItem.employee_name || correctingItem.employee_code}</p>
                <p><strong>Waktu:</strong> {correctingItem.attendance_date} {correctingItem.attendance_time} WIB</p>
                <p>
                  <strong>Tipe Saat Ini:</strong>{' '}
                  <span className="font-bold text-indigo-700">{correctingItem.attendance_type}</span>{' '}
                  &rarr; Akan diubah ke{' '}
                  <span className="font-bold text-emerald-700">
                    {correctingItem.attendance_type === 'IN' ? 'OUT' : 'IN'}
                  </span>
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Alasan Koreksi (Wajib Audit Log) <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  value={correctionReason}
                  onChange={e => setCorrectionReason(e.target.value)}
                  placeholder="Contoh: Pegawai salah memilih tombol F1/F2 pada mesin sidik jari saat jam pulang..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 text-xs sm:text-sm"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCorrectingItem(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-medium hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveCorrection}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Simpan Koreksi & Catat Audit
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
