import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  CalendarRange,
  Clock,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Download,
  Search,
  Filter,
  RefreshCw,
  Sun,
  Moon,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Info,
  CalendarCheck,
  Building,
  Sliders,
  Play,
  RotateCcw,
  Layers,
  ArrowRight,
  X
} from 'lucide-react';

export interface HolidayItem {
  id: number;
  name: string;
  date: string; // YYYY-MM-DD
  type: 'national' | 'joint_leave' | 'local' | 'special';
  description?: string;
  isPenaltyExempt: boolean;
}

export interface WorkScheduleItem {
  id: number;
  dayOfWeek: number; // 1=Senin ... 7=Minggu
  dayName: string;
  isWorkday: boolean;
  inTime: string;
  outTime: string;
  gracePeriodMinutes: number;
  breakTime: string;
  notes: string;
}

// 25 Hari Libur Resmi 2026 (17 Libur Nasional + 8 Cuti Bersama SKB 3 Menteri)
export const OFFICIAL_2026_HOLIDAYS: HolidayItem[] = [
  { id: 1, date: '2026-01-01', name: 'Tahun Baru 2026 Masehi', type: 'national', isPenaltyExempt: true, description: 'Libur Nasional Tahun Baru Masehi' },
  { id: 2, date: '2026-01-16', name: 'Isra Mikraj Nabi Muhammad SAW', type: 'national', isPenaltyExempt: true, description: 'Peringatan Isra Mikraj 1447 H' },
  { id: 3, date: '2026-02-16', name: 'Cuti Bersama Tahun Baru Imlek 2577', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama SKB 3 Menteri' },
  { id: 4, date: '2026-02-17', name: 'Tahun Baru Imlek 2577 Kongzili', type: 'national', isPenaltyExempt: true, description: 'Tahun Baru Imlek' },
  { id: 5, date: '2026-03-18', name: 'Cuti Bersama Hari Suci Nyepi', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Hari Suci Nyepi 1948' },
  { id: 6, date: '2026-03-19', name: 'Hari Suci Nyepi (Tahun Baru Saka 1948)', type: 'national', isPenaltyExempt: true, description: 'Hari Suci Nyepi' },
  { id: 7, date: '2026-03-20', name: 'Cuti Bersama Hari Raya Idulfitri 1447 H', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Menjelang Idulfitri' },
  { id: 8, date: '2026-03-21', name: 'Hari Raya Idulfitri 1447 H (Hari 1)', type: 'national', isPenaltyExempt: true, description: 'Hari Raya Idulfitri 1 Syawal 1447 H' },
  { id: 9, date: '2026-03-22', name: 'Hari Raya Idulfitri 1447 H (Hari 2)', type: 'national', isPenaltyExempt: true, description: 'Hari Raya Idulfitri 2 Syawal 1447 H' },
  { id: 10, date: '2026-03-23', name: 'Cuti Bersama Hari Raya Idulfitri 1447 H', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Pasca Idulfitri' },
  { id: 11, date: '2026-03-24', name: 'Cuti Bersama Hari Raya Idulfitri 1447 H', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Pasca Idulfitri' },
  { id: 12, date: '2026-04-03', name: 'Wafat Yesus Kristus (Jumat Agung)', type: 'national', isPenaltyExempt: true, description: 'Peringatan Wafat Yesus Kristus' },
  { id: 13, date: '2026-04-05', name: 'Kebangkitan Yesus Kristus (Paskah)', type: 'national', isPenaltyExempt: true, description: 'Hari Raya Paskah' },
  { id: 14, date: '2026-05-01', name: 'Hari Buruh Internasional', type: 'national', isPenaltyExempt: true, description: 'May Day' },
  { id: 15, date: '2026-05-14', name: 'Kenaikan Yesus Kristus', type: 'national', isPenaltyExempt: true, description: 'Kenaikan Yesus Kristus' },
  { id: 16, date: '2026-05-15', name: 'Cuti Bersama Kenaikan Yesus Kristus', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama SKB 3 Menteri' },
  { id: 17, date: '2026-05-27', name: 'Hari Raya Iduladha 1447 H', type: 'national', isPenaltyExempt: true, description: 'Hari Raya Kurban / Iduladha' },
  { id: 18, date: '2026-05-28', name: 'Cuti Bersama Hari Raya Iduladha 1447 H', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Iduladha' },
  { id: 19, date: '2026-05-31', name: 'Hari Raya Waisak 2570 BE', type: 'national', isPenaltyExempt: true, description: 'Hari Trisuci Waisak' },
  { id: 20, date: '2026-06-01', name: 'Hari Lahir Pancasila', type: 'national', isPenaltyExempt: true, description: 'Hari Lahir Pancasila' },
  { id: 21, date: '2026-06-16', name: 'Tahun Baru Islam 1448 H (1 Muharam)', type: 'national', isPenaltyExempt: true, description: 'Tahun Baru Hijriah' },
  { id: 22, date: '2026-08-17', name: 'Proklamasi Kemerdekaan RI ke-81', type: 'national', isPenaltyExempt: true, description: 'HUT Kemerdekaan Republik Indonesia' },
  { id: 23, date: '2026-08-25', name: 'Maulid Nabi Muhammad SAW', type: 'national', isPenaltyExempt: true, description: 'Peringatan Kelahiran Nabi Muhammad SAW' },
  { id: 24, date: '2026-12-24', name: 'Cuti Bersama Kelahiran Yesus Kristus', type: 'joint_leave', isPenaltyExempt: true, description: 'Cuti Bersama Malam Natal' },
  { id: 25, date: '2026-12-25', name: 'Kelahiran Yesus Kristus (Hari Natal)', type: 'national', isPenaltyExempt: true, description: 'Hari Raya Natal' },
];

export const INITIAL_SCHEDULES: WorkScheduleItem[] = [
  { id: 1, dayOfWeek: 1, dayName: 'Senin', isWorkday: true, inTime: '08:15', outTime: '16:30', gracePeriodMinutes: 0, breakTime: '12:00 - 13:00', notes: 'Hari Kerja Normal' },
  { id: 2, dayOfWeek: 2, dayName: 'Selasa', isWorkday: true, inTime: '08:15', outTime: '16:30', gracePeriodMinutes: 0, breakTime: '12:00 - 13:00', notes: 'Hari Kerja Normal' },
  { id: 3, dayOfWeek: 3, dayName: 'Rabu', isWorkday: true, inTime: '08:15', outTime: '16:30', gracePeriodMinutes: 0, breakTime: '12:00 - 13:00', notes: 'Hari Kerja Normal' },
  { id: 4, dayOfWeek: 4, dayName: 'Kamis', isWorkday: true, inTime: '08:15', outTime: '16:30', gracePeriodMinutes: 0, breakTime: '12:00 - 13:00', notes: 'Hari Kerja Normal' },
  { id: 5, dayOfWeek: 5, dayName: 'Jumat', isWorkday: true, inTime: '08:15', outTime: '17:00', gracePeriodMinutes: 0, breakTime: '11:30 - 13:00', notes: 'Hari Kerja Jumat (Pulang 17:00 WIB, Istirahat Sholat Jumat)' },
  { id: 6, dayOfWeek: 6, dayName: 'Sabtu', isWorkday: false, inTime: '-', outTime: '-', gracePeriodMinutes: 0, breakTime: '-', notes: 'Akhir Pekan (Libur Reguler)' },
  { id: 7, dayOfWeek: 7, dayName: 'Minggu', isWorkday: false, inTime: '-', outTime: '-', gracePeriodMinutes: 0, breakTime: '-', notes: 'Akhir Pekan (Libur Reguler)' },
];

const MONTH_NAMES = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

interface WorkCalendarManagementProps {
  userRole: 'admin' | 'operator' | 'viewer';
  onSelectDateForDashboard?: (date: string) => void;
}

export const WorkCalendarManagement: React.FC<WorkCalendarManagementProps> = ({
  userRole,
  onSelectDateForDashboard
}) => {
  const isOperator = userRole === 'admin' || userRole === 'operator';

  // Sub-Tab Navigation
  const [activeTab, setActiveTab] = useState<'calendar' | 'holidays' | 'schedules' | 'simulator'>('calendar');

  // Calendar Year & Month View
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(7); // 0-indexed (7 = Agustus 2026)
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>('2026-08-17');

  // Holiday Data State
  const [holidays, setHolidays] = useState<HolidayItem[]>(OFFICIAL_2026_HOLIDAYS);
  const [holidaySearch, setHolidaySearch] = useState('');
  const [holidayTypeFilter, setHolidayTypeFilter] = useState('');

  // Schedules Data State
  const [schedules, setSchedules] = useState<WorkScheduleItem[]>(INITIAL_SCHEDULES);
  const [isRamadhanModeActive, setIsRamadhanModeActive] = useState(false);
  const [ramadhanStartDate, setRamadhanStartDate] = useState('2026-02-18');
  const [ramadhanEndDate, setRamadhanEndDate] = useState('2026-03-20');

  // Custom Date Overrides (e.g., Pilkada, Acara Instansi)
  const [customOverrides, setCustomOverrides] = useState<Record<string, { title: string; isWorkday: boolean; inTime?: string; outTime?: string; reason: string }>>({
    '2026-08-14': {
      title: 'Gladi Bersih HUT RI ke-81',
      isWorkday: true,
      inTime: '07:30',
      outTime: '15:30',
      reason: 'Penyesuaian jam kerja gladi resik upacara kemerdekaan'
    }
  });

  // Modal States
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [editingHoliday, setEditingHoliday] = useState<HolidayItem | null>(null);
  const [holidayFormData, setHolidayFormData] = useState({
    name: '',
    date: '',
    type: 'national' as 'national' | 'joint_leave' | 'local' | 'special',
    description: '',
    isPenaltyExempt: true
  });

  // Notification State
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Rule Simulator State
  const [simDate, setSimDate] = useState<string>('2026-08-10');
  const [simInTime, setSimInTime] = useState<string>('08:45');
  const [simOutTime, setSimOutTime] = useState<string>('16:30');
  const [simGracePeriod, setSimGracePeriod] = useState<number>(0);

  // Quick Sync SKB 3 Menteri
  const handleSyncSKB = () => {
    setHolidays(OFFICIAL_2026_HOLIDAYS);
    showNotification(`Berhasil menyinkronkan ${OFFICIAL_2026_HOLIDAYS.length} Hari Libur Nasional & Cuti Bersama SKB 3 Menteri Tahun 2026.`);
  };

  // Check holiday map for fast lookup
  const holidayMap = useMemo(() => {
    const map = new Map<string, HolidayItem>();
    holidays.forEach(h => map.set(h.date, h));
    return map;
  }, [holidays]);

  // Evaluator function for any given date
  const evaluateDay = (dateStr: string) => {
    const dateObj = new Date(dateStr + 'T00:00:00');
    const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 1 = Monday, ..., 5 = Friday, 6 = Saturday

    // 1. Check Custom Override
    if (customOverrides[dateStr]) {
      const ov = customOverrides[dateStr];
      return {
        date: dateStr,
        dayOfWeek,
        isWorkday: ov.isWorkday,
        statusType: ov.isWorkday ? 'special_workday' : 'special_holiday',
        title: ov.title,
        badgeText: ov.isWorkday ? 'Jam Khusus' : 'Libur Khusus',
        inTime: ov.inTime || '08:15',
        outTime: ov.outTime || '16:30',
        penaltyExempt: !ov.isWorkday,
        description: ov.reason
      };
    }

    // 2. Check Holiday (SKB 3 Menteri or Custom)
    if (holidayMap.has(dateStr)) {
      const h = holidayMap.get(dateStr)!;
      return {
        date: dateStr,
        dayOfWeek,
        isWorkday: false,
        statusType: h.type === 'joint_leave' ? 'joint_leave' : 'national_holiday',
        title: h.name,
        badgeText: h.type === 'joint_leave' ? 'Cuti Bersama' : 'Libur Nasional',
        inTime: '-',
        outTime: '-',
        penaltyExempt: h.isPenaltyExempt,
        description: h.description || (h.type === 'joint_leave' ? 'Cuti Bersama Resmi SKB 3 Menteri' : 'Hari Libur Nasional Resmi')
      };
    }

    // 3. Check Weekend (Saturday & Sunday)
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      return {
        date: dateStr,
        dayOfWeek,
        isWorkday: false,
        statusType: 'weekend',
        title: dayOfWeek === 6 ? 'Akhir Pekan (Sabtu)' : 'Akhir Pekan (Minggu)',
        badgeText: 'Akhir Pekan',
        inTime: '-',
        outTime: '-',
        penaltyExempt: true,
        description: 'Libur reguler akhir pekan'
      };
    }

    // 4. Check Ramadhan Schedule
    const isRamadhan = isRamadhanModeActive && dateStr >= ramadhanStartDate && dateStr <= ramadhanEndDate;
    if (isRamadhan) {
      const outT = dayOfWeek === 5 ? '15:30' : '15:00';
      return {
        date: dateStr,
        dayOfWeek,
        isWorkday: true,
        statusType: 'ramadhan',
        title: 'Hari Kerja Khusus Ramadhan',
        badgeText: 'Jam Ramadhan',
        inTime: '08:00',
        outTime: outT,
        penaltyExempt: false,
        description: `Jam kerja efisien bulan Ramadhan (Masuk 08:00 - Pulang ${outT} WIB)`
      };
    }

    // 5. Standard Workday (Mon-Thu: 08:15 - 16:30, Fri: 08:15 - 17:00)
    const isFriday = dayOfWeek === 5;
    return {
      date: dateStr,
      dayOfWeek,
      isWorkday: true,
      statusType: 'workday',
      title: isFriday ? 'Hari Kerja (Jumat)' : 'Hari Kerja Reguler',
      badgeText: 'Hari Kerja',
      inTime: '08:15',
      outTime: isFriday ? '17:00' : '16:30',
      penaltyExempt: false,
      description: isFriday 
        ? 'Jumat: Masuk 08:15 WIB, Pulang 17:00 WIB (Istirahat Sholat Jumat 11:30 - 13:00)' 
        : 'Senin - Kamis: Masuk 08:15 WIB, Pulang 16:30 WIB'
    };
  };

  // Inspect Currently Selected Date
  const selectedDateEval = useMemo(() => {
    return evaluateDay(selectedCalendarDate);
  }, [selectedCalendarDate, holidayMap, customOverrides, isRamadhanModeActive, ramadhanStartDate, ramadhanEndDate]);

  // Calendar Grid Data for Current Month
  const calendarGrid = useMemo(() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);

    const daysInMonth = lastDayOfMonth.getDate();
    // Monday as start of week (0=Mon ... 6=Sun)
    let startDayOfWeek = firstDayOfMonth.getDay() - 1;
    if (startDayOfWeek === -1) startDayOfWeek = 6;

    const days: Array<{
      dayNumber: number;
      dateStr: string;
      isCurrentMonth: boolean;
      evaluation: ReturnType<typeof evaluateDay>;
    }> = [];

    // Preceding padding days from previous month
    const prevMonthLastDay = new Date(currentYear, currentMonth, 0).getDate();
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
      const dNum = prevMonthLastDay - i;
      const prevDate = new Date(currentYear, currentMonth - 1, dNum);
      const dateStr = prevDate.toISOString().slice(0, 10);
      days.push({
        dayNumber: dNum,
        dateStr,
        isCurrentMonth: false,
        evaluation: evaluateDay(dateStr)
      });
    }

    // Days in current month
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({
        dayNumber: d,
        dateStr,
        isCurrentMonth: true,
        evaluation: evaluateDay(dateStr)
      });
    }

    // Trailing padding days to fill 35 or 42 grid cells
    const remainingCells = (7 - (days.length % 7)) % 7;
    for (let j = 1; j <= remainingCells; j++) {
      const nextDate = new Date(currentYear, currentMonth + 1, j);
      const dateStr = nextDate.toISOString().slice(0, 10);
      days.push({
        dayNumber: j,
        dateStr,
        isCurrentMonth: false,
        evaluation: evaluateDay(dateStr)
      });
    }

    return days;
  }, [currentYear, currentMonth, holidayMap, customOverrides, isRamadhanModeActive, ramadhanStartDate, ramadhanEndDate]);

  // Monthly summary stats
  const monthlyStats = useMemo(() => {
    const currentMonthDays = calendarGrid.filter(d => d.isCurrentMonth);
    let workdays = 0;
    let nationalHolidays = 0;
    let jointLeaves = 0;
    let weekends = 0;

    currentMonthDays.forEach(d => {
      const t = d.evaluation.statusType;
      if (d.evaluation.isWorkday) {
        workdays++;
      } else if (t === 'national_holiday') {
        nationalHolidays++;
      } else if (t === 'joint_leave') {
        jointLeaves++;
      } else if (t === 'weekend') {
        weekends++;
      } else {
        nationalHolidays++;
      }
    });

    return {
      totalDays: currentMonthDays.length,
      workdays,
      nationalHolidays,
      jointLeaves,
      weekends,
      totalOffDays: nationalHolidays + jointLeaves + weekends
    };
  }, [calendarGrid]);

  // Filtered Holidays Table
  const filteredHolidays = useMemo(() => {
    return holidays.filter(h => {
      const matchSearch = h.name.toLowerCase().includes(holidaySearch.toLowerCase()) ||
                          h.date.includes(holidaySearch);
      const matchType = holidayTypeFilter === '' || h.type === holidayTypeFilter;
      return matchSearch && matchType;
    }).sort((a, b) => a.date.localeCompare(b.date));
  }, [holidays, holidaySearch, holidayTypeFilter]);

  // Holiday CRUD Handlers
  const handleOpenAddHoliday = () => {
    setEditingHoliday(null);
    setHolidayFormData({
      name: '',
      date: selectedCalendarDate || `${currentYear}-01-01`,
      type: 'national',
      description: '',
      isPenaltyExempt: true
    });
    setIsHolidayModalOpen(true);
  };

  const handleOpenEditHoliday = (item: HolidayItem) => {
    setEditingHoliday(item);
    setHolidayFormData({
      name: item.name,
      date: item.date,
      type: item.type,
      description: item.description || '',
      isPenaltyExempt: item.isPenaltyExempt
    });
    setIsHolidayModalOpen(true);
  };

  const handleSaveHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!holidayFormData.name.trim() || !holidayFormData.date) {
      showNotification('Nama hari libur dan tanggal wajib diisi.', 'error');
      return;
    }

    if (editingHoliday) {
      setHolidays(prev =>
        prev.map(h => h.id === editingHoliday.id ? { ...h, ...holidayFormData } : h)
      );
      showNotification(`Hari libur '${holidayFormData.name}' berhasil diperbarui.`);
    } else {
      const newId = Date.now();
      const newItem: HolidayItem = {
        id: newId,
        ...holidayFormData
      };
      setHolidays(prev => [...prev, newItem]);
      showNotification(`Hari libur '${holidayFormData.name}' berhasil ditambahkan.`);
    }

    setIsHolidayModalOpen(false);
  };

  const handleDeleteHoliday = (id: number) => {
    const item = holidays.find(h => h.id === id);
    if (!item) return;
    setHolidays(prev => prev.filter(h => h.id !== id));
    showNotification(`Hari libur '${item.name}' telah dihapus dari kalender.`, 'info');
  };

  // Toggle Override for Current Date
  const handleToggleCurrentDateOverride = (makeHoliday: boolean) => {
    if (makeHoliday) {
      setCustomOverrides(prev => ({
        ...prev,
        [selectedCalendarDate]: {
          title: 'Hari Libur Khusus / Diliburkan Instansi',
          isWorkday: false,
          reason: 'Diliburkan sementara atas kebijakan pimpinan instansi'
        }
      }));
      showNotification(`Tanggal ${selectedCalendarDate} berhasil ditetapkan sebagai Libur Khusus (Denda Rp 0).`);
    } else {
      // Remove override
      setCustomOverrides(prev => {
        const copy = { ...prev };
        delete copy[selectedCalendarDate];
        return copy;
      });
      showNotification(`Penetapan khusus tanggal ${selectedCalendarDate} telah dikembalikan ke standar.`);
    }
  };

  // Rule Simulator Evaluator
  const simulationResult = useMemo(() => {
    const evalDay = evaluateDay(simDate);
    
    // If not a workday
    if (!evalDay.isWorkday) {
      return {
        status: evalDay.title.toUpperCase(),
        penalty: 0,
        lateMinutes: 0,
        earlyMinutes: 0,
        isExempt: true,
        reason: `${evalDay.title} adalah hari libur (Denda Rp 0 otomatis). Scan absensi pada hari ini tidak dikenakan sanksi denda.`
      };
    }

    // Parse Expected times
    const [expInH, expInM] = evalDay.inTime.split(':').map(Number);
    const [expOutH, expOutM] = evalDay.outTime.split(':').map(Number);
    const expInTotal = expInH * 60 + expInM;
    const expOutTotal = expOutH * 60 + expOutM;

    let lateMin = 0;
    let earlyMin = 0;
    let penalty = 0;
    const reasonParts: string[] = [];

    // Parse Scan In
    if (simInTime) {
      const [actInH, actInM] = simInTime.split(':').map(Number);
      const actInTotal = actInH * 60 + actInM;
      if (actInTotal > expInTotal + simGracePeriod) {
        lateMin = actInTotal - expInTotal;
        if (lateMin <= 60) {
          penalty += 7500;
          reasonParts.push(`Terlambat ${lateMin} menit (≤ 60 menit: Denda Rp 7.500)`);
        } else {
          penalty += 10000;
          reasonParts.push(`Terlambat ${lateMin} menit (> 60 menit: Denda Rp 10.000)`);
        }
      }
    } else {
      penalty += 10000;
      reasonParts.push('Tidak Scan Masuk (Missing In: Denda Rp 10.000)');
    }

    // Parse Scan Out
    if (simOutTime) {
      const [actOutH, actOutM] = simOutTime.split(':').map(Number);
      const actOutTotal = actOutH * 60 + actOutM;
      if (actOutTotal < expOutTotal) {
        earlyMin = expOutTotal - actOutTotal;
        penalty += 10000;
        reasonParts.push(`Pulang cepat ${earlyMin} menit sebelum ${evalDay.outTime} WIB (Denda Rp 10.000)`);
      }
    } else {
      penalty += 10000;
      reasonParts.push('Tidak Scan Pulang (Missing Out: Denda Rp 10.000)');
    }

    // Both missing
    if (!simInTime && !simOutTime) {
      penalty = 20000;
      reasonParts.length = 0;
      reasonParts.push('Tidak Hadir Hari Kerja / Missing Keduanya (Denda Rp 20.000)');
    }

    let statusText = 'HADIR TEPAT WAKTU';
    if (!simInTime && !simOutTime) statusText = 'TIDAK HADIR (ALPHA)';
    else if (lateMin > 0 && earlyMin > 0) statusText = 'TERLAMBAT & PULANG CEPAT';
    else if (lateMin > 0) statusText = lateMin <= 60 ? 'TERLAMBAT ≤ 1 JAM' : 'TERLAMBAT > 1 JAM';
    else if (earlyMin > 0) statusText = 'PULANG CEPAT';
    else if (!simInTime) statusText = 'TIDAK ABSEN MASUK';
    else if (!simOutTime) statusText = 'TIDAK ABSEN PULANG';

    return {
      status: statusText,
      penalty,
      lateMinutes: lateMin,
      earlyMinutes: earlyMin,
      isExempt: false,
      reason: reasonParts.length > 0 ? reasonParts.join(' + ') : 'Tepat waktu sesuai jam kerja yang berlaku'
    };
  }, [simDate, simInTime, simOutTime, simGracePeriod, holidayMap, customOverrides, isRamadhanModeActive, ramadhanStartDate, ramadhanEndDate]);

  // Handle month change
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(prev => prev - 1);
    } else {
      setCurrentMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(prev => prev + 1);
    } else {
      setCurrentMonth(prev => prev + 1);
    }
  };

  // Export calendar data
  const handleExportCalendar = () => {
    showNotification(`Mengunduh file: kalender_kerja_${currentYear}_${MONTH_NAMES[currentMonth]}.xlsx`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Toast Notification */}
      {notification && (
        <div className={`p-4 rounded-2xl flex items-center justify-between shadow-lg text-sm font-semibold transition-all border ${
          notification.type === 'success' ? 'bg-emerald-600 text-white border-emerald-500' :
          notification.type === 'error' ? 'bg-rose-600 text-white border-rose-500' :
          'bg-slate-900 text-white border-slate-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="p-1 hover:bg-white/20 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* HEADER SECTION */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-sky-100 text-sky-800 border border-sky-200">
              Phase 4 Aktif
            </span>
            <span className="text-xs font-semibold text-slate-500">
              Engine Kalender Kerja & Aturan Denda
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Kalender Kerja, Jadwal Jam & Libur Nasional
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-3xl">
            Menentukan hari kerja efektif, integrasi 25 hari libur & cuti bersama SKB 3 Menteri 2026, jadwal jam kerja normal vs Ramadhan, serta pengecualian denda Rp 0 pada hari libur.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {isOperator && (
            <>
              <button
                onClick={handleSyncSKB}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                title="Sinkronkan 25 Hari Libur Nasional & Cuti Bersama SKB 3 Menteri 2026"
              >
                <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                <span>Sync SKB 3 Menteri 2026</span>
              </button>

              <button
                onClick={handleOpenAddHoliday}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Hari Libur</span>
              </button>
            </>
          )}

          <button
            onClick={handleExportCalendar}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* SUB-TABS NAVIGATION */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('calendar')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors shrink-0 cursor-pointer ${
            activeTab === 'calendar'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <CalendarIcon className="w-4 h-4 text-emerald-400" />
          <span>Kalender Visual ({MONTH_NAMES[currentMonth]} {currentYear})</span>
        </button>

        <button
          onClick={() => setActiveTab('holidays')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors shrink-0 cursor-pointer ${
            activeTab === 'holidays'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <CalendarRange className="w-4 h-4 text-rose-400" />
          <span>Daftar Libur & Cuti Bersama ({holidays.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('schedules')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors shrink-0 cursor-pointer ${
            activeTab === 'schedules'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4 text-amber-400" />
          <span>Pola Jam Kerja & Ramadhan</span>
        </button>

        <button
          onClick={() => setActiveTab('simulator')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors shrink-0 cursor-pointer ${
            activeTab === 'simulator'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Play className="w-4 h-4 text-indigo-400" />
          <span>Simulator & Evaluator Aturan</span>
        </button>
      </div>

      {/* TAB 1: VISUAL CALENDAR VIEW & DATE INSPECTOR */}
      {activeTab === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left / Main: Visual Calendar Grid */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
            {/* Calendar Controls & Month Nav */}
            <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevMonth}
                  className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 transition-colors cursor-pointer"
                  title="Bulan Sebelumnya"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="font-extrabold text-base sm:text-lg text-slate-900 min-w-[180px] text-center">
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </div>
                <button
                  onClick={handleNextMonth}
                  className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 transition-colors cursor-pointer"
                  title="Bulan Berikutnya"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Quick Jump Buttons */}
              <div className="flex items-center gap-1.5 text-xs">
                <button
                  onClick={() => { setCurrentYear(2026); setCurrentMonth(7); setSelectedCalendarDate('2026-08-17'); }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 cursor-pointer"
                >
                  Agustus 2026 (HUT RI)
                </button>
                <button
                  onClick={() => { setCurrentYear(2026); setCurrentMonth(2); setSelectedCalendarDate('2026-03-21'); }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 cursor-pointer"
                >
                  Maret 2026 (Idul Fitri)
                </button>
                <button
                  onClick={() => { setCurrentYear(2026); setCurrentMonth(4); setSelectedCalendarDate('2026-05-01'); }}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 cursor-pointer"
                >
                  Mei 2026
                </button>
              </div>
            </div>

            {/* Monthly Stats Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-100/80">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 block">Hari Kerja Efektif</span>
                <span className="text-lg font-black text-emerald-950">{monthlyStats.workdays} Hari</span>
              </div>
              <div className="p-3 rounded-2xl bg-rose-50 border border-rose-100/80">
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-800 block">Libur Nasional</span>
                <span className="text-lg font-black text-rose-950">{monthlyStats.nationalHolidays} Hari</span>
              </div>
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-100/80">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 block">Cuti Bersama</span>
                <span className="text-lg font-black text-amber-950">{monthlyStats.jointLeaves} Hari</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200/80">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-700 block">Akhir Pekan</span>
                <span className="text-lg font-black text-slate-900">{monthlyStats.weekends} Hari</span>
              </div>
            </div>

            {/* Calendar Days of Week Header */}
            <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs text-slate-500 py-1 border-b border-slate-100">
              <div>Senin</div>
              <div>Selasa</div>
              <div>Rabu</div>
              <div>Kamis</div>
              <div className="text-indigo-600">Jumat</div>
              <div className="text-rose-500">Sabtu</div>
              <div className="text-rose-600">Minggu</div>
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {calendarGrid.map((cell, idx) => {
                const evalD = cell.evaluation;
                const isSelected = cell.dateStr === selectedCalendarDate;
                const isNationalHoliday = evalD.statusType === 'national_holiday';
                const isJointLeave = evalD.statusType === 'joint_leave';
                const isWeekend = evalD.statusType === 'weekend';
                const isSpecial = evalD.statusType.startsWith('special');
                const isWorkday = evalD.isWorkday;

                return (
                  <button
                    key={`${cell.dateStr}-${idx}`}
                    onClick={() => {
                      setSelectedCalendarDate(cell.dateStr);
                      if (onSelectDateForDashboard) onSelectDateForDashboard(cell.dateStr);
                    }}
                    className={`min-h-[78px] sm:min-h-[92px] p-2 rounded-2xl flex flex-col justify-between text-left transition-all relative border cursor-pointer ${
                      isSelected
                        ? 'ring-2 ring-emerald-500 shadow-md border-emerald-500 z-10'
                        : 'hover:border-slate-300'
                    } ${
                      !cell.isCurrentMonth
                        ? 'opacity-30 bg-slate-50 border-slate-100'
                        : isNationalHoliday
                        ? 'bg-rose-50/70 border-rose-200/90 text-rose-950'
                        : isJointLeave
                        ? 'bg-amber-50/70 border-amber-200/90 text-amber-950'
                        : isSpecial
                        ? 'bg-purple-50/70 border-purple-200 text-purple-950'
                        : isWeekend
                        ? 'bg-slate-50/90 border-slate-200/60 text-slate-500'
                        : 'bg-white border-slate-200/80 text-slate-800'
                    }`}
                  >
                    {/* Top Row: Date Number + Tag */}
                    <div className="flex items-center justify-between">
                      <span className={`text-xs sm:text-sm font-extrabold ${
                        isNationalHoliday || isWeekend ? 'text-rose-600' : 'text-slate-800'
                      }`}>
                        {cell.dayNumber}
                      </span>

                      {/* Small Indicator Pill */}
                      {isNationalHoliday && (
                        <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse" title="Libur Nasional"></span>
                      )}
                      {isJointLeave && (
                        <span className="w-2 h-2 rounded-full bg-amber-500" title="Cuti Bersama"></span>
                      )}
                    </div>

                    {/* Middle: Title or Work hours */}
                    <div className="space-y-0.5">
                      {isNationalHoliday || isJointLeave ? (
                        <p className="text-[10px] font-bold line-clamp-2 leading-tight text-rose-800">
                          {evalD.title}
                        </p>
                      ) : isSpecial ? (
                        <p className="text-[10px] font-bold line-clamp-2 leading-tight text-purple-800">
                          {evalD.title}
                        </p>
                      ) : isWorkday ? (
                        <div className="text-[10px] text-slate-500 font-mono">
                          <span>{evalD.inTime} - {evalD.outTime}</span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400">Libur</span>
                      )}
                    </div>

                    {/* Bottom Status Badge */}
                    <div className="pt-1">
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        isNationalHoliday
                          ? 'bg-rose-200/60 text-rose-800'
                          : isJointLeave
                          ? 'bg-amber-200/60 text-amber-800'
                          : isSpecial
                          ? 'bg-purple-200/60 text-purple-800'
                          : isWorkday
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200/60 text-slate-600'
                      }`}>
                        {evalD.badgeText}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Legend Footer */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 flex-wrap gap-2">
              <div className="flex items-center gap-3 flex-wrap">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-white border border-slate-300"></span>
                  <span>Hari Kerja Normal</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-rose-100 border border-rose-300"></span>
                  <span className="text-rose-700 font-medium">Libur Nasional</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-amber-100 border border-amber-300"></span>
                  <span className="text-amber-700 font-medium">Cuti Bersama</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded bg-slate-200"></span>
                  <span>Akhir Pekan</span>
                </span>
              </div>
              <span className="font-mono text-[10px] text-slate-400">Pilih tanggal untuk inspeksi detail</span>
            </div>
          </div>

          {/* Right: Date Inspector Panel */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <CalendarCheck className="w-5 h-5 text-emerald-600" />
                  <h3 className="font-bold text-sm text-slate-900">Inspeksi Status Tanggal</h3>
                </div>
                <span className="font-mono text-xs font-bold text-slate-500">
                  {selectedCalendarDate}
                </span>
              </div>

              {/* Status Card */}
              <div className={`p-4 rounded-2xl border space-y-2.5 ${
                selectedDateEval.isWorkday
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                  : selectedDateEval.statusType === 'national_holiday'
                  ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                  : selectedDateEval.statusType === 'joint_leave'
                  ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                    Status Hari
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                    selectedDateEval.isWorkday
                      ? 'bg-emerald-600 text-white'
                      : 'bg-rose-600 text-white'
                  }`}>
                    {selectedDateEval.isWorkday ? 'HARI KERJA EFEKTIF' : 'HARI LIBUR (DENDA RP 0)'}
                  </span>
                </div>

                <div>
                  <h4 className="font-black text-base leading-snug">{selectedDateEval.title}</h4>
                  <p className="text-xs text-slate-600 mt-0.5">{selectedDateEval.description}</p>
                </div>
              </div>

              {/* Schedule Parameters */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">Jam Masuk Standar:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedDateEval.isWorkday ? `${selectedDateEval.inTime} WIB` : 'Tidak Ada'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">Jam Pulang Minimal:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedDateEval.isWorkday ? `${selectedDateEval.outTime} WIB` : 'Tidak Ada'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">Toleransi Keterlambatan:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {selectedDateEval.isWorkday ? '0 Menit (Tepat Waktu)' : '-'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-500">Status Pembebasan Denda:</span>
                  <span className={`font-bold ${selectedDateEval.penaltyExempt ? 'text-emerald-600' : 'text-slate-800'}`}>
                    {selectedDateEval.penaltyExempt ? 'Bebas Denda (Denda Rp 0)' : 'Denda Normal Berlaku'}
                  </span>
                </div>
              </div>

              {/* Action Buttons for Date Override */}
              {isOperator && (
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Override Kebijakan Tanggal Ini:
                  </div>

                  {customOverrides[selectedCalendarDate] ? (
                    <button
                      onClick={() => handleToggleCurrentDateOverride(false)}
                      className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Kembalikan ke Jadwal Standar</span>
                    </button>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleToggleCurrentDateOverride(true)}
                        className="py-2 px-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Tetapkan Libur Khusus
                      </button>
                      <button
                        onClick={() => {
                          setSimDate(selectedCalendarDate);
                          setActiveTab('simulator');
                        }}
                        className="py-2 px-3 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer text-center"
                      >
                        Uji di Simulator &rarr;
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Use Date in Main Dashboard Button */}
              {onSelectDateForDashboard && (
                <button
                  onClick={() => {
                    onSelectDateForDashboard(selectedCalendarDate);
                    showNotification(`Tanggal absensi utama dialihkan ke ${selectedCalendarDate}`);
                  }}
                  className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>Gunakan Tanggal Ini di Rekap Harian</span>
                </button>
              )}
            </div>

            {/* SKB 3 Menteri Info Card */}
            <div className="bg-slate-900 text-white rounded-3xl p-5 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>SKB 3 Menteri 2026</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Pemerintah telah menetapkan <strong>25 hari libur</strong> di tahun 2026 (17 Hari Libur Nasional + 8 Hari Cuti Bersama). Seluruh tanggal ini otomatis membebaskan denda pegawai menjadi <strong>Rp 0</strong>.
              </p>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: DAFTAR HARI LIBUR & CUTI BERSAMA (TABLE VIEW) */}
      {activeTab === 'holidays' && (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Daftar Hari Libur Nasional & Cuti Bersama
              </h2>
              <p className="text-xs text-slate-500">
                Tersimpan dalam tabel database <code className="font-mono text-emerald-700 font-bold">holidays</code> dengan flag bebas denda.
              </p>
            </div>

            {/* Filter and Search */}
            <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari hari libur..."
                  value={holidaySearch}
                  onChange={e => setHolidaySearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <select
                value={holidayTypeFilter}
                onChange={e => setHolidayTypeFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              >
                <option value="">Semua Kategori</option>
                <option value="national">Libur Nasional</option>
                <option value="joint_leave">Cuti Bersama</option>
                <option value="special">Khusus Instansi</option>
              </select>

              {isOperator && (
                <button
                  onClick={handleOpenAddHoliday}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Libur</span>
                </button>
              )}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 w-12 text-center">No</th>
                  <th className="py-3 px-4 w-36">Tanggal</th>
                  <th className="py-3 px-4">Nama Hari Libur</th>
                  <th className="py-3 px-4 w-40">Kategori</th>
                  <th className="py-3 px-4 w-36 text-center">Status Denda</th>
                  <th className="py-3 px-4">Deskripsi / SKB</th>
                  {isOperator && <th className="py-3 px-4 w-24 text-center">Aksi</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredHolidays.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Tidak ada data hari libur yang cocok.
                    </td>
                  </tr>
                ) : (
                  filteredHolidays.map((item, idx) => {
                    const dateObj = new Date(item.date + 'T00:00:00');
                    const formattedDate = dateObj.toLocaleDateString('id-ID', {
                      weekday: 'long',
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    });

                    return (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 text-center font-mono text-xs text-slate-400">
                          {idx + 1}
                        </td>
                        <td className="py-3.5 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                          {item.date}
                          <div className="text-[11px] font-normal text-slate-500 font-sans">
                            {formattedDate.split(',')[0]}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-900">
                          {item.name}
                        </td>
                        <td className="py-3.5 px-4">
                          {item.type === 'national' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-full bg-rose-100 text-rose-800 border border-rose-200">
                              Libur Nasional
                            </span>
                          ) : item.type === 'joint_leave' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-full bg-amber-100 text-amber-800 border border-amber-200">
                              Cuti Bersama
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-full bg-purple-100 text-purple-800 border border-purple-200">
                              Khusus / Lokal
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          {item.isPenaltyExempt ? (
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              Denda Rp 0
                            </span>
                          ) : (
                            <span className="text-xs text-slate-400">Denda Normal</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500">
                          {item.description || '-'}
                        </td>
                        {isOperator && (
                          <td className="py-3.5 px-4 text-center">
                            <div className="inline-flex items-center gap-1">
                              <button
                                onClick={() => handleOpenEditHoliday(item)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors cursor-pointer"
                                title="Edit Hari Libur"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteHoliday(item.id)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Hapus Hari Libur"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: POLA JAM KERJA & PENGATURAN RAMADHAN */}
      {activeTab === 'schedules' && (
        <div className="space-y-6">
          {/* Ramadhan Mode Toggle Card */}
          <div className="bg-gradient-to-r from-sky-900 to-indigo-900 text-white rounded-3xl p-6 shadow-sm border border-sky-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1 max-w-2xl">
              <div className="flex items-center gap-2 text-sky-300 text-xs font-bold uppercase tracking-wider">
                <Moon className="w-4 h-4" />
                <span>Pengaturan Khusus Bulan Ramadhan (Bulan Puasa)</span>
              </div>
              <h3 className="text-lg font-bold">Jam Kerja Khusus Ramadhan</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Ketika aktif, jam kerja otomatis disesuaikan (Senin - Kamis: 08:00 s.d. 15:00 WIB, Jumat: 08:00 s.d. 15:30 WIB) untuk seluruh pegawai sesuai Surat Edaran MenPAN-RB.
              </p>
              
              {isRamadhanModeActive && (
                <div className="pt-2 flex items-center gap-3 text-xs">
                  <span>Periode Aktif:</span>
                  <span className="font-mono font-bold bg-white/20 px-2 py-0.5 rounded">
                    {ramadhanStartDate} s.d. {ramadhanEndDate}
                  </span>
                </div>
              )}
            </div>

            {isOperator && (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setIsRamadhanModeActive(!isRamadhanModeActive);
                    showNotification(`Mode Jam Kerja Ramadhan berhasil di${!isRamadhanModeActive ? 'aktifkan' : 'nonaktifkan'}.`);
                  }}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-2 ${
                    isRamadhanModeActive
                      ? 'bg-rose-500 hover:bg-rose-600 text-white'
                      : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black'
                  }`}
                >
                  <Sun className="w-4 h-4" />
                  <span>{isRamadhanModeActive ? 'Nonaktifkan Ramadhan' : 'Aktifkan Mode Ramadhan'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Standard Schedules Table */}
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">Jadwal Jam Kerja Reguler ASN & Pegawai (5 Hari Kerja)</h3>
                <p className="text-xs text-slate-500">Pola jam kerja standar instansi pemerintah pusat dan daerah.</p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                Pola 5 Hari Kerja
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-2xl">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4 w-28">Hari</th>
                    <th className="py-3 px-4 w-28 text-center">Status</th>
                    <th className="py-3 px-4 w-32">Jam Masuk</th>
                    <th className="py-3 px-4 w-32">Jam Pulang</th>
                    <th className="py-3 px-4 w-36">Toleransi</th>
                    <th className="py-3 px-4 w-36">Jam Istirahat</th>
                    <th className="py-3 px-4">Keterangan Khusus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {schedules.map((sc) => (
                    <tr key={sc.id} className={`hover:bg-slate-50/80 transition-colors ${!sc.isWorkday ? 'bg-slate-50/50 text-slate-400' : ''}`}>
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {sc.dayName}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {sc.isWorkday ? (
                          <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800">
                            Hari Kerja
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-slate-100 text-slate-500">
                            Libur
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                        {sc.isWorkday ? `${sc.inTime} WIB` : '-'}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                        {sc.isWorkday ? `${sc.outTime} WIB` : '-'}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono text-slate-600">
                        {sc.isWorkday ? `${sc.gracePeriodMinutes} Menit` : '-'}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono text-slate-600">
                        {sc.breakTime}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">
                        {sc.notes}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RULE SIMULATOR & DATE EVALUATOR */}
      {activeTab === 'simulator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Simulator Inputs */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="space-y-1 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider">
                <Sliders className="w-4 h-4" />
                <span>Simulator Kalkulasi Denda Absensi</span>
              </div>
              <h3 className="text-base font-bold text-slate-900">Uji Coba Skenario Tanggal & Jam</h3>
              <p className="text-xs text-slate-500">
                Pilih tanggal apa saja (hari kerja normal, libur 17 Agustus, Jumat, atau akhir pekan) dan lihat bagaimana engine absensi menghitung denda keterlambatan / potongan.
              </p>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pilih Tanggal Simulasi:</label>
                <input
                  type="date"
                  value={simDate}
                  onChange={e => setSimDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              {/* Quick Preset Date Buttons */}
              <div className="flex items-center gap-1.5 flex-wrap text-[11px]">
                <span className="text-slate-400">Preset:</span>
                <button
                  onClick={() => { setSimDate('2026-08-17'); setSimInTime(''); setSimOutTime(''); }}
                  className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold rounded-lg cursor-pointer"
                >
                  17 Ags (Libur Nasional)
                </button>
                <button
                  onClick={() => { setSimDate('2026-08-10'); setSimInTime('08:45'); setSimOutTime('16:30'); }}
                  className="px-2 py-0.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-bold rounded-lg cursor-pointer"
                >
                  Senin (Telat 30 Menit)
                </button>
                <button
                  onClick={() => { setSimDate('2026-08-14'); setSimInTime('08:10'); setSimOutTime('16:30'); }}
                  className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold rounded-lg cursor-pointer"
                >
                  Jumat (Pulang Cepat)
                </button>
                <button
                  onClick={() => { setSimDate('2026-08-10'); setSimInTime(''); setSimOutTime(''); }}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg cursor-pointer"
                >
                  Hari Kerja (Alpha)
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Scan Masuk (WIB):</label>
                  <input
                    type="time"
                    value={simInTime}
                    onChange={e => setSimInTime(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Kosongkan jika Missing In</span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Scan Pulang (WIB):</label>
                  <input
                    type="time"
                    value={simOutTime}
                    onChange={e => setSimOutTime(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Kosongkan jika Missing Out</span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Toleransi Keterlambatan (Menit):</label>
                <select
                  value={simGracePeriod}
                  onChange={e => setSimGracePeriod(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value={0}>0 Menit (Tepat Waktu Ketat - Standar ASN)</option>
                  <option value={15}>15 Menit (Grace Period Standar Swasta)</option>
                  <option value={30}>30 Menit (Toleransi Cuaca Ekstrem)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Simulation Output Card */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-sm text-slate-900">Hasil Evaluasi Engine Absensi</h3>
              <span className="text-xs font-mono text-emerald-700 font-bold">
                Tanggal: {simDate}
              </span>
            </div>

            {/* Status Highlight Banner */}
            <div className={`p-5 rounded-2xl border space-y-3 ${
              simulationResult.penalty === 0
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : simulationResult.penalty <= 7500
                ? 'bg-amber-50 border-amber-200 text-amber-950'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider">
                  Status Kehadiran Dihitung:
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-black ${
                  simulationResult.penalty === 0
                    ? 'bg-emerald-600 text-white'
                    : 'bg-rose-600 text-white'
                }`}>
                  {simulationResult.status}
                </span>
              </div>

              <div className="flex items-baseline justify-between pt-1 border-t border-current/10">
                <span className="text-xs font-semibold">Total Denda / Potongan:</span>
                <span className="text-2xl sm:text-3xl font-black font-mono">
                  Rp {simulationResult.penalty.toLocaleString('id-ID')}
                </span>
              </div>

              <p className="text-xs leading-relaxed opacity-90">
                {simulationResult.reason}
              </p>
            </div>

            {/* Metrics Breakdown */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
                <span className="text-slate-500 font-medium">Keterlambatan (Menit):</span>
                <div className="text-lg font-mono font-bold text-slate-900">
                  {simulationResult.lateMinutes} Menit
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
                <span className="text-slate-500 font-medium">Pulang Cepat (Menit):</span>
                <div className="text-lg font-mono font-bold text-slate-900">
                  {simulationResult.earlyMinutes} Menit
                </div>
              </div>
            </div>

            {/* Explanation Note */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-1">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                Ketentuan Aturan Denda (Tabel <code className="font-mono text-emerald-700">settings</code>):
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-500 pt-1">
                <li>Hari Libur Nasional / Cuti Bersama: Denda otomatis <strong>Rp 0</strong>.</li>
                <li>Terlambat &le; 60 menit: Denda Rp 7.500.</li>
                <li>Terlambat &gt; 60 menit: Denda Rp 10.000.</li>
                <li>Pulang Cepat atau Missing In / Out: Denda Rp 10.000 per pelanggaran.</li>
                <li>Tidak hadir tanpa keterangan (Alpha): Denda Rp 20.000.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TAMBAH / EDIT HARI LIBUR */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">
                {editingHoliday ? 'Edit Hari Libur' : 'Tambah Hari Libur / Cuti Baru'}
              </h3>
              <button
                onClick={() => setIsHolidayModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveHoliday} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Libur:</label>
                <input
                  type="date"
                  required
                  value={holidayFormData.date}
                  onChange={e => setHolidayFormData({ ...holidayFormData, date: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl font-mono font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Hari Libur:</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: HUT Kemerdekaan RI ke-81"
                  value={holidayFormData.name}
                  onChange={e => setHolidayFormData({ ...holidayFormData, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Kategori Libur:</label>
                  <select
                    value={holidayFormData.type}
                    onChange={e => setHolidayFormData({ ...holidayFormData, type: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    <option value="national">Libur Nasional</option>
                    <option value="joint_leave">Cuti Bersama</option>
                    <option value="local">Libur Daerah</option>
                    <option value="special">Khusus Instansi / Pilkada</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status Denda:</label>
                  <select
                    value={holidayFormData.isPenaltyExempt ? '1' : '0'}
                    onChange={e => setHolidayFormData({ ...holidayFormData, isPenaltyExempt: e.target.value === '1' })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    <option value="1">Bebas Denda (Denda Rp 0)</option>
                    <option value="0">Dikenakan Denda Normal</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Keterangan / Dasar Hukum:</label>
                <textarea
                  rows={3}
                  placeholder="Contoh: SKB 3 Menteri No. 123 Tahun 2025 / Surat Edaran Kepala Daerah"
                  value={holidayFormData.description}
                  onChange={e => setHolidayFormData({ ...holidayFormData, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsHolidayModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Simpan Hari Libur
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
