import React, { useState, useMemo, useEffect } from 'react';
import {
  Cpu,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Clock,
  ShieldCheck,
  Lock,
  Unlock,
  Filter,
  Search,
  Download,
  Terminal,
  Layers,
  ChevronRight,
  TrendingDown,
  Info,
  Calendar,
  Check,
  Edit3,
  X,
  FileSpreadsheet,
  ArrowRight,
  Users
} from 'lucide-react';
import { EmployeeDailyRecord } from '../data/mockData';
import { getStoredEmployees } from '../data/participantStore';

interface ReconciliationResultItem extends EmployeeDailyRecord {
  isLocked: boolean;
  rawPunchesCount: number;
  expectedIn: string;
  expectedOut: string;
  penaltyBreakdown: string[];
  anomalies?: string[];
  isOverridden?: boolean;
  overrideNote?: string;
}

interface ReconciliationEngineModuleProps {
  userRole: 'admin' | 'operator' | 'viewer';
  currentSelectedDate: string;
  onNavigateToReports?: () => void;
  onSelectDateChange?: (date: string) => void;
}

export const ReconciliationEngineModule: React.FC<ReconciliationEngineModuleProps> = ({
  userRole,
  currentSelectedDate,
  onNavigateToReports,
  onSelectDateChange
}) => {
  const isOperator = userRole === 'admin' || userRole === 'operator';

  // Config State
  const [reconcileDate, setReconcileDate] = useState<string>(currentSelectedDate || '2026-08-10');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [isDryRun, setIsDryRun] = useState<boolean>(false);
  const [isLockedDate, setIsLockedDate] = useState<boolean>(false);

  // Execution & Progress State
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(100);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    `[INFO] Engine siap. Siap memproses log absensi mentah tanggal ${currentSelectedDate || '2026-08-10'}.`,
    `[INFO] Aturan denda aktif: Telat <=60m: Rp 7.500 | >60m: Rp 10.000 | Pulang Cepat: Rp 10.000 | Missing: Rp 10.000 | Alpha: Rp 20.000.`
  ]);

  // Reconciled Records State initialized from stored participants
  const [records, setRecords] = useState<ReconciliationResultItem[]>(() => {
    const stored = getStoredEmployees();
    if (!stored || stored.length === 0) return [];
    return stored.map((e) => ({
      id: e.id,
      code: e.employee_code,
      nip: e.nip || '-',
      name: e.name,
      department: e.department,
      firstIn: null,
      lastOut: null,
      status: 'BELUM SCAN',
      lateMinutes: 0,
      earlyMinutes: 0,
      penalty: 0,
      statusType: 'ontime' as const,
      isLocked: false,
      rawPunchesCount: 0,
      expectedIn: '08:15',
      expectedOut: '16:30',
      penaltyBreakdown: ['Belum ada log absensi']
    }));
  });

  useEffect(() => {
    const handleUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setRecords(e.detail.map((emp: any) => ({
          id: emp.id,
          code: emp.employee_code,
          nip: emp.nip || '-',
          name: emp.name,
          department: emp.department,
          firstIn: null,
          lastOut: null,
          status: 'BELUM SCAN',
          lateMinutes: 0,
          earlyMinutes: 0,
          penalty: 0,
          statusType: 'ontime' as const,
          isLocked: false,
          rawPunchesCount: 0,
          expectedIn: '08:15',
          expectedOut: '16:30',
          penaltyBreakdown: ['Belum ada log absensi']
        })));
      }
    };
    window.addEventListener('participants_updated', handleUpdated);
    return () => window.removeEventListener('participants_updated', handleUpdated);
  }, []);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Override Modal State
  const [overrideTarget, setOverrideTarget] = useState<ReconciliationResultItem | null>(null);
  const [overrideReason, setOverrideReason] = useState<string>('');
  const [overrideNewPenalty, setOverrideNewPenalty] = useState<number>(0);
  const [overrideNewStatus, setOverrideNewStatus] = useState<string>('HADIR TEPAT WAKTU');

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Check if date is national holiday (August 17, 2026 test)
  const isHolidayDate = reconcileDate === '2026-08-17';

  // Run Reconciliation Simulation
  const handleExecuteReconciliation = () => {
    if (isLockedDate) {
      showToast('Rekap tanggal ini telah dikunci (Locked). Buka kunci terlebih dahulu untuk memproses ulang.');
      return;
    }

    setIsRunning(true);
    setProgressPercent(10);
    setConsoleLogs([
      `[${new Date().toLocaleTimeString()}] Memulai rekonsiliasi absensi untuk tanggal ${reconcileDate}...`,
      `[${new Date().toLocaleTimeString()}] Mengevaluasi status kalender kerja & hari libur nasional...`
    ]);

    setTimeout(() => {
      setProgressPercent(35);
      if (isHolidayDate) {
        setConsoleLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] TERDETEKSI: 17 Agustus 2026 adalah Hari Proklamasi Kemerdekaan RI (Libur Nasional SKB 3 Menteri).`,
          `[${new Date().toLocaleTimeString()}] Aturan diterapkan: Pembebasan Denda Otomatis (Rp 0) untuk seluruh pegawai.`
        ]);
      } else {
        setConsoleLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] Status hari: Hari Kerja Normal (Jadwal: 08:15 - 16:30 WIB). Toleransi keterlambatan: 0 menit.`,
          `[${new Date().toLocaleTimeString()}] Mengekstrak log mentah dari tabel raw_attendance_logs...`
        ]);
      }
    }, 400);

    setTimeout(() => {
      setProgressPercent(70);
      setConsoleLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Mengelompokkan log scan per pegawai (NIP & Device PIN)...`,
        `[${new Date().toLocaleTimeString()}] Menghitung selisih jam masuk & jam pulang terhadap batas jadwal...`,
        `[${new Date().toLocaleTimeString()}] Menerapkan aturan denda berjenjang: Telat <=60m, Telat >60m, Pulang Cepat, Missing Scans, Alpha.`
      ]);
    }, 900);

    setTimeout(() => {
      setProgressPercent(100);
      setIsRunning(false);

      if (isHolidayDate) {
        // All penalties zeroed out for holiday
        setRecords(prev =>
          prev.map(r => ({
            ...r,
            penalty: 0,
            status: 'LIBUR NASIONAL (HUT RI)',
            statusType: 'holiday',
            penaltyBreakdown: ['Hari Libur Nasional SKB 3 Menteri (Denda Rp 0 otomatis)']
          }))
        );
        setConsoleLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] SUCCESS: 8 pegawai diproses. Seluruh denda menjadi Rp 0 karena Libur Nasional.`,
          `[${new Date().toLocaleTimeString()}] ${isDryRun ? 'DRY RUN SELESAI: Tidak ada perubahan yang disimpan ke DB.' : 'DATABASE COMMITTED: Tabel daily_attendance_summaries telah diperbarui.'}`
        ]);
        showToast('Rekonsiliasi Libur Nasional selesai! Seluruh denda berhasil dinolkan (Rp 0).');
      } else {
        // Regular calculation
        setConsoleLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] SUCCESS: 8 pegawai diproses. 6 pelanggaran terdeteksi. Total denda: Rp 77.500.`,
          `[${new Date().toLocaleTimeString()}] ${isDryRun ? 'DRY RUN SELESAI: Tidak ada perubahan yang disimpan ke DB.' : 'DATABASE COMMITTED: daily_attendance_summaries & attendance_penalties tersimpan.'}`
        ]);
        showToast(isDryRun ? 'Simulasi Rekonsiliasi (Dry Run) Selesai.' : 'Rekonsiliasi Absensi Berhasil Disimpan ke Database!');
      }

      if (onSelectDateChange) {
        onSelectDateChange(reconcileDate);
      }
    }, 1500);
  };

  // Toggle Lock
  const handleToggleLock = () => {
    const nextState = !isLockedDate;
    setIsLockedDate(nextState);
    setRecords(prev => prev.map(r => ({ ...r, isLocked: nextState })));
    showToast(nextState ? `Rekap tanggal ${reconcileDate} berhasil dikunci (Locked).` : `Kunci rekap tanggal ${reconcileDate} telah dibuka (Unlocked).`);
    setConsoleLogs(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] AUDIT: Operator mengubah status tanggal ${reconcileDate} menjadi ${nextState ? 'LOCKED' : 'UNLOCKED'}.`
    ]);
  };

  // Open Override Modal
  const handleOpenOverride = (item: ReconciliationResultItem) => {
    setOverrideTarget(item);
    setOverrideReason(item.overrideNote || 'Tugas dinas luar mendadak dengan surat tugas resmi');
    setOverrideNewPenalty(0);
    setOverrideNewStatus('HADIR TEPAT WAKTU');
  };

  // Save Override
  const handleSaveOverride = (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideTarget) return;

    setRecords(prev =>
      prev.map(r => {
        if (r.id === overrideTarget.id) {
          return {
            ...r,
            status: overrideNewStatus,
            penalty: overrideNewPenalty,
            isOverridden: true,
            overrideNote: overrideReason,
            penaltyBreakdown: [`Override Disetujui: ${overrideReason} (Denda disesuaikan menjadi Rp ${overrideNewPenalty.toLocaleString('id-ID')})`]
          };
        }
        return r;
      })
    );

    setConsoleLogs(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] AUDIT OVERRIDE: ${overrideTarget.name} status diubah ke '${overrideNewStatus}', denda disesuaikan: Rp ${overrideNewPenalty} (${overrideReason}).`
    ]);

    showToast(`Override untuk ${overrideTarget.name} berhasil disimpan.`);
    setOverrideTarget(null);
  };

  // Filtered List
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      const matchSearch =
        r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.nip.includes(searchQuery) ||
        r.code.toLowerCase().includes(searchQuery.toLowerCase());

      const matchDept = departmentFilter === 'ALL' || r.department === departmentFilter;

      const matchStatus =
        statusFilter === 'ALL' ||
        (statusFilter === 'PENALTY' && r.penalty > 0) ||
        (statusFilter === 'CLEAN' && r.penalty === 0) ||
        (statusFilter === 'ALPHA' && r.statusType === 'absent');

      return matchSearch && matchDept && matchStatus;
    });
  }, [records, searchQuery, departmentFilter, statusFilter]);

  // Aggregate Metrics
  const summaryMetrics = useMemo(() => {
    let totalPenalty = 0;
    let totalLate = 0;
    let totalEarly = 0;
    let totalAlpha = 0;
    let onTimeCount = 0;

    records.forEach(r => {
      totalPenalty += r.penalty;
      totalLate += r.lateMinutes;
      totalEarly += r.earlyMinutes;
      if (r.statusType === 'absent') totalAlpha++;
      if (r.penalty === 0 && r.statusType !== 'holiday') onTimeCount++;
    });

    return {
      totalEmployees: records.length,
      totalPenalty,
      totalLate,
      totalEarly,
      totalAlpha,
      onTimeCount,
      disciplineRate: Math.round((onTimeCount / records.length) * 100)
    };
  }, [records]);

  // Available Departments
  const departments = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => set.add(r.department));
    return Array.from(set);
  }, [records]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Toast */}
      {toastMessage && (
        <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-xl flex items-center justify-between text-sm font-semibold border border-slate-800">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="p-1 hover:bg-white/20 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* HEADER BAR */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-200">
              Phase 6 Aktif
            </span>
            <span className="text-xs font-semibold text-slate-500">
              Engine Rekonsiliasi & Denda Absensi Otomatis
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
            Engine Rekonsiliasi Harian & Potongan Denda
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-3xl">
            Memproses ribuan log mentah mesin absensi menjadi rekapan kehadiran definitif, mengeksekusi aturan denda berjenjang, dan membebaskan denda Rp 0 pada libur nasional.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {isOperator && (
            <button
              onClick={handleToggleLock}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer border ${
                isLockedDate
                  ? 'bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
              }`}
            >
              {isLockedDate ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              <span>{isLockedDate ? 'Rekap Terkunci (Locked)' : 'Kunci Rekap (Lock)'}</span>
            </button>
          )}

          {onNavigateToReports && (
            <button
              onClick={onNavigateToReports}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Lihat Rekap Bulanan & Slip &rarr;</span>
            </button>
          )}
        </div>
      </div>

      {/* RECONCILIATION RUNNER CONTROL CARD */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-600" />
            <h2 className="font-extrabold text-sm sm:text-base text-slate-900">
              Konfigurasi Eksekusi Rekonsiliasi
            </h2>
          </div>
          {isHolidayDate && (
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200 animate-pulse">
              Hari Libur Nasional: Denda Otomatis Rp 0
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Date Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Pilih Tanggal Rekonsiliasi:
            </label>
            <input
              type="date"
              value={reconcileDate}
              onChange={e => setReconcileDate(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono font-semibold border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
            <div className="flex items-center gap-1.5 mt-1.5">
              <button
                type="button"
                onClick={() => setReconcileDate('2026-08-10')}
                className="text-[10px] text-indigo-600 hover:underline cursor-pointer"
              >
                10 Agt (Kerja)
              </button>
              <span className="text-slate-300">•</span>
              <button
                type="button"
                onClick={() => setReconcileDate('2026-08-17')}
                className="text-[10px] text-rose-600 font-semibold hover:underline cursor-pointer"
              >
                17 Agt (HUT RI Libur)
              </button>
            </div>
          </div>

          {/* Department Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Filter Unit Kerja / SKPD:
            </label>
            <select
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            >
              <option value="ALL">Semua Unit Kerja (Seluruh Pegawai)</option>
              {departments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Dapat dijalankan per instansi atau massal.
            </span>
          </div>

          {/* Mode Option */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Mode Eksekusi:
            </label>
            <label className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer hover:bg-slate-100">
              <input
                type="checkbox"
                checked={isDryRun}
                onChange={e => setIsDryRun(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
              />
              <span className="text-xs font-semibold text-slate-800">
                Dry Run (Simulasi Saja)
              </span>
            </label>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Jika aktif, kalkulasi dilakukan tanpa commit ke database.
            </span>
          </div>

          {/* Run Button */}
          <div className="flex flex-col justify-end">
            <button
              onClick={handleExecuteReconciliation}
              disabled={isRunning || (isLockedDate && !isDryRun)}
              className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer ${
                isRunning
                  ? 'bg-slate-400 cursor-not-allowed'
                  : isLockedDate && !isDryRun
                  ? 'bg-slate-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98]'
              }`}
            >
              {isRunning ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Memproses Rekonsiliasi...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Jalankan Rekonsiliasi</span>
                </>
              )}
            </button>
            {isLockedDate && (
              <span className="text-[10px] text-rose-600 font-semibold mt-1 text-center">
                Rekap Terkunci. Buka gembok untuk proses ulang.
              </span>
            )}
          </div>

        </div>

        {/* Progress Bar & Real-time Console */}
        <div className="pt-2">
          <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-1.5 transition-all duration-300 ${
                progressPercent === 100 ? 'bg-emerald-500' : 'bg-indigo-600'
              }`}
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
        </div>

        {/* Streaming Logs Terminal Viewer */}
        <div className="rounded-2xl bg-slate-950 text-slate-300 p-3.5 font-mono text-[11px] leading-relaxed border border-slate-800 space-y-1 max-h-36 overflow-y-auto">
          <div className="flex items-center justify-between text-slate-500 pb-1 border-b border-slate-800 text-[10px]">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span>Console Log Engine Rekonsiliasi</span>
            </span>
            <span>CLI equivalent: php artisan attendance:reconcile --date={reconcileDate}</span>
          </div>
          {consoleLogs.map((log, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-emerald-500 shrink-0">&gt;</span>
              <span className={log.includes('SUCCESS') ? 'text-emerald-400 font-bold' : log.includes('TERDETEKSI') ? 'text-rose-300' : 'text-slate-300'}>
                {log}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* AGGREGATE SUMMARY STATS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Total Pegawai</span>
          <span className="text-xl font-black text-slate-900">{summaryMetrics.totalEmployees} Orang</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Tepat Waktu</span>
          <span className="text-xl font-black text-emerald-600">{summaryMetrics.onTimeCount} Orang</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Total Keterlambatan</span>
          <span className="text-xl font-black text-amber-600">{summaryMetrics.totalLate} Menit</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Pulang Cepat</span>
          <span className="text-xl font-black text-orange-600">{summaryMetrics.totalEarly} Menit</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Alpha (Tanpa Ket.)</span>
          <span className="text-xl font-black text-rose-600">{summaryMetrics.totalAlpha} Orang</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-rose-200 bg-rose-50/40 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider block">Total Denda Terkumpul</span>
          <span className="text-xl font-black text-rose-900">
            Rp {summaryMetrics.totalPenalty.toLocaleString('id-ID')}
          </span>
        </div>
      </div>

      {/* FILTER & DATA TABLE */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Hasil Rekonsiliasi Harian Definitif ({reconcileDate})
            </h2>
            <p className="text-xs text-slate-500">
              Data tersimpan di tabel <code className="font-mono text-indigo-700 font-bold">daily_attendance_summaries</code> dan <code className="font-mono text-indigo-700 font-bold">attendance_penalties</code>.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
            {/* Search */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama, NIP, atau kode..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            >
              <option value="ALL">Semua Status</option>
              <option value="PENALTY">Ada Denda Potongan</option>
              <option value="CLEAN">Bebas Denda (Rp 0)</option>
              <option value="ALPHA">Alpha Saja</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-2xl">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Pegawai</th>
                <th className="py-3 px-3">Unit Kerja</th>
                <th className="py-3 px-3 text-center">Scan Masuk</th>
                <th className="py-3 px-3 text-center">Scan Pulang</th>
                <th className="py-3 px-3 text-center">Keterlambatan</th>
                <th className="py-3 px-3">Status Evaluasi</th>
                <th className="py-3 px-4 text-right">Potongan Denda</th>
                <th className="py-3 px-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                    <div className="max-w-sm mx-auto space-y-2">
                      <Users className="w-10 h-10 mx-auto text-slate-300" />
                      <p className="font-semibold text-slate-700">
                        {records.length === 0 ? 'Data Peserta Belum Ada' : 'Tidak ada data pegawai yang sesuai filter'}
                      </p>
                      <p className="text-xs text-slate-400">
                        {records.length === 0
                          ? 'Peserta dummy telah dihapus. Silakan unggah peserta di menu Manajemen Pegawai.'
                          : 'Coba sesuaikan kata kunci pencarian atau filter status Anda.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((item) => {
                  const isOntime = item.statusType === 'ontime' || item.penalty === 0;
                  const isAlpha = item.statusType === 'absent';
                  const isHoliday = item.statusType === 'holiday';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Name & NIP */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{item.name}</div>
                        <div className="font-mono text-[11px] text-slate-500">
                          NIP: {item.nip}
                        </div>
                        {item.isOverridden && (
                          <span className="inline-block mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800">
                            Disetujui Override
                          </span>
                        )}
                      </td>

                      {/* Department */}
                      <td className="py-3 px-3 text-slate-600 text-xs">
                        {item.department}
                      </td>

                      {/* Scan In */}
                      <td className="py-3 px-3 text-center font-mono">
                        {item.firstIn ? (
                          <span className="px-2 py-1 rounded-md bg-slate-100 text-slate-800 font-semibold text-xs">
                            {item.firstIn}
                          </span>
                        ) : (
                          <span className="text-rose-500 font-bold text-xs bg-rose-50 px-2 py-0.5 rounded">
                            MISSING
                          </span>
                        )}
                      </td>

                      {/* Scan Out */}
                      <td className="py-3 px-3 text-center font-mono">
                        {item.lastOut ? (
                          <span className="px-2 py-1 rounded-md bg-slate-100 text-slate-800 font-semibold text-xs">
                            {item.lastOut}
                          </span>
                        ) : (
                          <span className="text-rose-500 font-bold text-xs bg-rose-50 px-2 py-0.5 rounded">
                            MISSING
                          </span>
                        )}
                      </td>

                      {/* Late / Early duration */}
                      <td className="py-3 px-3 text-center text-xs">
                        {item.lateMinutes > 0 ? (
                          <span className="text-amber-700 font-bold">
                            +{item.lateMinutes} mnt
                          </span>
                        ) : item.earlyMinutes > 0 ? (
                          <span className="text-orange-700 font-bold">
                            -{item.earlyMinutes} mnt
                          </span>
                        ) : (
                          <span className="text-slate-400">0 mnt</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold tracking-tight ${
                          isHoliday
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : isOntime
                            ? 'bg-emerald-100 text-emerald-800'
                            : isAlpha
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {item.status}
                        </span>
                        {item.penaltyBreakdown && item.penaltyBreakdown.length > 0 && (
                          <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1" title={item.penaltyBreakdown.join(' | ')}>
                            {item.penaltyBreakdown[0]}
                          </div>
                        )}
                      </td>

                      {/* Penalty Amount */}
                      <td className="py-3 px-4 text-right font-mono font-bold">
                        {item.penalty > 0 ? (
                          <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
                            Rp {item.penalty.toLocaleString('id-ID')}
                          </span>
                        ) : (
                          <span className="text-emerald-700 font-semibold">
                            Rp 0
                          </span>
                        )}
                      </td>

                      {/* Action */}
                      <td className="py-3 px-3 text-center">
                        {isOperator ? (
                          <button
                            onClick={() => handleOpenOverride(item)}
                            className="p-1.5 hover:bg-slate-100 text-slate-600 hover:text-indigo-600 rounded-lg transition-colors cursor-pointer"
                            title="Koreksi / Manual Override"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* OVERRIDE MODAL */}
      {overrideTarget && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Koreksi Manual & Override Rekonsiliasi
                </h3>
                <p className="text-xs text-slate-500">
                  {overrideTarget.name} ({overrideTarget.nip})
                </p>
              </div>
              <button
                onClick={() => setOverrideTarget(null)}
                className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveOverride} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Status Kehadiran Baru:
                </label>
                <select
                  value={overrideNewStatus}
                  onChange={e => setOverrideNewStatus(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="HADIR TEPAT WAKTU">HADIR TEPAT WAKTU (Dinas / Dispensasi)</option>
                  <option value="DINAS LUAR KOTA">DINAS LUAR KOTA (Surat Tugas Resmi)</option>
                  <option value="IZIN / CUTI RESMI">IZIN / CUTI RESMI</option>
                  <option value="TERLAMBAT <= 1 JAM">TERLAMBAT &le; 1 JAM (Rp 7.500)</option>
                  <option value="TERLAMBAT > 1 JAM">TERLAMBAT &gt; 1 JAM (Rp 10.000)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nominal Denda Disesuaikan (Rp):
                </label>
                <input
                  type="number"
                  step="500"
                  value={overrideNewPenalty}
                  onChange={e => setOverrideNewPenalty(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono font-bold border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Set ke 0 untuk membebaskan denda akibat tugas kedinasan.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Alasan Disposisi / Dasar Kebijakan (Wajib untuk Audit):
                </label>
                <textarea
                  required
                  rows={3}
                  value={overrideReason}
                  onChange={e => setOverrideReason(e.target.value)}
                  placeholder="Contoh: Surat Tugas No. 800/123/BKD Dinas Luar verifikasi lapangan..."
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setOverrideTarget(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs"
                >
                  Simpan Perubahan & Catat Audit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
