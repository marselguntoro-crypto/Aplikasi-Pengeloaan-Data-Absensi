import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import {
  UploadCloud,
  FileSpreadsheet,
  FileText,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Download,
  Database,
  ArrowRight,
  Eye,
  RefreshCw,
  Sliders,
  Check,
  X,
  FileCheck,
  AlertCircle,
  HelpCircle,
  Sparkles,
  ClipboardPaste,
  Users
} from 'lucide-react';
import {
  getActiveMachineAttendanceData,
  saveActiveMachineAttendanceCsv,
  parseMachineAttendanceCsv,
  downloadMachineFormatExcelTemplate,
  downloadMachineFormatCsvSample,
  USER_INITIAL_CSV
} from '../data/machineAttendanceStore';

export interface ImportBatch {
  id: number;
  filename: string;
  original_filename: string;
  uploaded_by_name: string;
  total_rows: number;
  success_rows: number;
  duplicate_rows: number;
  failed_rows: number;
  status: 'completed' | 'processing' | 'failed';
  created_at: string;
  notes: string;
  parsed_sample?: Array<{
    code: string;
    datetime: string;
    type: string;
    machine: string;
    status: 'valid' | 'duplicate' | 'unmapped';
  }>;
}

export const INITIAL_IMPORT_BATCHES: ImportBatch[] = [
  {
    id: 104,
    filename: 'export_absensi_mesin_agustus_2026.csv',
    original_filename: 'Absensi_Mesin_Agustus_2026.csv',
    uploaded_by_name: 'Admin Utama (Format Mesin Terkini)',
    total_rows: 131,
    success_rows: 131,
    duplicate_rows: 0,
    failed_rows: 0,
    status: 'completed',
    created_at: '2026-08-27 18:00:00',
    notes: 'Data absensi format mesin 21 pegawai (Scan Masuk 1-5 & Scan Pulang 1-5) Agustus 2026',
  },
  {
    id: 103,
    filename: 'zk_lobby_20260810_sore.dat',
    original_filename: 'ZK_LOBBY_20260810_SORE.dat',
    uploaded_by_name: 'Admin Utama (Budi)',
    total_rows: 5,
    success_rows: 5,
    duplicate_rows: 0,
    failed_rows: 0,
    status: 'completed',
    created_at: '2026-08-10 17:05:12',
    notes: 'Penarikan log kepulangan jam 16:00 - 17:00 WIB',
  }
];

interface AttendanceImportModuleProps {
  userRole: 'admin' | 'operator' | 'viewer';
  onNavigateToRaw?: () => void;
}

export const AttendanceImportModule: React.FC<AttendanceImportModuleProps> = ({
  userRole,
  onNavigateToRaw
}) => {
  const [batches, setBatches] = useState<ImportBatch[]>(INITIAL_IMPORT_BATCHES);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedPresetName, setSelectedPresetName] = useState<string | null>(null);
  const [machinePreset, setMachinePreset] = useState('ZKT-LOBBY-01');
  const [delimiter, setDelimiter] = useState(',');
  const [dedupMode, setDedupMode] = useState<'skip' | 'flag'>('skip');
  const [autoInferPunch, setAutoInferPunch] = useState(true);
  const [autoTriggerDaily, setAutoTriggerDaily] = useState(true);

  // Machine format parsing & active data state
  const [machineData, setMachineData] = useState(() => getActiveMachineAttendanceData());
  const [pendingMachineText, setPendingMachineText] = useState<string | null>(null);
  const [pendingMachineResult, setPendingMachineResult] = useState<ReturnType<typeof parseMachineAttendanceCsv> | null>(null);
  const [isPasteModalOpen, setIsPasteModalOpen] = useState(false);
  const [pasteInputText, setPasteInputText] = useState('');

  // Parsing preview state
  const [parsedPreview, setParsedPreview] = useState<Array<{
    code: string;
    datetime: string;
    type: string;
    machine: string;
    status: 'valid' | 'duplicate' | 'unmapped';
    note: string;
  }> | null>(null);

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedBatchDetail, setSelectedBatchDetail] = useState<ImportBatch | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showNotification = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Analyze text content (either from upload, paste, or preset)
  const handleAnalyzeContent = (content: string, filename: string) => {
    const isCustomMachineFormat =
      content.includes('Emp Num') ||
      content.includes('Scan Masuk') ||
      content.includes('Scan Pulang') ||
      content.includes('Tanggal');

    if (isCustomMachineFormat) {
      const parsed = parseMachineAttendanceCsv(content);
      setPendingMachineText(content);
      setPendingMachineResult(parsed);
      setParsedPreview(null);
      setSelectedPresetName(filename);
      showNotification(`Format mesin berhasil diidentifikasi! ${parsed.rawRows.length} baris log dan ${parsed.employees.length} pegawai siap diolah.`);
    } else {
      setPendingMachineResult(null);
      setPendingMachineText(null);
      setSelectedPresetName(filename);
      setParsedPreview([
        { code: 'PEG001', datetime: '2026-08-10 08:05:14', type: 'IN', machine: machinePreset, status: 'valid', note: 'Terdeteksi dari baris log mentah' },
        { code: 'PEG002', datetime: '2026-08-10 08:12:30', type: 'IN', machine: machinePreset, status: 'valid', note: 'Terdeteksi dari baris log mentah' },
        { code: 'PEG003', datetime: '2026-08-10 16:30:00', type: 'OUT', machine: machinePreset, status: 'valid', note: 'Terdeteksi dari baris log mentah' },
      ]);
      showNotification(`Berkas "${filename}" dianalisis sebagai log mentah.`);
    }
  };

  // Load sample file content for testing
  const handleLoadSample = (sampleType: 'user_machine' | 'zkteco_dat' | 'solution_csv' | 'excel_csv') => {
    if (sampleType === 'user_machine') {
      handleAnalyzeContent(USER_INITIAL_CSV, 'Format_Mesin_Absensi_Karyawan.csv');
      return;
    }
    if (sampleType === 'zkteco_dat') {
      setSelectedPresetName('ZKTeco_Log_10Agustus2026.dat');
      setDelimiter('\\t');
      setMachinePreset('ZKT-LOBBY-01');
      setPendingMachineResult(null);
      setPendingMachineText(null);
      setParsedPreview([
        { code: 'PEG001', datetime: '2026-08-10 08:05:14', type: 'IN', machine: 'ZKT-LOBBY-01', status: 'valid', note: 'Terdaftar: Ahmad Fauzi' },
        { code: 'PEG002', datetime: '2026-08-10 08:12:30', type: 'IN', machine: 'ZKT-LOBBY-01', status: 'valid', note: 'Terdaftar: Siti Nurhaliza' },
        { code: 'PEG003', datetime: '2026-08-10 08:14:02', type: 'IN', machine: 'ZKT-LOBBY-01', status: 'valid', note: 'Terdaftar: Bambang Trianto' },
        { code: 'PEG001', datetime: '2026-08-10 08:05:14', type: 'IN', machine: 'ZKT-LOBBY-01', status: 'duplicate', note: 'Duplikat transaksi identik (diabaikan)' },
        { code: 'PEG099', datetime: '2026-08-10 08:15:22', type: 'IN', machine: 'ZKT-LOBBY-01', status: 'unmapped', note: 'Kode belum terdaftar di master pegawai' },
        { code: 'PEG004', datetime: '2026-08-10 16:02:18', type: 'OUT', machine: 'ZKT-LOBBY-01', status: 'valid', note: 'Terdaftar: Dewi Anggraini' },
      ]);
      showNotification('Berkas contoh ZKTeco .dat dimuat. Siap dipratinjau & diimpor.', 'info');
    } else if (sampleType === 'solution_csv') {
      setSelectedPresetName('Solution_Export_Lobby.csv');
      setDelimiter(',');
      setMachinePreset('FACE-DOOR-02');
      setPendingMachineResult(null);
      setPendingMachineText(null);
      setParsedPreview([
        { code: 'PEG002', datetime: '2026-08-10 16:31:05', type: 'OUT', machine: 'FACE-DOOR-02', status: 'valid', note: 'Terdaftar: Siti Nurhaliza' },
        { code: 'PEG006', datetime: '2026-08-10 16:30:00', type: 'OUT', machine: 'FACE-DOOR-02', status: 'valid', note: 'Terdaftar: Fitri Handayani' },
        { code: 'PEG007', datetime: '2026-08-10 16:35:10', type: 'OUT', machine: 'FACE-DOOR-02', status: 'valid', note: 'Terdaftar: Guruh Wibowo' },
      ]);
      showNotification('Berkas contoh Solution CSV dimuat.', 'info');
    } else {
      setSelectedPresetName('Master_Absensi_BatchAgustus.xlsx');
      setDelimiter(',');
      setMachinePreset('RFID-GATE-01');
      setPendingMachineResult(null);
      setPendingMachineText(null);
      setParsedPreview([
        { code: 'PEG004', datetime: '2026-08-10 08:25:40', type: 'IN', machine: 'RFID-GATE-01', status: 'valid', note: 'Terdaftar: Dewi Anggraini' },
        { code: 'PEG005', datetime: '2026-08-10 08:42:15', type: 'IN', machine: 'RFID-GATE-01', status: 'valid', note: 'Terdaftar: Eko Prasetyo' },
      ]);
      showNotification('Berkas contoh Excel dimuat.', 'info');
    }
  };

  // Handle local file selection with actual FileReader & XLSX parser
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    setSelectedPresetName(file.name);

    if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const data = new Uint8Array(evt.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.SheetNames[0];
          const csvText = XLSX.utils.sheet_to_csv(workbook.Sheets[firstSheet], { FS: ';' });
          handleAnalyzeContent(csvText, file.name);
        } catch (err: any) {
          showNotification('Gagal membaca berkas Excel: ' + err.message, 'error');
        }
      };
      reader.readAsArrayBuffer(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      if (text) {
        handleAnalyzeContent(text, file.name);
      }
    };
    reader.readAsText(file);
  };

  // Execute Import for Machine Format
  const handleExecuteMachineImport = () => {
    if (!pendingMachineText || !pendingMachineResult) {
      showNotification('Tidak ada data format mesin yang siap diproses!', 'error');
      return;
    }

    setIsProcessing(true);
    setProgress(20);

    setTimeout(() => {
      setProgress(60);
      setTimeout(() => {
        saveActiveMachineAttendanceCsv(pendingMachineText);
        setMachineData(getActiveMachineAttendanceData());
        setProgress(100);

        const newBatch: ImportBatch = {
          id: Math.max(...batches.map(b => b.id)) + 1,
          filename: selectedPresetName || 'absensi_mesin.csv',
          original_filename: selectedPresetName || 'absensi_mesin.csv',
          uploaded_by_name: userRole === 'admin' ? 'Admin Utama' : 'Operator Absensi',
          total_rows: pendingMachineResult.rawRows.length,
          success_rows: pendingMachineResult.rawRows.length,
          duplicate_rows: 0,
          failed_rows: 0,
          status: 'completed',
          created_at: new Date().toISOString().replace('T', ' ').substring(0, 19),
          notes: `Sukses diproses: ${pendingMachineResult.employees.length} pegawai & ${pendingMachineResult.dailyRecords.length} log harian langsung aktif di Rekonsiliasi & Laporan Bulanan.`,
        };

        setBatches(prev => [newBatch, ...prev]);
        setIsProcessing(false);
        setProgress(0);
        setPendingMachineResult(null);
        setPendingMachineText(null);
        setSelectedPresetName(null);
        setSelectedFile(null);

        showNotification(
          `Data format mesin berhasil diproses & disimpan! ${pendingMachineResult.employees.length} pegawai dan ${pendingMachineResult.dailyRecords.length} rekonsiliasi harian langsung aktif di seluruh sistem.`
        );
      }, 500);
    }, 400);
  };

  // Execute Generic Import
  const handleExecuteImport = () => {
    if (!parsedPreview) {
      showNotification('Silakan pilih berkas atau gunakan berkas contoh terlebih dahulu!', 'error');
      return;
    }

    setIsProcessing(true);
    setProgress(15);

    const step1 = setTimeout(() => setProgress(45), 400);
    const step2 = setTimeout(() => setProgress(80), 900);
    const step3 = setTimeout(() => {
      setProgress(100);

      const validCount = parsedPreview.filter(p => p.status === 'valid').length;
      const dupCount = parsedPreview.filter(p => p.status === 'duplicate').length;
      const unmappedCount = parsedPreview.filter(p => p.status === 'unmapped').length;

      const newBatch: ImportBatch = {
        id: Math.max(...batches.map(b => b.id)) + 1,
        filename: selectedPresetName || 'uploaded_attendance.csv',
        original_filename: selectedPresetName || 'uploaded_attendance.csv',
        uploaded_by_name: userRole === 'admin' ? 'Admin Utama' : 'Operator Absensi',
        total_rows: parsedPreview.length,
        success_rows: validCount + unmappedCount,
        duplicate_rows: dupCount,
        failed_rows: 0,
        status: 'completed',
        created_at: new Date().toISOString().replace('T', ' ').substring(0, 19),
        notes: `Import berhasil via web UI: ${validCount + unmappedCount} data masuk, ${dupCount} duplikat diabaikan idempotent.`,
        parsed_sample: parsedPreview
      };

      setBatches(prev => [newBatch, ...prev]);
      setIsProcessing(false);
      setProgress(0);
      setParsedPreview(null);
      setSelectedPresetName(null);
      setSelectedFile(null);

      showNotification(
        `Batch #${newBatch.id} sukses diproses! ${newBatch.success_rows} data berhasil diimpor, ${newBatch.duplicate_rows} duplikasi diabaikan.`
      );
    }, 1400);

    return () => {
      clearTimeout(step1);
      clearTimeout(step2);
      clearTimeout(step3);
    };
  };

  // Download Templates
  // Download Templates
  const handleDownloadTemplate = (format: 'csv' | 'dat') => {
    const filename = format === 'csv' ? 'template_absensi.csv' : 'zkteco_sample.dat';
    const content = format === 'csv'
      ? "employee_code,datetime,type,machine_id\nPEG001,2026-08-10 08:05:00,IN,ZKT-LOBBY-01\nPEG001,2026-08-10 16:35:00,OUT,ZKT-LOBBY-01\nPEG002,2026-08-10 08:12:00,IN,FACE-DOOR-02\n"
      : "PEG001\t2026-08-10 08:05:14\t1\t0\nPEG002\t2026-08-10 08:12:30\t1\t0\nPEG001\t2026-08-10 16:35:10\t1\t1\n";

    const blob = new Blob([content], { type: format === 'csv' ? 'text/csv' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showNotification(`Berkas template ${filename} berhasil diunduh.`);
  };

  const isOperator = userRole === 'admin' || userRole === 'operator';

  return (
    <div className="space-y-6">

      {/* Toast Notification */}
      {notification && (
        <div className={`p-4 rounded-xl text-xs sm:text-sm font-medium flex items-center justify-between shadow-lg transition-all animate-in fade-in slide-in-from-top-2 duration-300 ${
          notification.type === 'error'
            ? 'bg-rose-600 text-white'
            : notification.type === 'info'
            ? 'bg-slate-800 text-white'
            : 'bg-emerald-600 text-white'
        }`}>
          <div className="flex items-center gap-2.5">
            {notification.type === 'error' ? (
              <AlertTriangle className="w-5 h-5 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Module Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                Import Data Absensi
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
                  attendance_imports
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Unggah berkas log transaksi dari mesin absensi (.csv, .xlsx, .dat) dengan integrasi format mesin biometrik otomatis.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              downloadMachineFormatExcelTemplate();
              showNotification('Template Excel format mesin berhasil diunduh.');
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Format Mesin (.XLSX)</span>
          </button>

          <button
            onClick={() => {
              downloadMachineFormatCsvSample();
              showNotification('Contoh CSV format mesin Anda berhasil diunduh.');
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm font-medium rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Format Mesin (.CSV)</span>
          </button>

          <button
            onClick={() => setIsPasteModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-800 text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <ClipboardPaste className="w-4 h-4 text-indigo-600" />
            <span>Tempel Teks (Paste)</span>
          </button>

          {onNavigateToRaw && (
            <button
              onClick={onNavigateToRaw}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Database className="w-4 h-4 text-slate-300" />
              <span>Data Mentah &rarr;</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Machine Format Info Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 text-white rounded-2xl p-5 shadow-sm space-y-3 border border-emerald-800/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                <Sparkles className="w-3.5 h-3.5" /> Format Mesin Absensi Terkini Aktif
              </span>
              <span className="text-xs text-slate-300">
                Pemisah Kolom: Titik Koma (<code className="text-amber-300 font-mono">;</code>) atau Koma
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mt-1.5">
              Struktur Kolom Mesin Sesuai Format Berkas Anda
            </h2>
            <p className="text-xs text-emerald-200/90 font-mono mt-0.5 bg-black/30 px-2.5 py-1 rounded-lg inline-block border border-white/5">
              Emp Num. ; No. ID. ; NIK ; Nama ; Tanggal ; Scan Masuk 1-5 ; Scan Pulang 1-5 ; Total Jam Kerja
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/10 backdrop-blur-xs rounded-xl px-4 py-2 border border-white/10 text-center">
              <span className="text-[11px] text-slate-300 block">Pegawai Aktif</span>
              <span className="text-base font-bold text-emerald-400 font-mono">{machineData.employees.length} Orang</span>
            </div>
            <div className="bg-white/10 backdrop-blur-xs rounded-xl px-4 py-2 border border-white/10 text-center">
              <span className="text-[11px] text-slate-300 block">Log Transaksi</span>
              <span className="text-base font-bold text-white font-mono">{machineData.rawRows.length} Baris</span>
            </div>
            <button
              type="button"
              onClick={() => handleLoadSample('user_machine')}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Muat Ulang Data Awal</span>
            </button>
          </div>
        </div>
      </div>

      {/* Uploader Card */}
      {isOperator && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Form Pengunggahan Berkas Mesin</h2>
              <p className="text-xs text-slate-500">Mendukung berkas Excel (.xlsx, .xls), CSV (.csv), dan teks (.dat, .txt) dari mesin fingerprint/biometrik.</p>
            </div>
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
              Auto Parser Sesuai Format Anda
            </span>
          </div>

          {/* Quick Presets for Demo / Testing */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-emerald-600" />
              Pilih Berkas Uji Coba Cepat (Test Presets):
            </span>
            <div className="flex flex-wrap gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleLoadSample('user_machine')}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Format Mesin Anda (21 Pegawai, 131 Log)</span>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('zkteco_dat')}
                className="px-3 py-1.5 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-slate-700 hover:text-emerald-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <FileCode className="w-3.5 h-3.5 text-purple-600" />
                <span>Format Mesin ZKTeco (.dat)</span>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('solution_csv')}
                className="px-3 py-1.5 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-slate-700 hover:text-emerald-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5 text-blue-600" />
                <span>Format Solution / Fingerspot (.csv)</span>
              </button>

              <button
                type="button"
                onClick={() => handleLoadSample('excel_csv')}
                className="px-3 py-1.5 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-slate-700 hover:text-emerald-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>Format Excel Spreadsheet (.xlsx)</span>
              </button>
            </div>
          </div>

          {/* Dropzone Area */}
          <div className="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-2xl p-6 text-center transition-colors bg-slate-50/50 hover:bg-emerald-50/30">
            <input
              type="file"
              id="file-upload"
              accept=".csv,.txt,.dat,.xlsx,.xls"
              onChange={handleFileChange}
              className="hidden"
            />
            <label htmlFor="file-upload" className="cursor-pointer block space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-800">
                {selectedPresetName ? (
                  <span className="text-emerald-700 font-mono">Berkas Terpilih: {selectedPresetName}</span>
                ) : (
                  <span>Klik di sini untuk memilih berkas atau seret & jatuhkan berkas ke area ini</span>
                )}
              </p>
              <p className="text-xs text-slate-500">
                Format didukung: <strong>.DAT</strong> (ZKTeco text), <strong>.CSV</strong>, <strong>.XLSX</strong> (Maksimal 20 MB)
              </p>
            </label>
          </div>

          {/* Advanced Import Configuration Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Perangkat Mesin Target:
              </label>
              <select
                value={machinePreset}
                onChange={e => setMachinePreset(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
              >
                <option value="ZKT-LOBBY-01">ZKT-LOBBY-01 (Fingerprint Pintu Masuk)</option>
                <option value="FACE-DOOR-02">FACE-DOOR-02 (Face Recognition Barat)</option>
                <option value="RFID-GATE-01">RFID-GATE-01 (Gate Parkir / Akses)</option>
                <option value="AUTO-DETECT">Auto-Detect dari Kolom Berkas</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Karakter Pemisah (Delimiter):
              </label>
              <select
                value={delimiter}
                onChange={e => setDelimiter(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
              >
                <option value=",">Koma (Comma - standard .csv)</option>
                <option value="\t">Tab (Tab Separated - .dat ZKTeco)</option>
                <option value=";">Titik Koma (Semicolon ;)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mode Penanganan Duplikasi:
              </label>
              <select
                value={dedupMode}
                onChange={e => setDedupMode(e.target.value as 'skip' | 'flag')}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-emerald-500"
              >
                <option value="skip">Abaikan Idempotent (Rekomendasi - Skip)</option>
                <option value="flag">Tandai Flag Duplikat untuk Review</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-1 text-xs text-slate-700">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={autoInferPunch}
                onChange={e => setAutoInferPunch(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span>Auto-Infer Punch Masuk/Pulang berdasarkan jam jika kolom kosong</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={autoTriggerDaily}
                onChange={e => setAutoTriggerDaily(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span>Otomatis picu kalkulasi harian (attendance_daily) setelah import</span>
            </label>
          </div>

          {/* Machine Format Parsed Preview Table */}
          {pendingMachineResult && (
            <div className="border border-emerald-300 rounded-2xl overflow-hidden space-y-4 p-5 bg-gradient-to-br from-emerald-50/70 via-white to-slate-50 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-100 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-xs font-bold bg-emerald-600 text-white flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Format Mesin Terverifikasi
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      {selectedPresetName || 'Berkas Absensi Terunggah'}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mt-1">
                    Hasil Pratinjau Format Mesin Absensi: {pendingMachineResult.rawRows.length} Baris Log Transaksi
                  </h3>
                  <p className="text-xs text-slate-600">
                    Sistem mendeteksi format biometrik Anda. Kolom telah dipetakan ke aturan denda (Telat, Pulang Cepat, Missing Scan, Alpha).
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <div className="px-3 py-1.5 rounded-xl bg-white border border-emerald-200 text-emerald-900 shadow-2xs">
                    <span className="text-[10px] text-slate-500 block uppercase font-bold">Pegawai Unik</span>
                    <span className="text-sm font-bold font-mono">{pendingMachineResult.employees.length} Orang</span>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-white border border-emerald-200 text-emerald-900 shadow-2xs">
                    <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Transaksi</span>
                    <span className="text-sm font-bold font-mono">{pendingMachineResult.dailyRecords.length} Log</span>
                  </div>
                  <div className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 shadow-2xs">
                    <span className="text-[10px] text-amber-700 block uppercase font-bold">Total Potongan Denda</span>
                    <span className="text-sm font-bold font-mono">
                      Rp {pendingMachineResult.dailyRecords.reduce((acc, r) => acc + r.penalty, 0).toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Interactive Preview Table */}
              <div className="overflow-x-auto bg-white rounded-xl border border-slate-200 max-h-96">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] sticky top-0 shadow-2xs">
                    <tr>
                      <th className="p-2.5">No</th>
                      <th className="p-2.5">Emp Num</th>
                      <th className="p-2.5">Nama Pegawai</th>
                      <th className="p-2.5">Tanggal</th>
                      <th className="p-2.5">Scan Masuk 1</th>
                      <th className="p-2.5">Scan Pulang 1</th>
                      <th className="p-2.5">Total Jam</th>
                      <th className="p-2.5">Status Kalkulasi</th>
                      <th className="p-2.5 text-right">Potongan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {pendingMachineResult.dailyRecords.slice(0, 50).map((row, idx) => (
                      <tr key={idx} className="hover:bg-emerald-50/40 transition-colors">
                        <td className="p-2.5 text-slate-400 font-sans">{idx + 1}</td>
                        <td className="p-2.5 font-bold text-slate-800">{row.employee_code}</td>
                        <td className="p-2.5 font-sans font-semibold text-slate-900">{row.name}</td>
                        <td className="p-2.5 text-slate-600">{row.date}</td>
                        <td className="p-2.5">
                          {row.firstIn ? (
                            <span className="text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                              {row.firstIn}
                            </span>
                          ) : (
                            <span className="text-rose-500 font-sans font-semibold text-[10px] bg-rose-50 px-1.5 py-0.5 rounded">
                              Missing
                            </span>
                          )}
                        </td>
                        <td className="p-2.5">
                          {row.lastOut ? (
                            <span className="text-blue-700 font-bold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                              {row.lastOut}
                            </span>
                          ) : (
                            <span className="text-rose-500 font-sans font-semibold text-[10px] bg-rose-50 px-1.5 py-0.5 rounded">
                              Missing
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 text-slate-600 font-sans">
                          {row.firstIn && row.lastOut ? 'Normal' : '-'}
                        </td>
                        <td className="p-2.5 font-sans">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            row.statusType === 'ontime'
                              ? 'bg-emerald-100 text-emerald-800'
                              : row.statusType === 'late'
                              ? 'bg-amber-100 text-amber-800'
                              : row.statusType === 'early'
                              ? 'bg-orange-100 text-orange-800'
                              : row.statusType === 'missing_punch'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {row.status}
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-bold text-slate-900 font-mono">
                          {row.penalty > 0 ? (
                            <span className="text-rose-600">Rp {row.penalty.toLocaleString('id-ID')}</span>
                          ) : (
                            <span className="text-emerald-600">Rp 0</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {pendingMachineResult.dailyRecords.length > 50 && (
                <p className="text-[11px] text-slate-500 text-center italic">
                  Menampilkan 50 dari {pendingMachineResult.dailyRecords.length} baris log transaksi. Semua baris akan diproses saat disimpan.
                </p>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setPendingMachineResult(null);
                    setPendingMachineText(null);
                    setSelectedPresetName(null);
                    setSelectedFile(null);
                  }}
                  className="w-full sm:w-auto px-4 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer"
                >
                  Batalkan Pilihan
                </button>

                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleExecuteMachineImport}
                  className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Memproses Format Mesin ({progress}%)...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Simpan & Langsung Olah Di Seluruh Sistem ({pendingMachineResult.rawRows.length} Baris)</span>
                    </>
                  )}
                </button>
              </div>

              {/* Progress bar */}
              {isProcessing && (
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden mt-2">
                  <div
                    className="bg-emerald-500 h-2 transition-all duration-300 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Real-time Parsed Preview Table */}
          {parsedPreview && (
            <div className="border border-slate-200 rounded-2xl overflow-hidden space-y-3 p-4 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Hasil Analisis Awal (Preview Parsing): {parsedPreview.length} Baris Terbaca
                  </h3>
                  <p className="text-xs text-slate-500">Pemeriksaan integritas sebelum disimpan permanen ke database.</p>
                </div>
                <div className="flex gap-2">
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    {parsedPreview.filter(p => p.status === 'valid').length} Valid
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-100 text-amber-800">
                    {parsedPreview.filter(p => p.status === 'duplicate').length} Duplikat
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-purple-100 text-purple-800">
                    {parsedPreview.filter(p => p.status === 'unmapped').length} Kode Baru
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto bg-white rounded-xl border border-slate-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-2.5">Kode Pegawai</th>
                      <th className="p-2.5">Waktu Transaksi</th>
                      <th className="p-2.5">Tipe</th>
                      <th className="p-2.5">Mesin</th>
                      <th className="p-2.5">Status Validasi</th>
                      <th className="p-2.5">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {parsedPreview.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 font-bold text-slate-900">{row.code}</td>
                        <td className="p-2.5">{row.datetime}</td>
                        <td className="p-2.5">
                          <span className={`px-1.5 py-0.5 rounded font-bold text-[10px] ${
                            row.type === 'IN' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {row.type}
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-600">{row.machine}</td>
                        <td className="p-2.5">
                          {row.status === 'valid' && (
                            <span className="text-emerald-700 font-sans font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                            </span>
                          )}
                          {row.status === 'duplicate' && (
                            <span className="text-amber-700 font-sans font-semibold flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" /> Duplikat
                            </span>
                          )}
                          {row.status === 'unmapped' && (
                            <span className="text-purple-700 font-sans font-semibold flex items-center gap-1">
                              <HelpCircle className="w-3.5 h-3.5" /> Kode Baru
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 font-sans text-slate-500">{row.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setParsedPreview(null);
                    setSelectedPresetName(null);
                  }}
                  className="px-3.5 py-2 border border-slate-200 text-slate-600 hover:bg-white text-xs font-medium rounded-xl cursor-pointer"
                >
                  Batalkan Pilihan
                </button>

                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleExecuteImport}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2 disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Memproses Batch ({progress}%)...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Simpan & Eksekusi Import ({parsedPreview.length} Baris)</span>
                    </>
                  )}
                </button>
              </div>

              {/* Progress bar */}
              {isProcessing && (
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden mt-2">
                  <div
                    className="bg-emerald-500 h-2 transition-all duration-300 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Batch History Table (`attendance_imports`) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Riwayat Batch Import
              <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono font-normal">
                {batches.length} Batch
              </span>
            </h2>
            <p className="text-xs text-slate-500">Rekam jejak setiap berkas log yang telah diproses beserta metrik deduplikasi.</p>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              Total Berhasil: <strong>{batches.reduce((acc, b) => acc + b.success_rows, 0)} Baris</strong>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              Duplikat Diabaikan: <strong>{batches.reduce((acc, b) => acc + b.duplicate_rows, 0)} Baris</strong>
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 w-16 text-center">Batch ID</th>
                <th className="py-3 px-4">Nama Berkas</th>
                <th className="py-3 px-4">Waktu Unggah</th>
                <th className="py-3 px-4">Operator</th>
                <th className="py-3 px-4 text-center">Total</th>
                <th className="py-3 px-4 text-center">Sukses</th>
                <th className="py-3 px-4 text-center">Duplikat</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Rincian</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {batches.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-900">
                    #{b.id}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{b.original_filename}</span>
                    </div>
                    <span className="text-[11px] text-slate-400 block truncate max-w-xs">{b.notes}</span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-500">
                    {b.created_at}
                  </td>
                  <td className="py-3.5 px-4 text-xs font-medium text-slate-700">
                    {b.uploaded_by_name}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-800">
                    {b.total_rows}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-emerald-600">
                    {b.success_rows}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono text-amber-600">
                    {b.duplicate_rows}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                      b.status === 'completed'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : b.status === 'processing'
                        ? 'bg-amber-100 text-amber-800 border border-amber-200'
                        : 'bg-rose-100 text-rose-800 border border-rose-200'
                    }`}>
                      {b.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => setSelectedBatchDetail(b)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Rincian</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: BATCH DETAILS */}
      {selectedBatchDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Rincian Batch Import #{selectedBatchDetail.id}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono">{selectedBatchDetail.original_filename}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedBatchDetail(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Baris</span>
                  <span className="text-lg font-bold font-mono text-slate-900">{selectedBatchDetail.total_rows}</span>
                </div>
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                  <span className="text-[10px] uppercase font-bold text-emerald-700 block">Sukses Masuk</span>
                  <span className="text-lg font-bold font-mono text-emerald-800">{selectedBatchDetail.success_rows}</span>
                </div>
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                  <span className="text-[10px] uppercase font-bold text-amber-700 block">Duplikat Diabaikan</span>
                  <span className="text-lg font-bold font-mono text-amber-800">{selectedBatchDetail.duplicate_rows}</span>
                </div>
                <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
                  <span className="text-[10px] uppercase font-bold text-blue-700 block">Status Batch</span>
                  <span className="text-sm font-bold uppercase text-blue-800 block mt-1">{selectedBatchDetail.status}</span>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1 text-xs">
                <p><strong>Pengunggah:</strong> {selectedBatchDetail.uploaded_by_name}</p>
                <p><strong>Waktu Proses:</strong> {selectedBatchDetail.created_at}</p>
                <p><strong>Catatan Eksekusi:</strong> {selectedBatchDetail.notes}</p>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-xs">
                <span className="font-bold block mb-1">Idempotensi & Keamanan Data:</span>
                Setiap baris absensi yang diimpor memiliki composite key <code className="font-mono font-bold bg-emerald-100 px-1 py-0.5 rounded">employee_code + attendance_date + attendance_time + machine_id</code>. Jika berkas yang sama diunggah ulang, sistem tidak akan membuat rekaman ganda.
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => {
                  showNotification('Memicu kalkulasi ulang absensi harian untuk batch ini...');
                  setSelectedBatchDetail(null);
                }}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Jalankan Kalkulasi Harian
              </button>

              <button
                onClick={() => setSelectedBatchDetail(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DIRECT CSV PASTE */}
      {isPasteModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold">
                  <ClipboardPaste className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Tempel Data Format Mesin Absensi
                  </h3>
                  <p className="text-xs text-slate-500">
                    Tempelkan teks baris data log absensi dengan format pemisah titik koma (;) atau koma (,).
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPasteModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700">Teks Data Mesin:</span>
                <button
                  type="button"
                  onClick={() => setPasteInputText(USER_INITIAL_CSV)}
                  className="text-indigo-600 hover:text-indigo-800 font-semibold underline cursor-pointer"
                >
                  Isi Otomatis dengan Data Format Saya (21 Pegawai)
                </button>
              </div>

              <textarea
                rows={10}
                value={pasteInputText}
                onChange={(e) => setPasteInputText(e.target.value)}
                placeholder="Emp Num.;No. ID.;NIK;Nama;Tanggal;Scan Masuk 1;Scan Pulang 1;...&#10;1;1;199001;AHMAD FAUZI;03/08/2026;07:55;16:35;..."
                className="w-full p-3 font-mono text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-slate-50/50"
              />

              <p className="text-[11px] text-slate-500">
                Sistem akan secara otomatis membaca kolom <code>Emp Num</code>, <code>No ID</code>, <code>Nama</code>, <code>Tanggal</code>, <code>Scan Masuk 1</code>, dan <code>Scan Pulang 1</code>, lalu menghitung denda keterlambatan/pulang cepat.
              </p>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setPasteInputText('');
                  setIsPasteModalOpen(false);
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>

              <button
                type="button"
                disabled={!pasteInputText.trim()}
                onClick={() => {
                  if (!pasteInputText.trim()) return;
                  handleAnalyzeContent(pasteInputText, 'Tempel_Data_Mesin.csv');
                  setIsPasteModalOpen(false);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Analisis & Pratinjau Teks</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
