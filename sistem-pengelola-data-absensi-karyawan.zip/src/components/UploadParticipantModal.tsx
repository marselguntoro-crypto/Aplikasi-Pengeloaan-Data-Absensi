import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  Upload,
  FileSpreadsheet,
  Download,
  AlertCircle,
  CheckCircle2,
  X,
  FileText,
  Database,
  ArrowRight,
  Check,
  RefreshCw
} from 'lucide-react';
import {
  EmployeeRecord,
  downloadParticipantTemplateCSV,
  downloadParticipantTemplateExcel,
  syncEmployeesToSupabaseApi
} from '../data/participantStore';

interface UploadParticipantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (imported: EmployeeRecord[]) => void;
  existingEmployees: EmployeeRecord[];
}

interface ParsedRow {
  employee_code: string;
  nip: string | null;
  name: string;
  department: string;
  position: string;
  employment_status: string;
  isValid: boolean;
  validationError?: string;
}

export const UploadParticipantModal: React.FC<UploadParticipantModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  existingEmployees,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importMode, setImportMode] = useState<'replace' | 'append'>('replace');
  const [syncToSupabase, setSyncToSupabase] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (selectedFile: File) => {
    setErrorMsg(null);
    const validExtensions = ['.xlsx', '.xls', '.csv'];
    const hasValidExt = validExtensions.some(ext => selectedFile.name.toLowerCase().endsWith(ext));

    if (!hasValidExt) {
      setErrorMsg('Format file tidak didukung. Harap unggah file .xlsx, .xls, atau .csv');
      return;
    }

    setFile(selectedFile);
    parseSpreadsheet(selectedFile);
  };

  const parseSpreadsheet = async (fileToParse: File) => {
    setIsProcessing(true);
    setErrorMsg(null);

    try {
      const buffer = await fileToParse.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        throw new Error('Berkas spreadsheet tidak memiliki lembar kerja (sheet).');
      }

      const worksheet = workbook.Sheets[firstSheetName];
      const rawJson = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

      if (rawJson.length === 0) {
        throw new Error('Berkas kosong atau tidak ada data yang terbaca.');
      }

      const parsed: ParsedRow[] = rawJson.map((row, index) => {
        // Normalize keys to lowercase for flexible column header matching
        const normalizedRow: Record<string, any> = {};
        for (const [key, value] of Object.entries(row)) {
          const normKey = key.trim().toLowerCase().replace(/[\s\-_]+/g, '_');
          normalizedRow[normKey] = value;
        }

        // Detect Code
        const code = String(
          normalizedRow['kode_pegawai'] ||
          normalizedRow['kode'] ||
          normalizedRow['code'] ||
          normalizedRow['employee_code'] ||
          normalizedRow['id_peserta'] ||
          normalizedRow['id'] ||
          normalizedRow['nik'] ||
          ''
        ).trim();

        // Detect Name
        const name = String(
          normalizedRow['nama_lengkap'] ||
          normalizedRow['nama'] ||
          normalizedRow['name'] ||
          normalizedRow['peserta'] ||
          normalizedRow['nama_peserta'] ||
          ''
        ).trim();

        // Detect NIP
        const nipVal = String(
          normalizedRow['nip'] ||
          normalizedRow['nip_baru'] ||
          normalizedRow['nomor_induk'] ||
          ''
        ).trim();
        const nip = nipVal ? nipVal : null;

        // Detect Department
        const department = String(
          normalizedRow['departemen'] ||
          normalizedRow['unit_kerja'] ||
          normalizedRow['divisi'] ||
          normalizedRow['opd'] ||
          normalizedRow['bagian'] ||
          normalizedRow['department'] ||
          'Umum'
        ).trim() || 'Umum';

        // Detect Position
        const position = String(
          normalizedRow['jabatan'] ||
          normalizedRow['position'] ||
          normalizedRow['posisi'] ||
          normalizedRow['tugas'] ||
          'Staf'
        ).trim() || 'Staf';

        // Detect Employment Status
        const employment_status = String(
          normalizedRow['status_kepegawaian'] ||
          normalizedRow['status'] ||
          normalizedRow['employment_status'] ||
          normalizedRow['jenis'] ||
          'PNS'
        ).trim() || 'PNS';

        let isValid = true;
        let validationError = '';

        if (!code) {
          isValid = false;
          validationError = 'Kode pegawai tidak boleh kosong';
        } else if (!name) {
          isValid = false;
          validationError = 'Nama peserta tidak boleh kosong';
        }

        return {
          employee_code: code,
          nip,
          name,
          department,
          position,
          employment_status,
          isValid,
          validationError,
        };
      });

      setParsedRows(parsed);
    } catch (err: any) {
      console.error('Error parsing spreadsheet:', err);
      setErrorMsg(err.message || 'Gagal membaca berkas. Pastikan format file sesuai.');
      setParsedRows([]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirmImport = async () => {
    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      setErrorMsg('Tidak ada baris data yang valid untuk diimpor.');
      return;
    }

    setIsProcessing(true);

    const newEmployees: EmployeeRecord[] = validRows.map((r, idx) => ({
      id: Date.now() + idx,
      employee_code: r.employee_code,
      nip: r.nip,
      name: r.name,
      department: r.department,
      position: r.position,
      employment_status: r.employment_status,
      is_active: true,
      created_at: new Date().toISOString().slice(0, 10),
      stats: { recorded: 0, onTime: 0, late: 0, missing: 0, penalties: 0 }
    }));

    let finalEmployeesList: EmployeeRecord[] = [];
    if (importMode === 'replace') {
      finalEmployeesList = newEmployees;
    } else {
      // Append / Upsert by employee_code
      const existingMap = new Map<string, EmployeeRecord>();
      existingEmployees.forEach(e => existingMap.set(e.employee_code, e));
      newEmployees.forEach(e => existingMap.set(e.employee_code, e));
      finalEmployeesList = Array.from(existingMap.values());
    }

    // Optionally sync to Supabase
    if (syncToSupabase) {
      try {
        await syncEmployeesToSupabaseApi(finalEmployeesList);
      } catch (err) {
        console.warn('Supabase sync attempted but failed/table not yet created:', err);
      }
    }

    setIsProcessing(false);
    onSuccess(finalEmployeesList);
    onClose();
  };

  const validCount = parsedRows.filter(r => r.isValid).length;
  const invalidCount = parsedRows.filter(r => !r.isValid).length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        {/* HEADER */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Upload Data Peserta / Pegawai
              </h3>
              <p className="text-xs text-slate-500">
                Mendukung berkas Excel (.xlsx, .xls) dan CSV (.csv)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TEMPLATE DOWNLOAD BANNER */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex-shrink-0">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-semibold text-slate-700">
              Butuh format contoh kolom yang tepat?
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={downloadParticipantTemplateExcel}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-medium transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unduh Template Excel (.xlsx)</span>
            </button>
            <button
              onClick={downloadParticipantTemplateCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-medium transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Unduh Template CSV</span>
            </button>
          </div>
        </div>

        {/* DRAG AND DROP ZONE */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleFileChange(e.dataTransfer.files[0]);
            }
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer flex-shrink-0 ${
            isDragging
              ? 'border-emerald-500 bg-emerald-50/50 scale-[0.99]'
              : 'border-emerald-300 bg-emerald-50/20 hover:bg-emerald-50/40'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileChange(e.target.files[0]);
              }
            }}
          />
          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-2.5">
            <Upload className="w-6 h-6" />
          </div>
          <p className="text-sm font-bold text-slate-800">
            {file ? file.name : 'Tarik & lepas file Excel/CSV ke sini, atau klik untuk memilih file'}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Mendukung .xlsx, .xls, dan .csv dengan header: kode_pegawai, nip, nama_lengkap, departemen, jabatan, status_kepegawaian
          </p>
          {file && (
            <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-semibold">
              <Check className="w-3.5 h-3.5" />
              <span>File siap: {file.name} ({(file.size / 1024).toFixed(1)} KB)</span>
            </div>
          )}
        </div>

        {/* ERROR MESSAGE */}
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2 flex-shrink-0">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* PARSED PREVIEW */}
        {parsedRows.length > 0 && (
          <div className="flex-1 min-h-0 flex flex-col space-y-3 overflow-hidden">
            <div className="flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-3 text-xs">
                <span className="font-bold text-slate-800">
                  Hasil Baca File: {parsedRows.length} baris
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  {validCount} Siap Impor
                </span>
                {invalidCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-semibold flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {invalidCount} Perlu Perbaikan
                  </span>
                )}
              </div>

              {/* IMPORT MODE TOGGLE */}
              <div className="flex items-center gap-2 text-xs">
                <label className="text-slate-600 font-medium">Metode Impor:</label>
                <select
                  value={importMode}
                  onChange={(e) => setImportMode(e.target.value as any)}
                  className="px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700"
                >
                  <option value="replace">Ganti Semua Peserta (Mulai Bersih)</option>
                  <option value="append">Gabungkan / Tambahkan ke Daftar</option>
                </select>
              </div>
            </div>

            {/* PREVIEW TABLE */}
            <div className="flex-1 overflow-y-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider sticky top-0">
                  <tr>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Kode Pegawai</th>
                    <th className="py-2.5 px-3">NIP</th>
                    <th className="py-2.5 px-3">Nama Lengkap</th>
                    <th className="py-2.5 px-3">Departemen / Unit</th>
                    <th className="py-2.5 px-3">Jabatan</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-normal">
                  {parsedRows.slice(0, 50).map((row, idx) => (
                    <tr key={idx} className={row.isValid ? 'hover:bg-slate-50' : 'bg-rose-50/50'}>
                      <td className="py-2 px-3">
                        {row.isValid ? (
                          <span className="inline-flex items-center text-emerald-600" title="Valid">
                            <CheckCircle2 className="w-4 h-4" />
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-rose-600" title={row.validationError}>
                            <AlertCircle className="w-4 h-4" />
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">
                        {row.employee_code || <span className="text-rose-500 italic">Kosong</span>}
                      </td>
                      <td className="py-2 px-3 font-mono text-slate-600">
                        {row.nip || '-'}
                      </td>
                      <td className="py-2 px-3 font-semibold text-slate-800">
                        {row.name || <span className="text-rose-500 italic">Kosong</span>}
                      </td>
                      <td className="py-2 px-3 text-slate-600">
                        {row.department}
                      </td>
                      <td className="py-2 px-3 text-slate-600">
                        {row.position}
                      </td>
                      <td className="py-2 px-3">
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-semibold">
                          {row.employment_status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {parsedRows.length > 50 && (
              <p className="text-[11px] text-slate-400 text-center flex-shrink-0">
                Menampilkan 50 baris pertama dari total {parsedRows.length} baris terbaca.
              </p>
            )}

            {/* SUPABASE SYNC CHECKBOX */}
            <div className="flex items-center gap-2 p-3 bg-emerald-50/50 border border-emerald-200/60 rounded-xl text-xs flex-shrink-0">
              <input
                type="checkbox"
                id="syncSupabase"
                checked={syncToSupabase}
                onChange={(e) => setSyncToSupabase(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
              />
              <label htmlFor="syncSupabase" className="font-semibold text-slate-700 cursor-pointer flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-emerald-600" />
                <span>Sekaligus sinkronkan data ke tabel <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-emerald-300">employees</code> di database Supabase Anda</span>
              </label>
            </div>
          </div>
        )}

        {/* FOOTER ACTIONS */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 flex-shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-medium rounded-xl transition-colors"
          >
            Batal
          </button>

          <button
            type="button"
            disabled={isProcessing || parsedRows.length === 0 || validCount === 0}
            onClick={handleConfirmImport}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Memproses Data...</span>
              </>
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>Simpan {validCount} Peserta ke Aplikasi</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
