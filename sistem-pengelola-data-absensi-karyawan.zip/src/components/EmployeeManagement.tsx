import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Users,
  UserPlus,
  FileSpreadsheet,
  Download,
  Search,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Eye,
  Edit3,
  Trash2,
  Upload,
  AlertCircle,
  Building,
  Briefcase,
  BadgeCheck,
  FileText,
  Check,
  X,
  Sparkles,
  PlusCircle,
  Sliders,
  Filter,
  CheckSquare,
  Square,
  ArrowUpDown,
  AlertTriangle,
  Layers,
  Database
} from 'lucide-react';
import {
  getStoredEmployees,
  saveStoredEmployees,
  clearStoredEmployees,
  downloadParticipantTemplateCSV,
  downloadParticipantTemplateExcel,
  syncEmployeesToSupabaseApi
} from '../data/participantStore';
import { UploadParticipantModal } from './UploadParticipantModal';

export interface EmployeeRecord {
  id: number;
  employee_code: string;
  nip: string | null;
  name: string;
  department: string;
  position: string;
  employment_status: string;
  is_active: boolean;
  created_at: string;
  stats?: {
    recorded: number;
    onTime: number;
    late: number;
    missing: number;
    penalties: number;
  };
}

// Initial employees initialized to empty array - dummy participants removed as requested by user
const INITIAL_EMPLOYEES: EmployeeRecord[] = [];

const DEFAULT_DEPARTMENTS = [
  'Teknologi Informasi & Sistem',
  'Bagian Keuangan & Aset',
  'Bagian Kepegawaian & SDM',
  'Perencanaan & Evaluasi',
  'Hukum & Humas',
  'Sekretariat',
  'Operasional Lapangan'
];

// Rich set of employment statuses
const STANDARD_EMPLOYMENT_STATUSES = [
  { value: 'PNS', label: 'PNS / ASN (Pegawai Negeri Sipil)' },
  { value: 'PPPK', label: 'PPPK (Perjanjian Kerja)' },
  { value: 'PPNPN', label: 'PPNPN (Non-PNS Pemerintah)' },
  { value: 'Honorer', label: 'Tenaga Honorer / THL' },
  { value: 'Tetap', label: 'Karyawan Tetap' },
  { value: 'Kontrak', label: 'Pegawai Kontrak / PKWT' },
  { value: 'Tenaga Ahli', label: 'Tenaga Ahli / Konsultan' },
  { value: 'Outsourcing', label: 'Outsourcing / Alih Daya' },
  { value: 'Magang', label: 'Magang / PKL' },
];

const COMMON_POSITIONS = [
  'Kepala Bagian IT & Infrastruktur',
  'Kepala Bagian Keuangan & Aset',
  'Kepala Bagian Kepegawaian & SDM',
  'Kepala Subbagian Umum & Rumah Tangga',
  'Analis SDM Aparatur Ahli Muda',
  'Analis Kebijakan Ahli Pertama',
  'Pranata Komputer Ahli Pertama',
  'Pranata Humas Ahli Pertama',
  'Statistisi Ahli Pertama',
  'Bendahara Pengeluaran Pembantu',
  'Bendahara Penerimaan',
  'Pengadministrasi Perkantoran',
  'Arsiparis Terampil',
  'Teknisi Jaringan & Komunikasi',
  'Programmer Web & Database',
  'Verifikator Berkas SPJ',
  'Resepsionis & Layanan Informasi',
  'Operator Mesin Absensi',
  'Staf Administrasi Umum',
  'Tenaga Keamanan (Security)',
  'Pengemudi Operasional'
];

interface EmployeeManagementProps {
  userRole: 'admin' | 'operator' | 'viewer';
}

export const EmployeeManagement: React.FC<EmployeeManagementProps> = ({ userRole }) => {
  const [employees, setEmployees] = useState<EmployeeRecord[]>(() => getStoredEmployees());
  
  // Filter & Search States
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [positionFilter, setPositionFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [employmentStatusFilter, setEmploymentStatusFilter] = useState('');
  const [sortBy, setSortBy] = useState<'name_asc' | 'name_desc' | 'code_asc' | 'code_desc' | 'dept' | 'newest'>('name_asc');
  
  // Selection States for "Pilih Semua" & Bulk Actions
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const headerCheckboxRef = useRef<HTMLInputElement | null>(null);

  // Delete Modal State (Single & Bulk Delete with Audit Confirmation)
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    type: 'single' | 'bulk';
    targetEmployee?: EmployeeRecord;
  }>({
    isOpen: false,
    type: 'bulk'
  });

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<EmployeeRecord | null>(null);
  const [viewingEmployee, setViewingEmployee] = useState<EmployeeRecord | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isSyncingSupabase, setIsSyncingSupabase] = useState(false);

  // Keep state and localStorage synchronized
  useEffect(() => {
    saveStoredEmployees(employees);
  }, [employees]);

  useEffect(() => {
    const handleUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setEmployees(e.detail);
      }
    };
    window.addEventListener('participants_updated', handleUpdated);
    return () => window.removeEventListener('participants_updated', handleUpdated);
  }, []);

  const handleClearAllParticipants = () => {
    if (window.confirm('Apakah Anda yakin ingin mengosongkan seluruh data peserta? Semua data peserta di aplikasi akan dibersihkan.')) {
      clearStoredEmployees();
      setEmployees([]);
      setSelectedIds([]);
      showNotification('Seluruh data peserta telah berhasil dikosongkan.');
    }
  };

  const handleSyncToSupabase = async () => {
    if (employees.length === 0) {
      showNotification('Tidak ada peserta untuk disinkronkan. Unggah peserta terlebih dahulu.', 'info');
      return;
    }
    setIsSyncingSupabase(true);
    try {
      const res = await syncEmployeesToSupabaseApi(employees);
      if (res.success) {
        showNotification(`Sukses menyinkronkan ${employees.length} peserta ke tabel 'employees' Supabase!`);
      } else {
        showNotification(`Gagal sinkron ke Supabase: ${res.message}`, 'error');
      }
    } catch (err: any) {
      showNotification(`Terjadi kesalahan: ${err.message}`, 'error');
    } finally {
      setIsSyncingSupabase(false);
    }
  };

  // Flexible Form State
  const [isCustomDept, setIsCustomDept] = useState(false);
  const [isCustomStatus, setIsCustomStatus] = useState(false);

  const [formData, setFormData] = useState({
    employee_code: '',
    nip: '',
    name: '',
    department: DEFAULT_DEPARTMENTS[0],
    position: '',
    employment_status: 'PNS',
    custom_status_text: '',
    is_active: true
  });

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Dynamically compute all unique departments across default + existing data
  const dynamicDepartments = useMemo(() => {
    const fromData = employees.map(e => e.department.trim()).filter(Boolean);
    const combined = Array.from(new Set([...DEFAULT_DEPARTMENTS, ...fromData]));
    return combined.sort();
  }, [employees]);

  // Dynamically compute all unique positions across existing data
  const dynamicPositions = useMemo(() => {
    const fromData = employees.map(e => e.position.trim()).filter(Boolean);
    const combined = Array.from(new Set([...COMMON_POSITIONS, ...fromData]));
    return combined.sort();
  }, [employees]);

  // Dynamically compute all unique employment statuses across standard + existing data
  const dynamicEmploymentStatuses = useMemo(() => {
    const fromData = employees.map(e => e.employment_status.trim()).filter(Boolean);
    const standardKeys = STANDARD_EMPLOYMENT_STATUSES.map(s => s.value);
    const combined = Array.from(new Set([...standardKeys, ...fromData]));
    return combined;
  }, [employees]);

  // Filtered and Sorted employees
  const filteredList = useMemo(() => {
    const list = employees.filter(emp => {
      const q = search.toLowerCase().trim();
      const matchSearch = !q ||
        emp.name.toLowerCase().includes(q) ||
        emp.employee_code.toLowerCase().includes(q) ||
        (emp.nip && emp.nip.includes(q)) ||
        emp.position.toLowerCase().includes(q) ||
        emp.department.toLowerCase().includes(q);
      
      const matchDept = deptFilter === '' || emp.department === deptFilter;
      const matchPosition = positionFilter === '' || emp.position === positionFilter;
      const matchStatus = statusFilter === '' || (statusFilter === '1' ? emp.is_active : !emp.is_active);
      const matchEmploymentStatus = employmentStatusFilter === '' || emp.employment_status === employmentStatusFilter;

      return matchSearch && matchDept && matchPosition && matchStatus && matchEmploymentStatus;
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'name_asc') return a.name.localeCompare(b.name, 'id');
      if (sortBy === 'name_desc') return b.name.localeCompare(a.name, 'id');
      if (sortBy === 'code_asc') return a.employee_code.localeCompare(b.employee_code);
      if (sortBy === 'code_desc') return b.employee_code.localeCompare(a.employee_code);
      if (sortBy === 'dept') return a.department.localeCompare(b.department, 'id');
      if (sortBy === 'newest') return b.id - a.id;
      return 0;
    });
  }, [employees, search, deptFilter, positionFilter, statusFilter, employmentStatusFilter, sortBy]);

  // Aggregate Stats
  const stats = useMemo(() => {
    return {
      total: employees.length,
      active: employees.filter(e => e.is_active).length,
      inactive: employees.filter(e => !e.is_active).length,
      departments: Array.from(new Set(employees.map(e => e.department))).length
    };
  }, [employees]);

  // Quick preset counts
  const countPNS = useMemo(() => employees.filter(e => {
    const s = e.employment_status.toLowerCase();
    return s.includes('pns') || s.includes('asn');
  }).length, [employees]);

  const countPPPK = useMemo(() => employees.filter(e => {
    const s = e.employment_status.toLowerCase();
    return s.includes('pppk');
  }).length, [employees]);

  const countNonASN = useMemo(() => employees.filter(e => {
    const s = e.employment_status.toLowerCase();
    return !s.includes('pns') && !s.includes('asn') && !s.includes('pppk');
  }).length, [employees]);

  // Active filter count
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (search.trim()) count++;
    if (deptFilter) count++;
    if (positionFilter) count++;
    if (statusFilter !== '') count++;
    if (employmentStatusFilter) count++;
    if (sortBy !== 'name_asc') count++;
    return count;
  }, [search, deptFilter, positionFilter, statusFilter, employmentStatusFilter, sortBy]);

  // Reset all filters
  const handleResetFilters = () => {
    setSearch('');
    setDeptFilter('');
    setPositionFilter('');
    setStatusFilter('');
    setEmploymentStatusFilter('');
    setSortBy('name_asc');
  };

  // Selection logic for "Pilih Semua"
  const isAllFilteredSelected = filteredList.length > 0 && filteredList.every(e => selectedIds.includes(e.id));
  const isIndeterminate = filteredList.some(e => selectedIds.includes(e.id)) && !isAllFilteredSelected;

  useEffect(() => {
    if (headerCheckboxRef.current) {
      headerCheckboxRef.current.indeterminate = isIndeterminate;
    }
  }, [isIndeterminate]);

  const handleSelectAll = () => {
    if (isAllFilteredSelected) {
      // Uncheck all filtered items
      const filteredIdSet = new Set(filteredList.map(e => e.id));
      setSelectedIds(prev => prev.filter(id => !filteredIdSet.has(id)));
    } else {
      // Select all filtered items
      const newIds = Array.from(new Set([...selectedIds, ...filteredList.map(e => e.id)]));
      setSelectedIds(newIds);
    }
  };

  const handleSelectAllGlobal = () => {
    setSelectedIds(employees.map(e => e.id));
  };

  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  const handleToggleSelect = (id: number) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Delete Handlers (Single & Bulk Delete)
  const handleOpenSingleDelete = (emp: EmployeeRecord) => {
    setDeleteModal({
      isOpen: true,
      type: 'single',
      targetEmployee: emp
    });
  };

  const handleOpenBulkDelete = () => {
    if (selectedIds.length === 0) return;
    setDeleteModal({
      isOpen: true,
      type: 'bulk'
    });
  };

  const handleConfirmDelete = () => {
    if (deleteModal.type === 'single' && deleteModal.targetEmployee) {
      const emp = deleteModal.targetEmployee;
      setEmployees(prev => prev.filter(e => e.id !== emp.id));
      setSelectedIds(prev => prev.filter(id => id !== emp.id));
      setDeleteModal({ isOpen: false, type: 'single' });
      showNotification(`Pegawai '${emp.name}' (${emp.employee_code}) berhasil dinonaktifkan / dihapus (Soft Delete tercatat di audit_logs).`, 'info');
    } else if (deleteModal.type === 'bulk') {
      const count = selectedIds.length;
      setEmployees(prev => prev.filter(e => !selectedIds.includes(e.id)));
      setSelectedIds([]);
      setDeleteModal({ isOpen: false, type: 'bulk' });
      showNotification(`Sebanyak ${count} data pegawai terpilih berhasil dihapus (Soft Delete tercatat di audit_logs).`, 'info');
    }
  };

  const handleBulkToggleActive = (activate: boolean) => {
    if (selectedIds.length === 0) return;
    const count = selectedIds.length;
    setEmployees(prev =>
      prev.map(e => selectedIds.includes(e.id) ? { ...e, is_active: activate } : e)
    );
    showNotification(`Status ${count} pegawai berhasil diubah menjadi ${activate ? 'Aktif' : 'Nonaktif'}.`);
  };

  const handleExportSelected = () => {
    if (selectedIds.length === 0) return;
    showNotification(`Mengunduh file: pegawai_terpilih_${new Date().toISOString().slice(0,10)}.xlsx (${selectedIds.length} data terpilih)`);
  };

  // Open Create Form
  const handleOpenCreate = () => {
    setEditingEmployee(null);
    setIsCustomDept(false);
    setIsCustomStatus(false);
    setFormData({
      employee_code: `PEG${String(employees.length + 1).padStart(3, '0')}`,
      nip: '',
      name: '',
      department: dynamicDepartments[0] || 'Sekretariat',
      position: 'Staf Administrasi',
      employment_status: 'PNS',
      custom_status_text: '',
      is_active: true
    });
    setIsFormOpen(true);
  };

  // Open Edit Form
  const handleOpenEdit = (emp: EmployeeRecord) => {
    setEditingEmployee(emp);

    // Check if department is in default list or custom
    const isDeptInList = dynamicDepartments.includes(emp.department);
    setIsCustomDept(!isDeptInList);

    // Check if status is in standard list or custom
    const isStandardStatus = STANDARD_EMPLOYMENT_STATUSES.some(s => s.value.toLowerCase() === emp.employment_status.toLowerCase());
    setIsCustomStatus(!isStandardStatus);

    setFormData({
      employee_code: emp.employee_code,
      nip: emp.nip || '',
      name: emp.name,
      department: emp.department,
      position: emp.position,
      employment_status: isStandardStatus ? emp.employment_status : '__CUSTOM__',
      custom_status_text: !isStandardStatus ? emp.employment_status : '',
      is_active: emp.is_active
    });
    setIsFormOpen(true);
  };

  // Submit Form (Create / Update)
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.employee_code.trim()) {
      showNotification('Nama lengkap dan Kode Pegawai wajib diisi!', 'error');
      return;
    }

    const finalDepartment = formData.department.trim();
    if (!finalDepartment) {
      showNotification('Unit / Departemen tidak boleh kosong!', 'error');
      return;
    }

    const finalPosition = formData.position.trim();
    if (!finalPosition) {
      showNotification('Jabatan pegawai wajib diisi!', 'error');
      return;
    }

    // Resolve final employment status (flexible)
    let finalStatus = formData.employment_status;
    if (isCustomStatus || formData.employment_status === '__CUSTOM__') {
      finalStatus = formData.custom_status_text.trim() || 'Tetap';
    }

    if (editingEmployee) {
      // Update
      setEmployees(prev =>
        prev.map(emp =>
          emp.id === editingEmployee.id
            ? {
                ...emp,
                employee_code: formData.employee_code.trim(),
                nip: formData.nip.trim() ? formData.nip.trim() : null,
                name: formData.name.trim(),
                department: finalDepartment,
                position: finalPosition,
                employment_status: finalStatus,
                is_active: formData.is_active
              }
            : emp
        )
      );
      showNotification(`Data pegawai '${formData.name}' berhasil diperbarui dengan Unit '${finalDepartment}' & Jabatan '${finalPosition}'.`);
    } else {
      // Create
      const newId = Math.max(...employees.map(e => e.id), 0) + 1;
      const newEmp: EmployeeRecord = {
        id: newId,
        employee_code: formData.employee_code.trim(),
        nip: formData.nip.trim() ? formData.nip.trim() : null,
        name: formData.name.trim(),
        department: finalDepartment,
        position: finalPosition,
        employment_status: finalStatus,
        is_active: formData.is_active,
        created_at: new Date().toISOString().split('T')[0],
        stats: { recorded: 0, onTime: 0, late: 0, missing: 0, penalties: 0 }
      };
      setEmployees(prev => [newEmp, ...prev]);
      showNotification(`Pegawai baru '${formData.name}' (${formData.employee_code}) berhasil ditambahkan.`);
    }

    setIsFormOpen(false);
  };

  // Toggle Active Status
  const handleToggleStatus = (emp: EmployeeRecord) => {
    setEmployees(prev =>
      prev.map(e => (e.id === emp.id ? { ...e, is_active: !e.is_active } : e))
    );
    showNotification(`Status pegawai '${emp.name}' diubah menjadi ${!emp.is_active ? 'Aktif' : 'Nonaktif'}.`);
  };

  // Soft Delete (Single item confirmation)
  const handleDelete = (emp: EmployeeRecord) => {
    handleOpenSingleDelete(emp);
  };

  // Simulate Export Excel
  const handleExportExcel = () => {
    showNotification(`Mengunduh file: data_pegawai_${new Date().toISOString().slice(0,10)}.xlsx (${filteredList.length} data terpilih)`);
  };

  // Helper to render responsive badges for any status
  const renderStatusBadge = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('pns') || s.includes('asn')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-indigo-50 text-indigo-700 border border-indigo-200">{status}</span>;
    }
    if (s.includes('pppk')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-sky-50 text-sky-700 border border-sky-200">{status}</span>;
    }
    if (s.includes('ppnpn')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-teal-50 text-teal-700 border border-teal-200">{status}</span>;
    }
    if (s.includes('tetap')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-emerald-50 text-emerald-700 border border-emerald-200">{status}</span>;
    }
    if (s.includes('kontrak') || s.includes('pkwt')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-amber-50 text-amber-700 border border-amber-200">{status}</span>;
    }
    if (s.includes('honorer') || s.includes('thl')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-orange-50 text-orange-700 border border-orange-200">{status}</span>;
    }
    if (s.includes('ahli') || s.includes('konsultan')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-purple-50 text-purple-700 border border-purple-200">{status}</span>;
    }
    if (s.includes('outsourcing') || s.includes('daya')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-slate-100 text-slate-700 border border-slate-300">{status}</span>;
    }
    if (s.includes('magang') || s.includes('pkl')) {
      return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200">{status}</span>;
    }
    // Custom status
    return <span className="inline-flex items-center px-2 py-0.5 text-xs font-bold rounded bg-cyan-50 text-cyan-800 border border-cyan-200">{status}</span>;
  };

  const isOperator = userRole === 'admin' || userRole === 'operator';

  return (
    <div className="space-y-6">

      {/* HTML5 Datalist for Jabatan / Position Suggestions */}
      <datalist id="position-suggestions">
        {COMMON_POSITIONS.map((pos) => (
          <option key={pos} value={pos} />
        ))}
      </datalist>

      {/* Notification Toast */}
      {notification && (
        <div className={`p-4 rounded-xl text-sm font-medium flex items-center justify-between shadow-lg transition-all animate-in fade-in slide-in-from-top-2 duration-300 ${
          notification.type === 'error'
            ? 'bg-rose-600 text-white'
            : notification.type === 'info'
            ? 'bg-slate-800 text-white'
            : 'bg-emerald-600 text-white'
        }`}>
          <div className="flex items-center gap-2.5">
            {notification.type === 'error' ? (
              <AlertCircle className="w-5 h-5 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button onClick={() => setNotification(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
              <Users className="w-7 h-7 text-emerald-600" />
              Master Data Pegawai
            </h1>
            <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
              Fleksibel
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Kelola data pegawai, unit/departemen fleksibel, jabatan fungsional/umum, dan variasi status kepegawaian (ASN, PPPK, PPNPN, Honorer, Tetap, Kontrak, dll).
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={downloadParticipantTemplateExcel}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs sm:text-sm font-medium rounded-xl shadow-xs transition-colors cursor-pointer"
            title="Unduh format Excel untuk mengunggah peserta"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Template Excel</span>
          </button>

          {isOperator && (
            <>
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Upload Berkas Peserta (.xlsx / .csv)</span>
              </button>

              <button
                onClick={handleOpenCreate}
                className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <UserPlus className="w-4 h-4 text-slate-600" />
                <span>Tambah Manual</span>
              </button>

              {employees.length > 0 && (
                <>
                  <button
                    onClick={handleSyncToSupabase}
                    disabled={isSyncingSupabase}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 text-xs sm:text-sm font-medium rounded-xl transition-colors cursor-pointer"
                    title="Sinkronkan data peserta ke Supabase"
                  >
                    <Database className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{isSyncingSupabase ? 'Sinkron...' : 'Sync Supabase'}</span>
                  </button>

                  <button
                    onClick={handleClearAllParticipants}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs sm:text-sm font-medium rounded-xl transition-colors cursor-pointer"
                    title="Kosongkan semua data peserta"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Kosongkan Peserta</span>
                  </button>
                </>
              )}
            </>
          )}
        </div>
      </div>

      {/* 4 Summary Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Pegawai</p>
            <p className="text-2xl font-bold text-slate-900 mt-0.5">{stats.total}</p>
            <p className="text-[11px] text-slate-500">Terdaftar di master</p>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Pegawai Aktif</p>
            <p className="text-2xl font-bold text-emerald-700 mt-0.5">{stats.active}</p>
            <p className="text-[11px] text-emerald-600">Wajib absen harian</p>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500 shrink-0">
            <XCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Nonaktif / Purna</p>
            <p className="text-2xl font-bold text-slate-700 mt-0.5">{stats.inactive}</p>
            <p className="text-[11px] text-slate-400">Bebas denda absensi</p>
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 shrink-0">
            <Building className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Unit / Departemen</p>
            <p className="text-2xl font-bold text-sky-700 mt-0.5">{stats.departments}</p>
            <p className="text-[11px] text-sky-600">Terbuka & Dinamis</p>
          </div>
        </div>
      </div>

      {/* Filter Toolbar with Multi-Attribute Search & Quick Presets */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        {/* Quick Filter Presets Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 shrink-0 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-emerald-600" /> Filter Cepat:
          </span>
          <button
            onClick={() => { setStatusFilter(''); setEmploymentStatusFilter(''); }}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 cursor-pointer ${
              statusFilter === '' && employmentStatusFilter === ''
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua ({stats.total})
          </button>
          <button
            onClick={() => setStatusFilter(statusFilter === '1' ? '' : '1')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              statusFilter === '1'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200/60'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
            Aktif ({stats.active})
          </button>
          <button
            onClick={() => setStatusFilter(statusFilter === '0' ? '' : '0')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer ${
              statusFilter === '0'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
            Nonaktif ({stats.inactive})
          </button>
          <button
            onClick={() => setEmploymentStatusFilter(employmentStatusFilter === 'PNS' ? '' : 'PNS')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 cursor-pointer ${
              employmentStatusFilter === 'PNS'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200/60'
            }`}
          >
            PNS / ASN ({countPNS})
          </button>
          <button
            onClick={() => setEmploymentStatusFilter(employmentStatusFilter === 'PPPK' ? '' : 'PPPK')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 cursor-pointer ${
              employmentStatusFilter === 'PPPK'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200/60'
            }`}
          >
            PPPK ({countPPPK})
          </button>
          <button
            onClick={() => setEmploymentStatusFilter(employmentStatusFilter === 'Honorer' ? '' : 'Honorer')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 cursor-pointer ${
              employmentStatusFilter === 'Honorer'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200/60'
            }`}
          >
            Non-ASN / Honorer ({countNonASN})
          </button>
          {activeFilterCount > 0 && (
            <button
              onClick={handleResetFilters}
              className="ml-auto text-xs font-semibold text-rose-600 hover:text-rose-700 hover:underline shrink-0 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Filter ({activeFilterCount})
            </button>
          )}
        </div>

        {/* Detailed Filter Inputs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari Nama, NIP, Kode, atau Jabatan..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                title="Hapus pencarian"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Department Filter (Dynamic) */}
          <div>
            <select
              value={deptFilter}
              onChange={e => setDeptFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">Semua Unit / Departemen ({dynamicDepartments.length})</option>
              {dynamicDepartments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Position Filter (Dynamic) */}
          <div>
            <select
              value={positionFilter}
              onChange={e => setPositionFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">Semua Jabatan ({dynamicPositions.length})</option>
              {dynamicPositions.map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          {/* Employment Status Filter */}
          <div>
            <select
              value={employmentStatusFilter}
              onChange={e => setEmploymentStatusFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="">Semua Status Kepegawaian</option>
              {dynamicEmploymentStatuses.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {/* Sort By & Quick Reset */}
          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              <option value="name_asc">Nama (A - Z)</option>
              <option value="name_desc">Nama (Z - A)</option>
              <option value="code_asc">Kode Mesin (Asc)</option>
              <option value="code_desc">Kode Mesin (Desc)</option>
              <option value="dept">Unit / Departemen</option>
              <option value="newest">Terdaftar Terbaru</option>
            </select>

            <button
              onClick={handleResetFilters}
              className={`p-2 border rounded-xl transition-colors shrink-0 cursor-pointer ${
                activeFilterCount > 0
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                  : 'border-slate-200 hover:bg-slate-50 text-slate-500'
              }`}
              title="Reset Semua Filter"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Bulk Selection Bar (When 1 or more employees are checked) */}
        {isOperator && selectedIds.length > 0 && (
          <div className="bg-emerald-50/90 border-b border-emerald-200 p-3.5 px-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 animate-in fade-in slide-in-from-top-1 duration-150">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs">
                {selectedIds.length}
              </span>
              <span className="text-xs sm:text-sm font-semibold text-emerald-950">
                <strong>{selectedIds.length}</strong> pegawai dipilih
              </span>
              <div className="flex items-center gap-2 text-xs">
                {selectedIds.length < filteredList.length && (
                  <button
                    onClick={handleSelectAll}
                    className="font-medium text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                  >
                    Pilih semua hasil filter ({filteredList.length})
                  </button>
                )}
                {selectedIds.length < employees.length && (
                  <button
                    onClick={handleSelectAllGlobal}
                    className="font-medium text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                  >
                    Pilih seluruh database ({employees.length})
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap w-full md:w-auto justify-end">
              <button
                onClick={() => handleBulkToggleActive(true)}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100 text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                title="Aktifkan pegawai terpilih"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Aktifkan</span>
              </button>

              <button
                onClick={() => handleBulkToggleActive(false)}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                title="Nonaktifkan pegawai terpilih"
              >
                <XCircle className="w-3.5 h-3.5 text-slate-500" />
                <span>Nonaktifkan</span>
              </button>

              <button
                onClick={handleExportSelected}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                title="Export data pegawai terpilih ke Excel"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Export ({selectedIds.length})</span>
              </button>

              <button
                onClick={handleOpenBulkDelete}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
                title="Hapus massal pegawai yang dipilih"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Terpilih ({selectedIds.length})</span>
              </button>

              <button
                onClick={handleClearSelection}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-slate-500 hover:text-slate-800 hover:bg-emerald-100/60 rounded-xl text-xs font-medium transition-colors cursor-pointer"
                title="Batalkan semua pilihan"
              >
                <X className="w-3.5 h-3.5" />
                <span>Batal</span>
              </button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                {isOperator && (
                  <th className="py-3.5 px-3 w-10 text-center">
                    <input
                      ref={headerCheckboxRef}
                      type="checkbox"
                      checked={isAllFilteredSelected}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                      title={isAllFilteredSelected ? "Batal Pilih Semua" : `Pilih Semua (${filteredList.length})`}
                    />
                  </th>
                )}
                <th className="py-3.5 px-3 w-12 text-center">No</th>
                <th className="py-3.5 px-4">Pegawai</th>
                <th className="py-3.5 px-4">Kode Mesin / NIP</th>
                <th className="py-3.5 px-4">Unit / Departemen</th>
                <th className="py-3.5 px-4">Jabatan</th>
                <th className="py-3.5 px-4">Status Kerja</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-center w-36">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={isOperator ? 9 : 8} className="py-14 text-center text-slate-400">
                    {employees.length === 0 ? (
                      <div className="max-w-md mx-auto space-y-4 px-4">
                        <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100 shadow-xs">
                          <Upload className="w-8 h-8" />
                        </div>
                        <div>
                          <h4 className="text-base font-bold text-slate-800">
                            Belum Ada Data Peserta
                          </h4>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            Peserta dummy telah dihapus. Silakan unggah file peserta Anda dalam format Excel (.xlsx) atau CSV (.csv) untuk mulai mengolah data absensi.
                          </p>
                        </div>
                        <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
                          <button
                            onClick={() => setIsUploadModalOpen(true)}
                            className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
                          >
                            <Upload className="w-4 h-4" />
                            <span>Upload Berkas Peserta (.xlsx / .csv)</span>
                          </button>
                          <button
                            onClick={handleOpenCreate}
                            className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-xl transition-colors"
                          >
                            <UserPlus className="w-4 h-4" />
                            <span>Tambah Manual</span>
                          </button>
                          <button
                            onClick={downloadParticipantTemplateExcel}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-xl transition-colors"
                          >
                            <Download className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Unduh Template</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <Users className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                        <p className="font-semibold text-slate-700">Tidak ada data pegawai yang sesuai</p>
                        <p className="text-xs text-slate-400 mt-1">Coba sesuaikan kata kunci pencarian atau filter departemen.</p>
                        {activeFilterCount > 0 && (
                          <button
                            onClick={handleResetFilters}
                            className="mt-3 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            Reset Semua Filter
                          </button>
                        )}
                      </>
                    )}
                  </td>
                </tr>
              ) : (
                filteredList.map((emp, idx) => {
                  const isSelected = selectedIds.includes(emp.id);
                  return (
                    <tr
                      key={emp.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isSelected
                          ? 'bg-emerald-50/60 border-l-4 border-l-emerald-600'
                          : !emp.is_active
                          ? 'bg-slate-50/50 text-slate-400'
                          : ''
                      }`}
                    >
                      {isOperator && (
                        <td className="py-3.5 px-3 text-center" onClick={e => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelect(emp.id)}
                            className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                          />
                        </td>
                      )}

                      <td className="py-3.5 px-3 text-center font-mono text-xs text-slate-400">
                        {idx + 1}
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-900">
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-full border flex items-center justify-center font-bold text-xs uppercase shrink-0 ${
                            isSelected
                              ? 'bg-emerald-100 border-emerald-300 text-emerald-800'
                              : 'bg-slate-100 border-slate-200 text-slate-700'
                          }`}>
                            {emp.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                          </div>
                          <div>
                            <button
                              onClick={() => setViewingEmployee(emp)}
                              className="font-semibold text-slate-900 hover:text-emerald-600 transition-colors text-left cursor-pointer"
                            >
                              {emp.name}
                            </button>
                            <p className="text-[11px] text-slate-400">ID: #{emp.id}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                          {emp.employee_code}
                        </span>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {emp.nip || '-'}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 inline-flex items-center gap-1.5">
                          <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          {emp.department}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 text-xs">
                        <span className="inline-flex items-center gap-1">
                          <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          {emp.position}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        {renderStatusBadge(emp.employment_status)}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {emp.is_active ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                            Aktif
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                            Nonaktif
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => setViewingEmployee(emp)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors cursor-pointer"
                            title="Lihat Detail Profil & Absensi"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {isOperator && (
                            <>
                              <button
                                onClick={() => handleOpenEdit(emp)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors cursor-pointer"
                                title="Edit Data Pegawai (Fleksibel)"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => handleToggleStatus(emp)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                                title={emp.is_active ? 'Nonaktifkan Pegawai' : 'Aktifkan Pegawai'}
                              >
                                {emp.is_active ? <XCircle className="w-4 h-4 text-amber-500" /> : <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                              </button>

                              <button
                                onClick={() => handleDelete(emp)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Hapus (Soft Delete)"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Menampilkan <strong>{filteredList.length}</strong> dari <strong>{employees.length}</strong> pegawai
            {selectedIds.length > 0 && (
              <strong className="text-emerald-700 ml-2">({selectedIds.length} dipilih)</strong>
            )}
          </span>
          <div className="flex items-center gap-3">
            {isOperator && (
              <button
                onClick={handleSelectAll}
                className="text-xs font-medium text-slate-700 hover:text-emerald-700 hover:underline cursor-pointer"
              >
                {isAllFilteredSelected ? 'Batal Pilih Semua' : `Pilih Semua yang Tampil (${filteredList.length})`}
              </button>
            )}
            <span className="font-mono text-[11px] text-slate-400">Unit, Jabatan & Status bersifat Fleksibel</span>
          </div>
        </div>
      </div>

      {/* Floating Bottom Quick-Action Bar for Bulk Actions */}
      {isOperator && selectedIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-slate-800 flex items-center gap-3.5 backdrop-blur-md animate-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-2 pr-3 border-r border-slate-700 text-xs font-semibold">
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[11px]">
              {selectedIds.length}
            </span>
            <span>Pegawai Terpilih</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenBulkDelete}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus ({selectedIds.length})</span>
            </button>
            <button
              onClick={() => handleBulkToggleActive(true)}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Aktifkan</span>
            </button>
            <button
              onClick={() => handleBulkToggleActive(false)}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5 text-slate-400" />
              <span>Nonaktifkan</span>
            </button>
            <button
              onClick={handleClearSelection}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Batal Pilihan"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODAL: KONFIRMASI HAPUS (SINGLE & BULK DELETE DENGAN AUDIT TRAIL) */}
      {deleteModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-slate-900">
                  {deleteModal.type === 'bulk'
                    ? `Hapus ${selectedIds.length} Pegawai Terpilih?`
                    : `Hapus Pegawai '${deleteModal.targetEmployee?.name}'?`}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Konfirmasi tindakan penghapusan data pegawai (Soft Delete) dari sistem absensi.
                </p>
              </div>
              <button
                onClick={() => setDeleteModal({ isOpen: false, type: 'bulk' })}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {deleteModal.type === 'bulk' ? (
              <div className="space-y-3">
                <div className="bg-rose-50/70 border border-rose-200 p-3.5 rounded-xl text-xs text-rose-800 space-y-1">
                  <p className="font-semibold flex items-center gap-1.5 text-rose-900">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    Perhatian: Tindakan Berskala Massal
                  </p>
                  <p>
                    Sebanyak <strong>{selectedIds.length}</strong> data pegawai akan dihapus secara <em>Soft Delete</em>. Data historis absensi tetap tersimpan dan tindakan ini dicatat otomatis dalam <strong>audit_logs</strong>.
                  </p>
                </div>

                <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 max-h-48 overflow-y-auto space-y-1.5">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Daftar Pegawai yang Akan Dihapus ({selectedIds.length}):
                  </p>
                  {employees.filter(e => selectedIds.includes(e.id)).map(e => (
                    <div key={e.id} className="flex items-center justify-between text-xs bg-white p-2 rounded-lg border border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded text-[11px]">
                          {e.employee_code}
                        </span>
                        <span className="font-semibold text-slate-900">{e.name}</span>
                      </div>
                      <span className="text-[11px] text-slate-500">{e.department}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Nama Pegawai:</span>
                    <strong className="text-slate-900">{deleteModal.targetEmployee?.name}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Kode Pegawai / NIP:</span>
                    <span className="font-mono text-slate-800 font-semibold">
                      {deleteModal.targetEmployee?.employee_code} / {deleteModal.targetEmployee?.nip || '-'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Unit / Departemen:</span>
                    <span className="text-slate-800">{deleteModal.targetEmployee?.department}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Jabatan:</span>
                    <span className="text-slate-800">{deleteModal.targetEmployee?.position}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-500">
                  Penghapusan ini bersifat <strong>Soft Delete</strong>. Data dapat dipulihkan kapan saja oleh Superadmin melalui menu Log Audit.
                </p>
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDeleteModal({ isOpen: false, type: 'bulk' })}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>
                  {deleteModal.type === 'bulk'
                    ? `Ya, Hapus ${selectedIds.length} Pegawai`
                    : 'Ya, Hapus Pegawai Ini'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT EMPLOYEE WITH HIGH FLEXIBILITY */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  {editingEmployee ? <Edit3 className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {editingEmployee ? `Edit Data Pegawai: ${editingEmployee.name}` : 'Tambah Pegawai Baru'}
                  </h3>
                  <p className="text-[11px] text-slate-400">Unit, Jabatan, dan Status Pegawai dapat dipilih atau diketik manual secara bebas.</p>
                </div>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Kode Pegawai */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Kode Pegawai (ID Mesin) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.employee_code}
                    onChange={e => setFormData({ ...formData, employee_code: e.target.value })}
                    placeholder="Contoh: PEG001"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Harus unik, dipetakan ke log mesin absensi.</p>
                </div>

                {/* NIP */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    NIP (Nomor Induk Pegawai)
                  </label>
                  <input
                    type="text"
                    value={formData.nip}
                    onChange={e => setFormData({ ...formData, nip: e.target.value })}
                    placeholder="Contoh: 198503152010011002"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Opsional untuk non-PNS / swasta / honorer.</p>
                </div>

                {/* Nama Lengkap */}
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">
                    Nama Lengkap & Gelar <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Contoh: Dr. Budi Santoso, S.Kom., M.T."
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* UNIT / DEPARTEMEN FLEKSIBEL */}
                <div className="sm:col-span-2 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block font-semibold text-slate-800 flex items-center gap-1.5">
                      <Building className="w-4 h-4 text-emerald-600" />
                      Unit / Departemen / Divisi <span className="text-rose-500">*</span>
                    </label>

                    <button
                      type="button"
                      onClick={() => setIsCustomDept(!isCustomDept)}
                      className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>{isCustomDept ? 'Pilih dari Daftar Terdaftar' : '+ Ketik Unit / Seksi Baru'}</span>
                    </button>
                  </div>

                  {!isCustomDept ? (
                    <div>
                      <select
                        value={formData.department}
                        onChange={e => {
                          if (e.target.value === '__CUSTOM__') {
                            setIsCustomDept(true);
                            setFormData({ ...formData, department: '' });
                          } else {
                            setFormData({ ...formData, department: e.target.value });
                          }
                        }}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 bg-white text-xs sm:text-sm"
                      >
                        {dynamicDepartments.map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                        <option value="__CUSTOM__">+ Tambah / Ketik Unit Lainnya...</option>
                      </select>
                      <p className="text-[10px] text-slate-400 mt-1">Pilih dari unit kerja organisasi yang sudah ada, atau klik '+ Ketik Unit / Seksi Baru'.</p>
                    </div>
                  ) : (
                    <div>
                      <input
                        type="text"
                        required
                        value={formData.department}
                        onChange={e => setFormData({ ...formData, department: e.target.value })}
                        placeholder="Contoh: Seksi Pengawasan & Audit Internal / Biro Humas"
                        className="w-full px-3 py-2 border border-emerald-300 bg-white rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap mt-2">
                        <span className="text-[10px] text-slate-400">Rekomendasi Cepat:</span>
                        {DEFAULT_DEPARTMENTS.slice(0, 4).map(d => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setFormData({ ...formData, department: d })}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 cursor-pointer"
                          >
                            {d}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* JABATAN FLEKSIBEL */}
                <div className="sm:col-span-2 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block font-semibold text-slate-800 flex items-center gap-1.5">
                      <Briefcase className="w-4 h-4 text-emerald-600" />
                      Jabatan Pegawai <span className="text-rose-500">*</span>
                    </label>
                    <span className="text-[11px] text-slate-400">Ketik bebas atau pilih saran</span>
                  </div>

                  <input
                    type="text"
                    required
                    list="position-suggestions"
                    value={formData.position}
                    onChange={e => setFormData({ ...formData, position: e.target.value })}
                    placeholder="Contoh: Analis Kebijakan Ahli Muda, Kepala Seksi, Programmer, dll."
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm"
                  />

                  {/* Quick suggestion chips for Jabatan */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1">
                    <span className="text-[10px] text-slate-400">Pilih Preset Jabatan:</span>
                    {[
                      'Kepala Bagian',
                      'Kepala Subbagian',
                      'Analis SDM Aparatur',
                      'Pranata Komputer',
                      'Bendahara Pengeluaran',
                      'Pengadministrasi Perkantoran',
                      'Teknisi Jaringan',
                      'Tenaga Ahli Programmer',
                      'Staf Umum'
                    ].map(title => (
                      <button
                        key={title}
                        type="button"
                        onClick={() => setFormData({ ...formData, position: title })}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 hover:border-emerald-400 hover:text-emerald-700 transition-colors cursor-pointer"
                      >
                        {title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* STATUS KEPEGAWAIAN FLEKSIBEL */}
                <div className="sm:col-span-2 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block font-semibold text-slate-800 flex items-center gap-1.5">
                      <BadgeCheck className="w-4 h-4 text-emerald-600" />
                      Status Kepegawaian <span className="text-rose-500">*</span>
                    </label>

                    <button
                      type="button"
                      onClick={() => setIsCustomStatus(!isCustomStatus)}
                      className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{isCustomStatus ? 'Gunakan Opsi Standar' : 'Ketik Status Kustom'}</span>
                    </button>
                  </div>

                  {!isCustomStatus ? (
                    <div>
                      <select
                        value={formData.employment_status}
                        onChange={e => {
                          if (e.target.value === '__CUSTOM__') {
                            setIsCustomStatus(true);
                          } else {
                            setFormData({ ...formData, employment_status: e.target.value });
                          }
                        }}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 bg-white text-xs sm:text-sm"
                      >
                        {STANDARD_EMPLOYMENT_STATUSES.map(status => (
                          <option key={status.value} value={status.value}>{status.label}</option>
                        ))}
                        <option value="__CUSTOM__">Lainnya (Ketik Status Kustom Manual)...</option>
                      </select>
                      <p className="text-[10px] text-slate-400 mt-1">Mendukung PNS, PPPK, PPNPN, Honorer, Karyawan Tetap, Kontrak, Tenaga Ahli, dan status kustom.</p>
                    </div>
                  ) : (
                    <div>
                      <input
                        type="text"
                        required
                        value={formData.custom_status_text}
                        onChange={e => setFormData({ ...formData, custom_status_text: e.target.value })}
                        placeholder="Ketik status kepegawaian, misal: Dokter Tamu, Pekerja Harian, Tenaga Pendukung..."
                        className="w-full px-3 py-2 border border-emerald-300 bg-white rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap mt-2">
                        <span className="text-[10px] text-slate-400">Pilihan Cepat:</span>
                        {['PPNPN', 'Honorer / THL', 'Tenaga Ahli', 'Outsourcing', 'Part-time'].map(st => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setFormData({ ...formData, custom_status_text: st })}
                            className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 cursor-pointer"
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Status Keaktifan (is_active) */}
                <div className="sm:col-span-2 p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-800 block text-xs sm:text-sm">Status Keaktifan Kerja</span>
                    <p className="text-[11px] text-slate-400">Pegawai aktif akan diproses kalkulasi absensi dan denda keterlambatan harian.</p>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={formData.is_active}
                      onChange={e => setFormData({ ...formData, is_active: e.target.checked })}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                    />
                    <span className={`text-xs font-bold ${formData.is_active ? 'text-emerald-700' : 'text-slate-400'}`}>
                      {formData.is_active ? 'Pegawai Aktif' : 'Nonaktif / Pensiun'}
                    </span>
                  </label>
                </div>
              </div>

              {/* Form Action Buttons */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium rounded-xl transition-colors cursor-pointer text-xs sm:text-sm"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer text-xs sm:text-sm"
                >
                  {editingEmployee ? 'Simpan Perubahan' : 'Tambah Pegawai'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DETAIL VIEW EMPLOYEE */}
      {viewingEmployee && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 space-y-6 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-sm uppercase">
                  {viewingEmployee.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{viewingEmployee.name}</h3>
                  <p className="text-xs text-slate-500">{viewingEmployee.position} &bull; {viewingEmployee.department}</p>
                </div>
              </div>
              <button
                onClick={() => setViewingEmployee(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 5 Stats Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Hari Tercatat</p>
                <p className="text-lg font-bold text-slate-800 mt-0.5">{viewingEmployee.stats?.recorded || 22} Hari</p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <p className="text-[10px] font-bold text-emerald-700 uppercase">Tepat Waktu</p>
                <p className="text-lg font-bold text-emerald-700 mt-0.5">{viewingEmployee.stats?.onTime || 20} Hari</p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <p className="text-[10px] font-bold text-amber-700 uppercase">Terlambat</p>
                <p className="text-lg font-bold text-amber-700 mt-0.5">{viewingEmployee.stats?.late || 2} Kali</p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                <p className="text-[10px] font-bold text-purple-700 uppercase">Missing In/Out</p>
                <p className="text-lg font-bold text-purple-700 mt-0.5">{viewingEmployee.stats?.missing || 0} Hari</p>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200">
                <p className="text-[10px] font-bold text-rose-700 uppercase">Total Denda</p>
                <p className="text-base font-bold text-rose-700 mt-0.5">
                  Rp {(viewingEmployee.stats?.penalties || 0).toLocaleString('id-ID')}
                </p>
              </div>
            </div>

            {/* Information List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Kode Pegawai (ID Mesin):</span>
                <span className="font-mono font-bold text-slate-800 text-sm">{viewingEmployee.employee_code}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Nomor Induk Pegawai (NIP):</span>
                <span className="font-mono text-slate-800 text-sm">{viewingEmployee.nip || 'Non-ASN / Belum Terdaftar'}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Unit / Departemen:</span>
                <span className="font-bold text-slate-800 text-sm">{viewingEmployee.department}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Jabatan:</span>
                <span className="font-bold text-slate-800 text-sm">{viewingEmployee.position}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Status Kepegawaian:</span>
                <div>{renderStatusBadge(viewingEmployee.employment_status)}</div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                <span className="text-slate-400 block mb-1">Status Keaktifan:</span>
                <span className={`font-bold text-sm ${viewingEmployee.is_active ? 'text-emerald-600' : 'text-slate-400'}`}>
                  {viewingEmployee.is_active ? 'Aktif Bekerja (Wajib Absen)' : 'Nonaktif / Pensiun'}
                </span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setViewingEmployee(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Tutup Jendela Detail
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: REAL UPLOAD PARTICIPANTS (EXCEL & CSV) */}
      <UploadParticipantModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        existingEmployees={employees}
        onSuccess={(imported) => {
          setEmployees(imported);
          saveStoredEmployees(imported);
          showNotification(`Berhasil memuat ${imported.length} peserta ke sistem!`);
        }}
      />

    </div>
  );
};
