import React, { useState, useMemo, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  Database,
  UploadCloud,
  Calendar,
  CalendarRange,
  FileSpreadsheet,
  Receipt,
  SlidersHorizontal,
  ShieldCheck,
  UserCog,
  LogOut,
  Clock,
  Shield,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  TrendingDown,
  Building2,
  Code2,
  Copy,
  Check,
  Search,
  Filter,
  Info,
  ChevronRight,
  ExternalLink,
  Cpu,
  Layers,
  FileText
} from 'lucide-react';
import { SAMPLE_RAW_LOGS, EmployeeDailyRecord, RawAttendanceLog } from './data/mockData';
import { getStoredEmployees } from './data/participantStore';
import { LARAVEL_PHASE1_FILES, CodeFile } from './data/laravelCodeSnippets';
import { LARAVEL_PHASE2_FILES } from './data/laravelPhase2Files';
import { LARAVEL_PHASE3_FILES } from './data/laravelPhase3Files';
import { LARAVEL_PHASE4_FILES } from './data/laravelPhase4Files';
import { LARAVEL_PHASE6_FILES } from './data/laravelPhase6Files';
import { EmployeeManagement } from './components/EmployeeManagement';
import { RawAttendanceManagement } from './components/RawAttendanceManagement';
import { AttendanceImportModule } from './components/AttendanceImportModule';
import { WorkCalendarManagement } from './components/WorkCalendarManagement';
import { ReconciliationEngineModule } from './components/ReconciliationEngineModule';
import { MonthlyReportModule } from './components/MonthlyReportModule';
import { SupabaseManagerModule } from './components/SupabaseManagerModule';

export default function App() {
  // Navigation State (Active menu set to supabase when connected)
  const [activeMenu, setActiveMenu] = useState<'dashboard' | 'employees' | 'raw' | 'import' | 'calendar' | 'reconcile' | 'monthly-report' | 'settings' | 'code-explorer' | 'supabase'>('supabase');
  const [selectedRole, setSelectedRole] = useState<'admin' | 'operator' | 'viewer'>('admin');
  
  // Date State (Defaults to 2026-08-10 for workday, or 2026-08-17 for national holiday test)
  const [selectedDate, setSelectedDate] = useState<string>('2026-08-10');
  
  // Search and Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  
  // Code Explorer State
  const [codePhaseFilter, setCodePhaseFilter] = useState<'all' | 'phase1' | 'phase2' | 'phase3' | 'phase4' | 'phase6'>('phase6');
  
  const allCodeFiles = useMemo(() => {
    if (codePhaseFilter === 'phase1') return LARAVEL_PHASE1_FILES;
    if (codePhaseFilter === 'phase2') return LARAVEL_PHASE2_FILES;
    if (codePhaseFilter === 'phase3') return LARAVEL_PHASE3_FILES;
    if (codePhaseFilter === 'phase4') return LARAVEL_PHASE4_FILES;
    if (codePhaseFilter === 'phase6') return LARAVEL_PHASE6_FILES;
    return [...LARAVEL_PHASE1_FILES, ...LARAVEL_PHASE2_FILES, ...LARAVEL_PHASE3_FILES, ...LARAVEL_PHASE4_FILES, ...LARAVEL_PHASE6_FILES];
  }, [codePhaseFilter]);

  const [selectedCodeFile, setSelectedCodeFile] = useState<CodeFile>(LARAVEL_PHASE6_FILES[0]);
  const [copied, setCopied] = useState(false);

  // Determine Holiday vs Workday status
  const isHoliday = useMemo(() => {
    return selectedDate === '2026-08-17';
  }, [selectedDate]);

  const isWeekend = useMemo(() => {
    const d = new Date(selectedDate);
    return d.getDay() === 0 || d.getDay() === 6;
  }, [selectedDate]);

  const dayStatusText = useMemo(() => {
    if (selectedDate === '2026-08-17') {
      return 'HUT Kemerdekaan RI ke-81 (Libur Nasional - Denda Rp 0)';
    }
    if (isWeekend) {
      return 'Akhir Pekan (Sabtu/Minggu - Libur Reguler)';
    }
    const day = new Date(selectedDate).getDay();
    if (day === 5) {
      return 'Hari Kerja Reguler (Jumat: Masuk 08:15 WIB - Pulang 17:00 WIB)';
    }
    return 'Hari Kerja Reguler (Senin-Kamis: Masuk 08:15 WIB - Pulang 16:30 WIB)';
  }, [selectedDate, isWeekend]);

  // Copy code handler
  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filtered employees from dynamic participant storage
  const [storedEmployees, setStoredEmployees] = useState(() => getStoredEmployees());

  useEffect(() => {
    const handleUpdated = (e: any) => {
      if (e.detail && Array.isArray(e.detail)) {
        setStoredEmployees(e.detail);
      }
    };
    window.addEventListener('participants_updated', handleUpdated);
    return () => window.removeEventListener('participants_updated', handleUpdated);
  }, []);

  const liveEmployees = useMemo<EmployeeDailyRecord[]>(() => {
    if (!storedEmployees || storedEmployees.length === 0) return [];
    return storedEmployees.map((emp) => ({
      id: emp.id,
      code: emp.employee_code,
      nip: emp.nip || '-',
      name: emp.name,
      department: emp.department,
      firstIn: null,
      lastOut: null,
      status: 'BELUM SCAN',
      lateMinutes: 0,
      earlyMinutes: 0,
      penalty: 0,
      statusType: 'ontime'
    }));
  }, [storedEmployees]);

  const filteredEmployees = useMemo(() => {
    return liveEmployees.filter(emp => {
      const matchSearch = emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          emp.nip.includes(searchQuery) ||
                          emp.department.toLowerCase().includes(searchQuery.toLowerCase());
      const matchStatus = statusFilter === 'ALL' || emp.status.includes(statusFilter);
      return matchSearch && matchStatus;
    });
  }, [liveEmployees, searchQuery, statusFilter]);

  // Statistics Calculation
  const stats = useMemo(() => {
    const total = storedEmployees.length;
    if (total === 0) {
      return {
        total: 0,
        onTime: 0,
        late: 0,
        early: 0,
        missingIn: 0,
        missingOut: 0,
        absent: 0,
        holiday: 0,
        totalPenalty: 0
      };
    }
    if (isHoliday || isWeekend) {
      return {
        total: total,
        onTime: 0,
        late: 0,
        early: 0,
        missingIn: 0,
        missingOut: 0,
        absent: 0,
        holiday: total,
        totalPenalty: 0
      };
    }
    return {
      total: total,
      onTime: total,
      late: 0,
      early: 0,
      missingIn: 0,
      missingOut: 0,
      absent: 0,
      holiday: 0,
      totalPenalty: 0
    };
  }, [storedEmployees.length, isHoliday, isWeekend]);

  return (
    <div className="min-h-screen bg-slate-100 flex font-sans text-slate-800 antialiased selection:bg-emerald-500 selection:text-white">
      
      {/* SIDEBAR NAVIGATION */}
      <aside className="w-64 bg-slate-900 text-slate-300 border-r border-slate-800 flex flex-col shrink-0 fixed inset-y-0 z-30">
        {/* Brand Header */}
        <div className="h-16 flex items-center px-5 bg-slate-950 border-b border-slate-800/80 gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 font-bold">
            <Clock className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-sm tracking-tight text-white">SIM-ABSENSI</span>
            <span className="text-[10px] text-emerald-400 font-medium tracking-wide">Laravel 11 &bull; Phase 1</span>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          
          {/* Main Section */}
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Menu Utama
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveMenu('dashboard')}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-all ${
                  activeMenu === 'dashboard'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Dashboard Absensi</span>
              </button>

              <button
                onClick={() => setActiveMenu('code-explorer')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-xl transition-all ${
                  activeMenu === 'code-explorer'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  <span>Kode Laravel (P1-P3)</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {LARAVEL_PHASE1_FILES.length + LARAVEL_PHASE2_FILES.length + LARAVEL_PHASE3_FILES.length} Files
                </span>
              </button>
            </nav>
          </div>

          {/* Attendance Processing Section */}
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Data & Pengolahan Absensi
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveMenu('employees')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'employees'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Users className="w-4 h-4" />
                  <span>Data Pegawai</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">Aktif</span>
              </button>

              <button
                onClick={() => setActiveMenu('raw')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'raw'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Database className="w-4 h-4" />
                  <span>Data Absensi Mentah</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">Aktif</span>
              </button>

              <button
                onClick={() => setActiveMenu('import')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'import'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <UploadCloud className="w-4 h-4" />
                  <span>Import Data Absensi</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">Aktif</span>
              </button>

              <button
                onClick={() => setActiveMenu('calendar')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'calendar'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CalendarRange className="w-4 h-4" />
                  <span>Kalender Kerja & Libur</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold">Aktif</span>
              </button>

              <button
                onClick={() => setActiveMenu('reconcile')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'reconcile'
                    ? 'bg-indigo-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Cpu className="w-4 h-4" />
                  <span>Engine Rekonsiliasi & Denda</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">Phase 6</span>
              </button>
            </nav>
          </div>

          {/* Reports */}
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Laporan & Rekap
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveMenu('monthly-report')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'monthly-report'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Rekap Bulanan Tukin</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">Phase 7</span>
              </button>

              <button
                onClick={() => setActiveMenu('monthly-report')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'monthly-report'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Receipt className="w-4 h-4" />
                  <span>Slip Potongan Denda</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">Phase 8</span>
              </button>
            </nav>
          </div>

          {/* System & Settings */}
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Sistem
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => setActiveMenu('settings')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'settings'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <SlidersHorizontal className="w-4 h-4" />
                  <span>Pengaturan Jam & Denda</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Phase 1</span>
              </button>

              <button
                onClick={() => setActiveMenu('supabase')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xl transition-all ${
                  activeMenu === 'supabase'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Database className="w-4 h-4 text-emerald-400" />
                  <span>Database Supabase</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Live
                </span>
              </button>

              <div className="flex items-center justify-between px-3 py-2 text-xs text-slate-400 rounded-xl opacity-80 cursor-not-allowed">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Audit Log Aktivitas</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Phase 9</span>
              </div>
            </nav>
          </div>

        </div>

        {/* User Card & Role Switcher */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-xs text-white">
                  AD
                </div>
                <div className="flex flex-col truncate">
                  <span className="text-xs font-semibold text-white truncate">Administrator</span>
                  <span className="text-[10px] text-emerald-400 capitalize">Biro Kepegawaian</span>
                </div>
              </div>
            </div>

            {/* Interactive Role Switch Simulator */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="text-[9px] font-semibold uppercase tracking-wider text-slate-500 block mb-1">
                Simulasi Peran (RBAC):
              </label>
              <div className="grid grid-cols-3 gap-1">
                {(['admin', 'operator', 'viewer'] as const).map(role => (
                  <button
                    key={role}
                    onClick={() => setSelectedRole(role)}
                    className={`text-[10px] py-1 rounded font-semibold uppercase transition-all ${
                      selectedRole === role
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 ml-64 flex flex-col min-w-0">
        
        {/* TOP NAVBAR */}
        <header className="h-16 bg-white border-b border-slate-200/80 sticky top-0 z-20 px-6 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <h1 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Sistem Pengelola Data Absensi Karyawan
            </h1>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
              WIB (Asia/Jakarta)
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveMenu('supabase')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold text-emerald-800 transition-colors shadow-xs"
              title="Koneksi Supabase Aktif: vwzzhkbivgsptcldodor.supabase.co"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <Database className="w-3.5 h-3.5 text-emerald-700" />
              <span>Supabase Terhubung</span>
            </button>

            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-600">
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              <span>Senin, 10 Agustus 2026 - 16:45 WIB</span>
            </div>

            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700">
              <Shield className="w-3.5 h-3.5 text-indigo-600" />
              <span className="uppercase">{selectedRole}</span>
            </div>

            <button 
              onClick={() => {
                setCodePhaseFilter('phase3');
                setSelectedCodeFile(LARAVEL_PHASE3_FILES[0]);
                setActiveMenu('code-explorer');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <Code2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Lihat Arsitektur Laravel Phase 3</span>
            </button>
          </div>
        </header>

        {/* BODY CONTENT */}
        <main className="flex-1 p-6 overflow-y-auto space-y-6">

          {/* PHASE 1 COMPLETION ALERT BANNER */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-900 via-slate-900 to-slate-900 text-white border border-emerald-500/30 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">PHASE 1 BERHASIL DIBANGUN</span>
                  <span className="px-2 py-0.2 rounded-full text-[10px] font-semibold bg-emerald-500 text-slate-950">
                    Selesai & Siap
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  Struktur Database, 12 Tabel Migration, Eloquent Models, Seeder (User, Jam Kerja, Setting), Layout Blade, Sidebar, Dashboard, dan Routes telah selesai diarsiteki.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setActiveMenu('code-explorer')}
                className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Layers className="w-4 h-4" />
                <span>Eksplorasi File Laravel (12 File)</span>
              </button>
            </div>
          </div>

          {/* VIEW: DASHBOARD */}
          {activeMenu === 'dashboard' && (
            <div className="space-y-6">

              {/* DATE PICKER & SIMULATOR CONTROLS */}
              <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-emerald-600">Pusat Monitoring Absensi</span>
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
                    Monitoring Status Absensi Harian
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Simulasikan tanggal kerja reguler atau tanggal libur nasional (contoh: 17 Agustus 2026).
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <label htmlFor="date-input" className="text-xs font-medium text-slate-600">Pilih Tanggal:</label>
                    <input
                      type="date"
                      id="date-input"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="bg-transparent text-xs font-bold text-slate-900 focus:outline-hidden cursor-pointer"
                    />
                  </div>

                  <button
                    onClick={() => setSelectedDate('2026-08-10')}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                      selectedDate === '2026-08-10'
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Uji Hari Kerja (10 Ags)
                  </button>

                  <button
                    onClick={() => setSelectedDate('2026-08-17')}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                      selectedDate === '2026-08-17'
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                    }`}
                  >
                    Uji Libur RI (17 Ags)
                  </button>
                </div>
              </div>

              {/* CALENDAR STATUS & RULES MATRIX BANNER */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                
                {/* Status Kalender Kerja Card */}
                <div className={`rounded-2xl p-5 shadow-xs flex flex-col justify-between border ${
                  isHoliday 
                    ? 'bg-gradient-to-br from-rose-950 via-slate-900 to-slate-900 border-rose-800 text-white' 
                    : 'bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 border-slate-800 text-white'
                }`}>
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                        <CalendarRange className="w-4 h-4" />
                        Status Kalender Kerja
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        isHoliday || isWeekend
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        {isHoliday ? 'LIBUR NASIONAL' : (isWeekend ? 'AKHIR PEKAN' : 'HARI KERJA')}
                      </span>
                    </div>

                    <div className="mt-4">
                      <div className="text-2xl font-black text-white">
                        {new Date(selectedDate).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                      </div>
                      <p className="text-xs text-slate-300 mt-1 font-medium">
                        {dayStatusText}
                      </p>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[11px]">Jam Masuk Seharusnya:</span>
                      <span className="font-bold text-emerald-400 text-sm">
                        {isHoliday || isWeekend ? 'Libur (Tidak Ada)' : '08:15 WIB'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Jam Pulang Seharusnya:</span>
                      <span className="font-bold text-emerald-400 text-sm">
                        {isHoliday || isWeekend ? 'Libur (Tidak Ada)' : '16:30 WIB'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Aturan Jam Kerja & Denda Card */}
                <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-emerald-600" />
                      Matriks Aturan Jam Kerja & Potongan Kepegawaian (WIB)
                    </h3>
                    <span className="text-[11px] font-medium text-slate-500">Konfigurasi Aktif</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 my-2">
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[11px] font-medium text-slate-500">Terlambat &le; 1 Jam</div>
                      <div className="text-sm font-bold text-amber-600 mt-0.5">Rp 7.500</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">&gt; 08:15 s/d 09:15</div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[11px] font-medium text-slate-500">Terlambat &gt; 1 Jam</div>
                      <div className="text-sm font-bold text-rose-600 mt-0.5">Rp 10.000</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">&gt; 09:15 WIB</div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[11px] font-medium text-slate-500">Pulang Cepat</div>
                      <div className="text-sm font-bold text-orange-600 mt-0.5">Rp 10.000</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">&lt; Jam Pulang</div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[11px] font-medium text-slate-500">Missing In / Out</div>
                      <div className="text-sm font-bold text-purple-600 mt-0.5">Rp 10.000</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Hanya 1 transaksi</div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[11px] font-medium text-slate-500">Tidak Hadir Kerja</div>
                      <div className="text-sm font-bold text-red-700 mt-0.5">Rp 20.000</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Hari kerja tanpa absen</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-600 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100">
                    <span className="flex items-center gap-1.5 text-emerald-900 font-medium">
                      <Info className="w-4 h-4 text-emerald-600 shrink-0" />
                      <strong>Prinsip Inti:</strong> Kalender kerja dievaluasi terlebih dahulu sebelum menghitung alpha. Pada hari libur nasional, potongan = <strong>Rp 0</strong>.
                    </span>
                    <button onClick={() => setActiveMenu('settings')} className="text-emerald-700 font-semibold hover:underline shrink-0">
                      Ubah Setting &rarr;
                    </button>
                  </div>
                </div>

              </div>

              {/* 8 STATISTIC KPI CARDS */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3">
                
                {/* 1. Total Pegawai */}
                <div className="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-xs">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Total Pegawai</span>
                  <div className="text-2xl font-bold text-slate-900 mt-1">{stats.total}</div>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">Pegawai Terdaftar</span>
                </div>

                {/* 2. Hadir Tepat Waktu */}
                <div className="bg-white rounded-xl p-3.5 border border-emerald-200 bg-emerald-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">Tepat Waktu</span>
                  <div className="text-2xl font-bold text-emerald-600 mt-1">{stats.onTime}</div>
                  <span className="text-[10px] text-emerald-600 font-medium mt-0.5 block">&le; 08:15 (Rp 0)</span>
                </div>

                {/* 3. Terlambat */}
                <div className="bg-white rounded-xl p-3.5 border border-amber-200 bg-amber-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">Terlambat</span>
                  <div className="text-2xl font-bold text-amber-600 mt-1">{stats.late}</div>
                  <span className="text-[10px] text-amber-600 font-medium mt-0.5 block">&le;1h & &gt;1h</span>
                </div>

                {/* 4. Pulang Cepat */}
                <div className="bg-white rounded-xl p-3.5 border border-orange-200 bg-orange-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-orange-700 uppercase tracking-wider block">Pulang Cepat</span>
                  <div className="text-2xl font-bold text-orange-600 mt-1">{stats.early}</div>
                  <span className="text-[10px] text-orange-600 font-medium mt-0.5 block">&lt; 16:30 WIB</span>
                </div>

                {/* 5. Tidak Absen Masuk */}
                <div className="bg-white rounded-xl p-3.5 border border-purple-200 bg-purple-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider block">Tanpa Masuk</span>
                  <div className="text-2xl font-bold text-purple-600 mt-1">{stats.missingIn}</div>
                  <span className="text-[10px] text-purple-600 font-medium mt-0.5 block">Hanya Ada Pulang</span>
                </div>

                {/* 6. Tidak Absen Pulang */}
                <div className="bg-white rounded-xl p-3.5 border border-indigo-200 bg-indigo-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider block">Tanpa Pulang</span>
                  <div className="text-2xl font-bold text-indigo-600 mt-1">{stats.missingOut}</div>
                  <span className="text-[10px] text-indigo-600 font-medium mt-0.5 block">Hanya Ada Masuk</span>
                </div>

                {/* 7. Tidak Hadir / Alpha */}
                <div className="bg-white rounded-xl p-3.5 border border-rose-200 bg-rose-50/20 shadow-xs">
                  <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">Tidak Hadir</span>
                  <div className="text-2xl font-bold text-rose-600 mt-1">{stats.absent}</div>
                  <span className="text-[10px] text-rose-600 font-medium mt-0.5 block">Denda Rp 20.000</span>
                </div>

                {/* 8. Total Potongan */}
                <div className="bg-white rounded-xl p-3.5 border border-red-300 bg-red-50/30 shadow-xs">
                  <span className="text-[10px] font-bold text-red-700 uppercase tracking-wider block">Total Potongan</span>
                  <div className="text-base font-black text-red-700 mt-1 truncate">
                    Rp {stats.totalPenalty.toLocaleString('id-ID')}
                  </div>
                  <span className="text-[10px] text-red-600 font-medium mt-0.5 block">
                    {isHoliday ? 'Hari Libur (Rp 0)' : 'Denda Terkumpul'}
                  </span>
                </div>

              </div>

              {/* DATA TABLE & RECENT RAW LOGS */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Employee Daily Calculated Table */}
                <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col">
                  <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">Rekapitulasi Absensi Harian Pegawai</h3>
                      <p className="text-xs text-slate-500">Hasil kalkulasi AttendanceCalculationService pada tanggal terpilih</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          placeholder="Cari nama / NIP..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-emerald-500 w-44"
                        />
                      </div>

                      <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 font-medium text-slate-700 focus:outline-hidden"
                      >
                        <option value="ALL">Semua Status</option>
                        <option value="HADIR TEPAT WAKTU">Tepat Waktu</option>
                        <option value="TERLAMBAT">Terlambat</option>
                        <option value="PULANG CEPAT">Pulang Cepat</option>
                        <option value="TIDAK ABSEN">Tidak Absen</option>
                      </select>
                    </div>
                  </div>

                  <div className="overflow-x-auto flex-1">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-100">
                        <tr>
                          <th className="px-4 py-3">Pegawai</th>
                          <th className="px-3 py-3">Masuk</th>
                          <th className="px-3 py-3">Pulang</th>
                          <th className="px-4 py-3">Status Kehadiran</th>
                          <th className="px-4 py-3 text-right">Potongan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {isHoliday ? (
                          <tr>
                            <td colSpan={5} className="px-4 py-12 text-center text-slate-500">
                              <div className="flex flex-col items-center justify-center gap-2">
                                <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
                                  <Calendar className="w-5 h-5" />
                                </div>
                                <span className="font-bold text-slate-800 text-sm">Tanggal Ini Adalah Libur Nasional (17 Agustus 2026)</span>
                                <span className="text-xs text-slate-400 max-w-md">
                                  Seluruh pegawai dibebaskan dari kewajiban absensi. Sesuai aturan spesifikasi (No. 9 & 10), potongan bernilai <strong>Rp 0</strong> dan tidak dianggap alpha.
                                </span>
                              </div>
                            </td>
                          </tr>
                        ) : filteredEmployees.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-4 py-12 text-center text-slate-400">
                              <div className="flex flex-col items-center justify-center gap-2 max-w-md mx-auto">
                                <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-1">
                                  <Users className="w-6 h-6" />
                                </div>
                                <span className="font-bold text-slate-800 text-sm">
                                  {storedEmployees.length === 0 ? 'Data Peserta Belum Diunggah' : 'Tidak Ada Data yang Cocok'}
                                </span>
                                <p className="text-xs text-slate-500 leading-relaxed">
                                  {storedEmployees.length === 0
                                    ? 'Data dummy peserta telah dibersihkan. Silakan unggah berkas peserta Anda dalam format Excel (.xlsx) atau CSV (.csv) di menu Manajemen Pegawai.'
                                    : 'Coba sesuaikan kata kunci pencarian Anda.'}
                                </p>
                                {storedEmployees.length === 0 && (
                                  <button
                                    onClick={() => setActiveMenu('employees')}
                                    className="mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer"
                                  >
                                    <Users className="w-4 h-4" />
                                    <span>Buka Modul Manajemen Pegawai &rarr;</span>
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ) : (
                          filteredEmployees.map((emp) => (
                            <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="px-4 py-3">
                                <div className="font-semibold text-slate-900">{emp.name}</div>
                                <div className="text-[11px] text-slate-400 flex items-center gap-1.5 font-mono">
                                  <span>{emp.nip}</span> &bull; <span>{emp.department}</span>
                                </div>
                              </td>
                              <td className="px-3 py-3 font-mono font-medium">
                                {emp.firstIn ? (
                                  <span className={emp.lateMinutes > 0 ? 'text-amber-600 font-bold' : 'text-slate-800'}>
                                    {emp.firstIn} WIB
                                    {emp.lateMinutes > 0 && (
                                      <span className="block text-[10px] text-amber-500 font-normal">
                                        +{emp.lateMinutes}m
                                      </span>
                                    )}
                                  </span>
                                ) : (
                                  <span className="text-slate-400 italic">-</span>
                                )}
                              </td>
                              <td className="px-3 py-3 font-mono font-medium">
                                {emp.lastOut ? (
                                  <span className={emp.earlyMinutes > 0 ? 'text-orange-600 font-bold' : 'text-slate-800'}>
                                    {emp.lastOut} WIB
                                    {emp.earlyMinutes > 0 && (
                                      <span className="block text-[10px] text-orange-500 font-normal">
                                        -{emp.earlyMinutes}m
                                      </span>
                                    )}
                                  </span>
                                ) : (
                                  <span className="text-slate-400 italic">-</span>
                                )}
                              </td>
                              <td className="px-4 py-3">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  emp.statusType === 'ontime'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : emp.statusType === 'late'
                                    ? 'bg-amber-100 text-amber-800'
                                    : emp.statusType === 'early'
                                    ? 'bg-orange-100 text-orange-800'
                                    : emp.statusType === 'missing'
                                    ? 'bg-purple-100 text-purple-800'
                                    : 'bg-rose-100 text-rose-800'
                                }`}>
                                  {emp.status}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-right font-mono font-bold">
                                {emp.penalty > 0 ? (
                                  <span className="text-red-600">Rp {emp.penalty.toLocaleString('id-ID')}</span>
                                ) : (
                                  <span className="text-emerald-600 font-medium">Rp 0</span>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="p-3 bg-slate-50 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                    <span>Menampilkan {filteredEmployees.length} pegawai</span>
                    <span>Tabel Database: <code className="text-emerald-700 font-mono">attendance_daily</code> (Idempotent)</span>
                  </div>
                </div>

                {/* Right Column: Recent Machine Transactions & Quick Actions */}
                <div className="space-y-6">
                  
                  {/* Recent Raw Logs Card */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                    <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                          Data Mentah Terkini (Raw Log)
                        </h3>
                        <p className="text-[11px] text-slate-400">Stream transaksi mesin absensi</p>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium font-mono">
                        attendance_raw
                      </span>
                    </div>

                    <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                      {SAMPLE_RAW_LOGS.slice(0, 6).map((log) => (
                        <div key={log.id} className="p-3 hover:bg-slate-50/80 transition-colors flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 font-mono font-bold text-[11px]">
                              {log.type}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-800">{log.name}</div>
                              <div className="text-[10px] text-slate-400 font-mono">
                                {log.machine} &bull; {log.department}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-mono font-bold text-slate-700">{log.time}</div>
                            <span className="text-[9px] text-slate-400">WIB</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
                      <button 
                        onClick={() => setActiveMenu('raw')}
                        className="text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                      >
                        Buka Seluruh Transaksi Mentah &rarr;
                      </button>
                    </div>
                  </div>

                  {/* Quick Roadmap Tracker Card */}
                  <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-5 border border-slate-800 shadow-xs">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                        Status Pembangunan Sistem
                      </span>
                      <span className="text-xs font-mono text-slate-400">Phase 1 of 10</span>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                        <span className="font-medium flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          Phase 1: Project, DB & Auth
                        </span>
                        <span className="text-[10px] uppercase font-bold">SELESAI</span>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                        <span className="font-medium flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          Phase 2: Data Pegawai & CRUD
                        </span>
                        <span className="text-[10px] uppercase font-bold">SELESAI</span>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/60 text-slate-400">
                        <span className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                          Phase 3: Import & Raw Mapping
                        </span>
                        <span className="text-[10px] uppercase text-amber-400 font-semibold">Berikutnya</span>
                      </div>

                      <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/60 text-slate-400">
                        <span className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                          Phase 5: AttendanceCalculationService
                        </span>
                        <span className="text-[10px] uppercase">Menunggu</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                      Phase 2 selesai. Ketikkan <strong>"LANJUT PHASE 3"</strong> untuk melanjutkan pengembangan ke modul Import Mesin Absensi & Raw Data Mapping.
                    </div>
                  </div>

                </div>

              </div>

            </div>
          )}

          {/* VIEW: CODE EXPLORER */}
          {activeMenu === 'code-explorer' && (
            <div className="space-y-5">
              <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-emerald-600">Arsitektur Kode Laravel 11/12</span>
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-0.5">
                    Inspektur File & Source Code Arsitektur
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Setiap file disusun rapi sesuai standar industri Laravel, PSR-12, Form Requests, dan prinsip single responsibility.
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Phase Filter Tabs */}
                  <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-medium flex-wrap">
                    <button
                      onClick={() => {
                        setCodePhaseFilter('phase6');
                        setSelectedCodeFile(LARAVEL_PHASE6_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'phase6'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Phase 6 & 7: Rekonsiliasi & Tukin ({LARAVEL_PHASE6_FILES.length})
                    </button>
                    <button
                      onClick={() => {
                        setCodePhaseFilter('phase4');
                        setSelectedCodeFile(LARAVEL_PHASE4_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'phase4'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Phase 4: Kalender & Libur ({LARAVEL_PHASE4_FILES.length})
                    </button>
                    <button
                      onClick={() => {
                        setCodePhaseFilter('phase3');
                        setSelectedCodeFile(LARAVEL_PHASE3_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'phase3'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Phase 3: Log Mentah ({LARAVEL_PHASE3_FILES.length})
                    </button>
                    <button
                      onClick={() => {
                        setCodePhaseFilter('phase2');
                        setSelectedCodeFile(LARAVEL_PHASE2_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'phase2'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Phase 2: Pegawai ({LARAVEL_PHASE2_FILES.length})
                    </button>
                    <button
                      onClick={() => {
                        setCodePhaseFilter('phase1');
                        setSelectedCodeFile(LARAVEL_PHASE1_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'phase1'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Phase 1: DB & Auth ({LARAVEL_PHASE1_FILES.length})
                    </button>
                    <button
                      onClick={() => {
                        setCodePhaseFilter('all');
                        setSelectedCodeFile(LARAVEL_PHASE6_FILES[0]);
                      }}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        codePhaseFilter === 'all'
                          ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Semua ({LARAVEL_PHASE1_FILES.length + LARAVEL_PHASE2_FILES.length + LARAVEL_PHASE3_FILES.length + LARAVEL_PHASE4_FILES.length + LARAVEL_PHASE6_FILES.length})
                    </button>
                  </div>

                  <button
                    onClick={() => handleCopyCode(selectedCodeFile.code)}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Tersalin!' : 'Salin File'}</span>
                  </button>
                </div>
              </div>

              {/* Two Column Explorer: File List on Left, Code Viewer on Right */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                
                {/* Left: File Selector */}
                <div className="lg:col-span-4 space-y-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1 mb-2 flex items-center justify-between">
                    <span>Daftar File ({allCodeFiles.length})</span>
                    <span className="text-[10px] text-emerald-600 font-bold uppercase">{codePhaseFilter}</span>
                  </div>

                  <div className="space-y-1.5 max-h-[680px] overflow-y-auto pr-1">
                    {allCodeFiles.map((file) => (
                      <button
                        key={file.path}
                        onClick={() => setSelectedCodeFile(file)}
                        className={`w-full text-left p-3 rounded-xl border transition-all ${
                          selectedCodeFile.path === file.path
                            ? 'bg-white border-emerald-500 shadow-xs ring-2 ring-emerald-500/20'
                            : 'bg-white/80 border-slate-200 hover:bg-white hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                            {file.category}
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">
                            {file.path.split('.').pop()}
                          </span>
                        </div>
                        <div className="text-xs font-bold text-slate-800">{file.title}</div>
                        <div className="text-[11px] font-mono text-slate-400 truncate mt-0.5">{file.path}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Right: Code Viewer */}
                <div className="lg:col-span-8 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col">
                  {/* Code Viewer Header */}
                  <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1.5 mr-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></div>
                      </div>
                      <span className="font-mono text-slate-300 font-medium">{selectedCodeFile.path}</span>
                    </div>

                    <button
                      onClick={() => handleCopyCode(selectedCodeFile.code)}
                      className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                      title="Salin Kode"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Description Bar */}
                  <div className="px-5 py-2.5 bg-slate-900/90 border-b border-slate-800/80 text-xs text-emerald-400 font-medium flex items-center gap-2">
                    <Info className="w-3.5 h-3.5 shrink-0" />
                    <span>{selectedCodeFile.description}</span>
                  </div>

                  {/* Code Block */}
                  <div className="p-5 flex-1 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed bg-slate-950/70 max-h-[600px] overflow-y-auto">
                    <pre>
                      <code>{selectedCodeFile.code}</code>
                    </pre>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* VIEW: EMPLOYEES (PHASE 2 - FULL INTERACTIVE) */}
          {activeMenu === 'employees' && (
            <EmployeeManagement userRole={selectedRole} />
          )}

          {/* VIEW: RAW LOGS (PHASE 3 - FULL INTERACTIVE) */}
          {activeMenu === 'raw' && (
            <RawAttendanceManagement
              userRole={selectedRole}
              onNavigateToImport={() => setActiveMenu('import')}
            />
          )}

          {/* VIEW: IMPORT DATA ABSENSI (PHASE 3 - FULL INTERACTIVE) */}
          {activeMenu === 'import' && (
            <AttendanceImportModule
              userRole={selectedRole}
              onNavigateToRaw={() => setActiveMenu('raw')}
            />
          )}

          {/* VIEW: SETTINGS PREVIEW */}
          {activeMenu === 'settings' && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-6">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Pengaturan Jam Kerja & Aturan Denda</h2>
                <p className="text-xs text-slate-500">Nilai tersimpan dalam database tabel <code className="font-mono text-emerald-700">settings</code> dan <code className="font-mono text-emerald-700">work_schedules</code>.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Jadwal Jam Kerja Kantor</h3>
                  
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Jam Masuk Normal (WIB):</label>
                    <input type="text" readOnly value="08:15" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold" />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Jam Pulang Senin - Kamis (WIB):</label>
                    <input type="text" readOnly value="16:30" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold" />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Jam Pulang Hari Jumat (WIB):</label>
                    <input type="text" readOnly value="17:00" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold" />
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Nominal Denda & Potongan</h3>
                  
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Terlambat &le; 60 Menit:</label>
                    <input type="text" readOnly value="Rp 7.500" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold text-amber-600" />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Terlambat &gt; 60 Menit:</label>
                    <input type="text" readOnly value="Rp 10.000" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold text-rose-600" />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Pulang Cepat & Missing In / Out:</label>
                    <input type="text" readOnly value="Rp 10.000" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold text-orange-600" />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Tidak Hadir Hari Kerja (Missing Keduanya):</label>
                    <input type="text" readOnly value="Rp 20.000" className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono font-bold text-red-700" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: WORK CALENDAR & HOLIDAYS (PHASE 4 - FULL INTERACTIVE) */}
          {activeMenu === 'calendar' && (
            <WorkCalendarManagement
              userRole={selectedRole}
              onSelectDateForDashboard={(d) => {
                setSelectedDate(d);
                setActiveMenu('dashboard');
              }}
            />
          )}

          {/* VIEW: ENGINE REKONSILIASI & DENDA OTOMATIS (PHASE 6 - FULL INTERACTIVE) */}
          {activeMenu === 'reconcile' && (
            <ReconciliationEngineModule
              userRole={selectedRole}
              currentSelectedDate={selectedDate}
              onNavigateToReports={() => setActiveMenu('monthly-report')}
              onSelectDateChange={(d) => setSelectedDate(d)}
            />
          )}

          {/* VIEW: REKAP BULANAN & SLIP POTONGAN TUKIN (PHASE 7 & 8 - FULL INTERACTIVE) */}
          {activeMenu === 'monthly-report' && (
            <MonthlyReportModule />
          )}

          {/* VIEW: DATABASE SUPABASE (POSTGRESQL CLOUD) */}
          {activeMenu === 'supabase' && (
            <SupabaseManagerModule />
          )}

        </main>
      </div>

    </div>
  );
}
