import { createClient, SupabaseClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

let supabaseClient: SupabaseClient | null = null;

export interface SupabaseConfig {
  url: string;
  key: string;
  isConfigured: boolean;
}

export function getSupabaseConfig(): SupabaseConfig {
  const url = (process.env.SUPABASE_URL || 'https://vwzzhkbivgsptcldodor.supabase.co').trim();
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY || 'sb_secret_yXycQojGl7b77uZritbrsw_gpr6juh-').trim();

  return {
    url,
    key,
    isConfigured: Boolean(url && key),
  };
}

export function getSupabase(): SupabaseClient | null {
  const { url, key, isConfigured } = getSupabaseConfig();
  if (!isConfigured) {
    return null;
  }

  if (!supabaseClient) {
    // Normalize URL: strip trailing /rest/v1/ or slashes if user pasted REST endpoint
    const cleanUrl = url.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
    
    supabaseClient = createClient(cleanUrl, key, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
  }

  return supabaseClient;
}

/**
 * Checks connection health to the Supabase REST API
 */
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  url: string;
  latencyMs: number;
  message: string;
  host?: string;
  tables?: string[];
  error?: string;
}> {
  const { url, key, isConfigured } = getSupabaseConfig();
  if (!isConfigured) {
    return {
      connected: false,
      url: '',
      latencyMs: 0,
      message: 'Supabase URL atau Key belum dikonfigurasi pada environment variables.',
    };
  }

  const cleanUrl = url.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
  const startTime = Date.now();

  try {
    // PostgREST root introspection test
    const response = await fetch(`${cleanUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: key,
        Authorization: `Bearer ${key}`,
        Accept: 'application/json',
      },
    });

    const latencyMs = Date.now() - startTime;

    if (response.ok) {
      const data = await response.json();
      const paths = data.paths ? Object.keys(data.paths).filter(p => p !== '/') : [];
      const tables = paths.map(p => p.replace(/^\//, ''));

      return {
        connected: true,
        url: cleanUrl,
        host: data.host || new URL(cleanUrl).host,
        latencyMs,
        tables,
        message: `Terhubung dengan sukses ke Supabase (${data.host || cleanUrl}) dalam ${latencyMs}ms.`,
      };
    } else {
      const errorText = await response.text();
      return {
        connected: false,
        url: cleanUrl,
        latencyMs,
        message: `Koneksi gagal dengan status HTTP ${response.status}`,
        error: errorText,
      };
    }
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    return {
      connected: false,
      url: cleanUrl,
      latencyMs,
      message: `Gagal menghubungi Supabase: ${err.message}`,
      error: err.stack || String(err),
    };
  }
}
